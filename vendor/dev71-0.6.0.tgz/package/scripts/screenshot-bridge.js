import http from "node:http";
import fs from "node:fs";
import path from "node:path";

const PORT = Number(process.env.DEVTOOLS_BRIDGE_PORT) || 8088;
const DEFAULT_DIR = process.env.DEVTOOLS_SCREENSHOT_DIR || path.resolve(process.cwd(), "screenshots");

const server = http.createServer((req, res) => {
  res.setHeader("Access-Control-Allow-Origin", "*");
  res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  res.setHeader("Access-Control-Allow-Headers", "Content-Type");

  if (req.method === "OPTIONS") {
    res.writeHead(204);
    res.end();
    return;
  }

  if (req.method === "POST" && req.url === "/api/devtools/save-screenshot") {
    let body = "";
    req.on("data", (chunk) => {
      body += chunk;
    });
    req.on("end", () => {
      try {
        const { filename, dataUrl, directory } = JSON.parse(body);
        const targetDir = directory || DEFAULT_DIR;
        if (!fs.existsSync(targetDir)) {
          fs.mkdirSync(targetDir, { recursive: true });
        }
        const safeFilename = (filename || `screenshot_${Date.now()}.png`).replace(/[^a-zA-Z0-9_.-]/g, "_");
        const filePath = path.join(targetDir, safeFilename);

        const matches = dataUrl.match(/^data:([A-Za-z-+/]+);base64,(.+)$/);
        if (matches) {
          const buffer = Buffer.from(matches[2], "base64");
          fs.writeFileSync(filePath, buffer);
        } else if (dataUrl.startsWith("data:image/svg+xml")) {
          const svgContent = decodeURIComponent(dataUrl.split(",")[1]);
          fs.writeFileSync(filePath, svgContent, "utf-8");
        } else {
          fs.writeFileSync(filePath, dataUrl, "utf-8");
        }

        res.writeHead(200, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ success: true, filePath: `file://${filePath}`, filename: safeFilename }));
      } catch (err) {
        res.writeHead(500, { "Content-Type": "application/json" });
        res.end(JSON.stringify({ success: false, error: String(err) }));
      }
    });
    return;
  }

  res.writeHead(404);
  res.end();
});

server.listen(PORT, "0.0.0.0", () => {
  console.log(`📸 DevTools Screenshot Bridge listening on http://0.0.0.0:${PORT}`);
});
