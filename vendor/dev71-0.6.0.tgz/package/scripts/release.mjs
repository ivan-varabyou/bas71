#!/usr/bin/env node
/**
 * @file release.mjs
 * Automated release pipeline for dev71.
 *
 * Usage:
 *   node scripts/release.mjs [patch | minor | major | <explicit-version>] [options]
 *
 * Options:
 *   --dry-run       Calculate new version and simulate without modifying files
 *   --no-test       Skip running typecheck and unit tests
 *   --no-build      Skip compiling TypeScript and bundling esbuild
 *   --no-sync       Skip syncing to sibling repositories or client bundles
 *   --message <msg> Custom release note to include in CHANGELOG.md
 */

import fs from "node:fs";
import path from "node:path";
import { execSync } from "node:child_process";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DEVTOOLS_ROOT = path.resolve(__dirname, "..");

// Known sibling and consumer paths
const VIAFACTORY_DEVTOOLS = "/media/express/WORK1/project/viafactory/packages/devtools";
const SOAPION_DEVTOOLS = "/media/express/WORK1/project/soapion/packages/devtools";
const SOAPION_FLUTTER_WEB_BUNDLE = "/media/express/WORK1/project/soapion/transcription_client/web/devtools.js";
const MOCKAPIX_ROOT = "/media/express/WORK1/project/mockapix";

function parseSemver(version) {
  const match = version.trim().match(/^(\d+)\.(\d+)\.(\d+)(?:-([\w.-]+))?$/);
  if (!match) {
    throw new Error(`Invalid semver version: "${version}"`);
  }
  return {
    major: parseInt(match[1], 10),
    minor: parseInt(match[2], 10),
    patch: parseInt(match[3], 10),
    prerelease: match[4] || null,
  };
}

function calculateNextVersion(currentVersion, bumpType) {
  const parsed = parseSemver(currentVersion);
  switch (bumpType.toLowerCase()) {
    case "patch":
      return `${parsed.major}.${parsed.minor}.${parsed.patch + 1}`;
    case "minor":
      return `${parsed.major}.${parsed.minor + 1}.0`;
    case "major":
      return `${parsed.major + 1}.0.0`;
    default:
      // Check if bumpType is an explicit semver
      if (/^\d+\.\d+\.\d+/.test(bumpType)) {
        return bumpType;
      }
      throw new Error(
        `Unknown bump type: "${bumpType}". Must be 'patch', 'minor', 'major', or explicit 'X.Y.Z'.`
      );
  }
}

function updateFile(filePath, regex, replacement, isDryRun) {
  if (!fs.existsSync(filePath)) return;
  const content = fs.readFileSync(filePath, "utf-8");
  if (!regex.test(content)) {
    console.warn(`⚠️ Warning: pattern ${regex} not matched in ${filePath}`);
    return;
  }
  const updated = content.replace(regex, replacement);
  if (!isDryRun) {
    fs.writeFileSync(filePath, updated, "utf-8");
  }
}

function updateChangelog(changelogPath, nextVersion, bumpType, message, isDryRun) {
  const today = new Date().toISOString().split("T")[0];
  const header = `## [${nextVersion}] - ${today} (${bumpType.toUpperCase()})`;
  const defaultNotes = {
    major: "Breaking changes to devtools inspection contract, mount API, or tracing schema.",
    minor: "New features, canvas/framework engine heuristics, screenshot bridge modes, or export capabilities.",
    patch: "Bug fixes, styling refinements, and internal stability improvements.",
  };
  const note = message || defaultNotes[bumpType.toLowerCase()] || "Release update.";

  const entry = `\n${header}\n\n- ${note}\n`;

  if (fs.existsSync(changelogPath)) {
    const existing = fs.readFileSync(changelogPath, "utf-8");
    if (existing.includes(`## [${nextVersion}]`)) {
      return; // Already present
    }
    const lines = existing.split("\n");
    let insertIdx = 0;
    // Find first ## or insert after top header
    const firstSectionIdx = lines.findIndex((l) => l.startsWith("## ["));
    if (firstSectionIdx !== -1) {
      lines.splice(firstSectionIdx, 0, entry.trim() + "\n");
    } else {
      lines.push(entry);
    }
    if (!isDryRun) {
      fs.writeFileSync(changelogPath, lines.join("\n"), "utf-8");
    }
  } else {
    const initialContent = `# Changelog — @viafactory/devtools\n\nAll notable changes to this package are documented here.\n${entry}`;
    if (!isDryRun) {
      fs.writeFileSync(changelogPath, initialContent, "utf-8");
    }
  }
}

function runCommand(cmd, cwd) {
  console.log(`\n$ (in ${path.relative(process.cwd(), cwd) || "."}) ${cmd}`);
  execSync(cmd, { cwd, stdio: "inherit" });
}

function syncDirectories(srcDir, destDir) {
  if (!fs.existsSync(destDir) || srcDir === destDir) return;
  console.log(`🔄 Syncing devtools from ${srcDir} to ${destDir}...`);
  // Copy src, scripts, package.json, tsconfig files, README
  const itemsToSync = ["src", "scripts", "package.json", "tsconfig.json", "tsconfig.build.json", "README.md", "CHANGELOG.md"];
  for (const item of itemsToSync) {
    const srcPath = path.join(srcDir, item);
    const destPath = path.join(destDir, item);
    if (!fs.existsSync(srcPath)) continue;
    fs.cpSync(srcPath, destPath, { recursive: true, force: true });
  }
}

async function main() {
  const args = process.argv.slice(2);
  const isDryRun = args.includes("--dry-run");
  const skipTest = args.includes("--no-test");
  const skipBuild = args.includes("--no-build");
  const skipSync = args.includes("--no-sync");

  const msgIdx = args.indexOf("--message");
  const customMessage = msgIdx !== -1 ? args[msgIdx + 1] : null;

  const positionalArgs = args.filter((a) => !a.startsWith("--") && a !== customMessage);
  const bumpType = positionalArgs[0] || "patch";

  const pkgJsonPath = path.join(DEVTOOLS_ROOT, "package.json");
  if (!fs.existsSync(pkgJsonPath)) {
    console.error(`❌ package.json not found at ${pkgJsonPath}`);
    process.exit(1);
  }

  const pkg = JSON.parse(fs.readFileSync(pkgJsonPath, "utf-8"));
  const currentVersion = pkg.version;
  const nextVersion = calculateNextVersion(currentVersion, bumpType);

  console.log(`=======================================================`);
  console.log(`📦 dev71 Release Pipeline`);
  console.log(`=======================================================`);
  console.log(`Current version: ${currentVersion}`);
  console.log(`Bump type:       ${bumpType}`);
  console.log(`Target version:  ${nextVersion}`);
  console.log(`Dry run:         ${isDryRun ? "YES" : "NO"}`);
  console.log(`=======================================================\n`);

  if (isDryRun) {
    console.log(`[DRY RUN] Would update package.json to ${nextVersion}`);
    console.log(`[DRY RUN] Would update DEVTOOLS_VERSION in src/ui/devtools-overlay.ts`);
    console.log(`[DRY RUN] Would update src/version.ts`);
    console.log(`[DRY RUN] Would run typecheck, test, and build`);
    return;
  }

  // 1. Update version constant file src/version.ts
  const versionTsPath = path.join(DEVTOOLS_ROOT, "src", "version.ts");
  const versionTsContent = `/**
 * Canonical version of dev71.
 * Automatically synchronized by scripts/release.mjs.
 */
export const DEV71_VERSION = "${nextVersion}";
export const DEVTOOLS_VERSION = DEV71_VERSION;
`;
  fs.writeFileSync(versionTsPath, versionTsContent, "utf-8");
  console.log(`✅ Updated ${path.relative(DEVTOOLS_ROOT, versionTsPath)}`);

  // 2. Update devtools-overlay.ts if it defines DEVTOOLS_VERSION directly
  const overlayTsPath = path.join(DEVTOOLS_ROOT, "src", "ui", "devtools-overlay.ts");
  if (fs.existsSync(overlayTsPath)) {
    const overlayContent = fs.readFileSync(overlayTsPath, "utf-8");
    if (/export const DEVTOOLS_VERSION = ".*?";/.test(overlayContent)) {
      updateFile(
        overlayTsPath,
        /export const DEVTOOLS_VERSION = ".*?";/,
        `export const DEVTOOLS_VERSION = "${nextVersion}";`,
        isDryRun
      );
      console.log(`✅ Updated DEVTOOLS_VERSION in ${path.relative(DEVTOOLS_ROOT, overlayTsPath)}`);
    }
  }

  // 3. Update package.json
  pkg.version = nextVersion;
  fs.writeFileSync(pkgJsonPath, JSON.stringify(pkg, null, 2) + "\n", "utf-8");
  console.log(`✅ Updated ${path.relative(DEVTOOLS_ROOT, pkgJsonPath)} to ${nextVersion}`);

  // 4. Update CHANGELOG.md
  const changelogPath = path.join(DEVTOOLS_ROOT, "CHANGELOG.md");
  updateChangelog(changelogPath, nextVersion, bumpType, customMessage, isDryRun);
  console.log(`✅ Updated ${path.relative(DEVTOOLS_ROOT, changelogPath)}`);

  // 5. Verification (typecheck and tests)
  if (!skipTest) {
    console.log(`\n🔍 Verifying codebase integrity...`);
    try {
      runCommand("pnpm typecheck", DEVTOOLS_ROOT);
      runCommand("pnpm test", DEVTOOLS_ROOT);
      console.log(`✅ Typecheck and tests passed.`);
    } catch (err) {
      console.error(`\n❌ Validation failed! Reverting package.json and version constant...`);
      pkg.version = currentVersion;
      fs.writeFileSync(pkgJsonPath, JSON.stringify(pkg, null, 2) + "\n", "utf-8");
      fs.writeFileSync(
        versionTsPath,
        `export const DEVTOOLS_VERSION = "${currentVersion}";\n`,
        "utf-8"
      );
      updateFile(
        overlayTsPath,
        /export const DEVTOOLS_VERSION = ".*?";/,
        `export const DEVTOOLS_VERSION = "${currentVersion}";`,
        false
      );
      process.exit(1);
    }
  }

  // 6. Build
  if (!skipBuild) {
    console.log(`\n🔨 Building bundles...`);
    runCommand("pnpm build", DEVTOOLS_ROOT);
    console.log(`✅ Distribution bundles generated.`);
  }

  // 7. Client consumer update & cross-repo sync
  if (!skipSync) {
    const builtBundle = path.join(DEVTOOLS_ROOT, "dist", "devtools.bundle.js");
    if (fs.existsSync(builtBundle)) {
      if (fs.existsSync(path.dirname(SOAPION_FLUTTER_WEB_BUNDLE))) {
        fs.copyFileSync(builtBundle, SOAPION_FLUTTER_WEB_BUNDLE);
        console.log(`✅ Copied devtools.bundle.js -> ${SOAPION_FLUTTER_WEB_BUNDLE}`);
      }
    }

    // Pack and update mockapix vendor tgz
    if (fs.existsSync(MOCKAPIX_ROOT)) {
      try {
        console.log(`📦 Packing devtools for mockapix...`);
        const vendorDir = path.join(MOCKAPIX_ROOT, "vendor");
        if (fs.existsSync(vendorDir)) {
          for (const f of fs.readdirSync(vendorDir)) {
            if (f.startsWith("viafactory-devtools-") && f.endsWith(".tgz")) {
              fs.unlinkSync(path.join(vendorDir, f));
            }
          }
        }
        runCommand(`npm pack ${DEVTOOLS_ROOT} --pack-destination ${vendorDir}`, DEVTOOLS_ROOT);
        const mockapixPkgPath = path.join(MOCKAPIX_ROOT, "package.json");
        if (fs.existsSync(mockapixPkgPath)) {
          const mPkg = JSON.parse(fs.readFileSync(mockapixPkgPath, "utf-8"));
          if (mPkg.devDependencies && mPkg.devDependencies["@viafactory/devtools"]) {
            mPkg.devDependencies["@viafactory/devtools"] = `file:vendor/viafactory-devtools-${nextVersion}.tgz`;
          } else if (mPkg.dependencies && mPkg.dependencies["@viafactory/devtools"]) {
            mPkg.dependencies["@viafactory/devtools"] = `file:vendor/viafactory-devtools-${nextVersion}.tgz`;
          }
          fs.writeFileSync(mockapixPkgPath, JSON.stringify(mPkg, null, 2) + "\n", "utf-8");
          console.log(`✅ Updated mockapix package.json dependency to viafactory-devtools-${nextVersion}.tgz`);
          runCommand("npm install", MOCKAPIX_ROOT);
          console.log(`✅ npm install completed in mockapix.`);
        }
      } catch (err) {
        console.warn(`⚠️ Warning: Failed to pack/install for mockapix:`, err.message);
      }
    }

    // Cross-sync between soapion and viafactory repositories
    const isViafactory = DEVTOOLS_ROOT.startsWith("/media/express/WORK1/project/viafactory");
    const otherRepoDevtools = isViafactory ? SOAPION_DEVTOOLS : VIAFACTORY_DEVTOOLS;
    if (fs.existsSync(otherRepoDevtools)) {
      syncDirectories(DEVTOOLS_ROOT, otherRepoDevtools);
      // Run build in other repo as well
      try {
        console.log(`🔨 Building bundle in sibling repository ${otherRepoDevtools}...`);
        runCommand("pnpm build", otherRepoDevtools);
        console.log(`✅ Sibling repository devtools built and synchronized.`);
      } catch (e) {
        console.warn(`⚠️ Warning: Failed to build in sibling repo:`, e.message);
      }
    }
  }

  console.log(`\n=======================================================`);
  console.log(`🎉 RELEASE SUCCESSFUL: dev71 v${nextVersion}`);
  console.log(`=======================================================`);
  console.log(`Next step to commit:`);
  console.log(`  git add packages/devtools/`);
  console.log(`  git commit -m "chore(devtools): release v${nextVersion}"`);
  console.log(`=======================================================\n`);
}

main().catch((err) => {
  console.error("Release script encountered fatal error:", err);
  process.exit(1);
});
