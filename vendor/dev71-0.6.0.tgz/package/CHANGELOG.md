# Changelog — dev71

All notable changes to this package are documented here.

## [0.6.0] - 2026-11-06 (MINOR)

- New features, canvas/framework engine heuristics, screenshot bridge modes, or export capabilities.

## [0.5.0] - 2026-11-06 (MINOR)

- Visual connection arrows, natural language & voice link parsing between points, and screenshot export links.

## [0.4.3] - 2026-11-05 (PATCH)

- feat(devtools): interactive mode switcher cards in settings, prominent active mode button indicator, removed action intent chips

## [0.4.2] - 2026-11-05 (PATCH)

- Bug fixes, styling refinements, and internal stability improvements.

## [0.4.1] - 2026-11-05 (PATCH)

- Fix UI layout overflows, make comment popups and modal settings responsive, enhance mode switcher

## [0.4.0] - 2026-10-26 (MINOR)

- Add support for Flutter, Pixi.js, React Native Canvas engines, unique session/step hashes, and screenshot bridge
