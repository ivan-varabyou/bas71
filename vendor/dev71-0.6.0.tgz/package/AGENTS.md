# dev71 Development Rules

`dev71` is the universal in-browser DOM-to-source inspector & AI agent context copier for Angular, React, Vue, and web applications.
The project is kept in tone using the `df71` Dark Factory harness.

## Size and decomposition limits

Strict physical line count limits per handwritten file:

| Category | Maximum lines |
| --- | ---: |
| Entry, public API, index | 80 |
| Types, ports, constants | 160 |
| View, templates, styles | 220 |
| Controller, manager, policy | 220 |
| Canvas / bridge adapter, dom-utils | 350 |
| Hard limit for any handwritten file | 350 |

- Every handwritten file in `src/` must remain strictly <= 350 physical lines.
- When approaching 300 lines, extract a named, cohesive responsibility into a sub-module.
- Do not disable lint or minification to bypass line budgets.

## Harness & verification (df71)

Before any commit or release:
1. `npm run typecheck` - Strict TypeScript check.
2. `npm test` - Vitest test suite must pass 100%.
3. `npm run check:line-budgets` - Physical line budget check across all sources.
4. `npm run project-check` - `df71 project-check` policy validation.
5. `npm run build` - Dual build: TypeScript declaration emission and ESBuild bundle.
6. `npm run harness` - `df71 harness` automated multi-stage pipeline.
