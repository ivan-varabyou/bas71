# dev71

> Universal In-Browser DOM-to-Source Inspector & AI Agent Context Copier.
> Supports **Angular**, **React**, and **Vue**. Integrates with **Vite**, **esbuild**, and **Angular Application Builder**.

---

## ⚡ Overview

`dev71` enables instant DOM-to-source traceability and structured context copying directly into clipboard for AI coding agents.

### Why It Exists

When human developers or AI agents test web UIs in a browser, locating the exact component file, line number, caller hierarchy, and test identifier typically requires searching the codebase across dozens of files.

`dev71` eliminates this overhead:

1. **Build-Time Tagging**: Automatically injects `data-vf-path="file:line"` and `data-vf-comp="ComponentName"` into opening template tags.
2. **Universal Runtime Overlay**: Works identically across Angular, React, and Vue applications.
3. **Agent-Optimized Clipboard**: Formats copied elements in a compact, deterministic Markdown format specifically designed for fast AI parsing.
4. **DF71 Harness Quality Gate**: Maintained in tone with `df71` Dark Factory harness.

---

## 🎯 Clipboard Output Specification

### Single Element Mode (Click / Ctrl+Click)

```markdown
🎯 Target Entity: **ButtonComponent** (`<vf-button>`)
📂 Entity Source: `packages/admin-platform/src/frontend/shared/ui/button/button.component.ts`
⚡ Action: Replace custom element with Shared UI component
🛑 Scope Lock: Modify **CALL SITE ONLY** (`src/frontend/shared/ui/content-header/content-header.component.html:49`). Do NOT edit shared definitions.
📦 Component Bundle:
   • TS:   `packages/admin-platform/src/frontend/shared/ui/content-header/content-header.component.ts`
   • HTML: `packages/admin-platform/src/frontend/shared/ui/content-header/content-header.component.html:49`
   • CSS:  `packages/admin-platform/src/frontend/shared/ui/content-header/content-header.component.css`
🎨 Style Trace:
   • `.btn-create` (`content-header.component.css:12`) -> padding: 8px 16px; background: #4945ff; font-size: 13px
📍 Called by: DataTableComponent (`src/frontend/shared/ui/data-table/data-table.component.html:3`)
🌐 Route: `/admin/content-manager/collection-types/api::article.article`
🏷 cm-create-entry-btn · ✅ TC-CM-001 · ⚡ FLOW-CM-CREATE-01
💬 "Create new entry"
📝 Optional agent note
```

### Multi-Step Trace Mode (Ctrl + Shift + Click)

```markdown
⚡ Trace (2 steps)

1. [VIOLET] 🎯 `a[data-testid="cm-create-entry-btn"]` · ContentHeaderComponent
   📍 Called by: DataTableComponent (src/frontend/shared/ui/data-table/data-table.component.html:3)
   🌐 Route: `/admin/content-manager/collection-types/api::article.article`
   📄 src/frontend/shared/ui/content-header/content-header.component.html:49
   🏷 cm-create-entry-btn · ✅ TC-CM-001 · ⚡ FLOW-CM-CREATE-01

2. [CYAN] 🎯 `input#title-input` · CmFormComponent
   📍 Called by: ContentHeaderComponent (src/frontend/shared/ui/content-header/content-header.component.html:58)
   🌐 Route: `/admin/content-manager/create`
   📄 src/frontend/shared/ui/cm-form/cm-form.component.html:34
   🏷 cm-title-input · ✅ TC-CM-002
   📝 User typed invalid article title here
```

---

## ⌨️ User Controls & Hotkeys

| Action | Gesture / Key | Description |
|---|---|---|
| **Toggle Overlay** | `Alt + D` (or custom hotkey) | Activates/deactivates the inspector overlay. |
| **Annotate & Pin** | **Hold `Ctrl` + Click** | Highlights element in indigo, opens a note popup. Ordinary click does nothing, preventing accidental triggers. |
| **Group Trace** | **Hold `Ctrl + Shift` + Click** | Appends elements to interaction sequence with rotating color palette (Violet, Cyan, Amber, Rose, Lime, Orange). Releasing keys resets active selection state. |
| **Persistent Notes** | Above each selected element | Renders a grey badge `#N "note"` with `✏️` (edit note) and `✕` (exclude step). |
| **Edit & Reorder Trace** | Click `✏️ Edit Trace` | Opens modal with **Drag & Drop** (`☰`) reordering of steps, inline note edits, and deletion of accidental clicks. |
| **Copy Trace** | Click `📋 Copy Trace` | Copies full multi-step trace ordered by the current sequence into clipboard. |
| **Settings** | Click `⚙️` icon | Customize activation hotkeys (Primary / Secondary) and output format. |

---

## 📦 Installation & Setup

### 1. Install Package

```bash
pnpm add -D dev71
```

---

## 2. Browser Runtime Mount & Universal Project Configuration

Mount the overlay in your application's client entry point:

```typescript
import { mountDevTools } from "dev71";

const devTools = mountDevTools({
  enabled: false, // Starts inactive, toggles via Alt+D
  framework: "auto", // "angular" | "react" | "vue" | "auto"
  componentPrefixes: ["app-", "ui-", "vf-"], // Custom element tag prefixes
  pathPrefix: "packages/my-app/", // Strips repo path prefix for cleaner traces
});
```

---

### 3. Build-Time Tagger Integration

Choose the plugin matching your bundler:

#### Option A: Vite (`vite.config.ts`) — Universal (Angular / React / Vue)
```typescript
import { defineConfig } from "vite";
import { dev71Plugin } from "dev71/vite";

export default defineConfig({
  plugins: [
    dev71Plugin({
      framework: "auto", // "angular" | "react" | "vue" | "auto"
    }),
  ],
});
```

#### Option B: esbuild (`build.ts` / custom scripts)
```typescript
import esbuild from "esbuild";
import { dev71EsbuildPlugin } from "dev71/esbuild";

await esbuild.build({
  entryPoints: ["src/index.tsx"],
  bundle: true,
  outfile: "dist/bundle.js",
  plugins: [
    dev71EsbuildPlugin({ framework: "auto" }),
  ],
});
```

#### Option C: Angular CLI / Application Builder (`scripts/tag-templates.mjs`)
In projects using Angular CLI `@angular-devkit/build-angular:application` or `@angular/build`:

```javascript
import { tagTemplateSource } from "dev71";
```

---

## 🛠 Quality & Harness (df71)

`dev71` is validated and guarded by `df71`:

```bash
pnpm run typecheck       # Strict TypeScript check
pnpm run test            # Vitest suite
pnpm run check:line-budgets # Enforce physical line budget limits (<= 350 lines)
pnpm run project-check   # DF71 project policy validation
pnpm run harness         # Full dark-factory multi-stage gate
```
