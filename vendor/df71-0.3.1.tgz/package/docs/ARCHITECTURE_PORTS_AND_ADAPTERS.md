# DF71 Hexagonal Architecture: Ports and Adapters

The DF71 Dark Factory Harness strictly enforces Ports and Adapters (Hexagonal Architecture) across all supported project stacks.

---

## 1. Core Principles

1. **Domain Purity**:
   - The domain layer (`domain/`) contains pure business logic, entities, value objects, and domain errors.
   - Zero framework dependencies: no Vue, React, Angular, Chrome Extension APIs, IndexedDB, or HTTP clients.

2. **Ports Owned by Consumers**:
   - Ports (`ports/` or `application/ports/`) are TypeScript interfaces or language protocols defined by domain/application needs.
   - An adapter adapts to the port, not the other way around.

3. **Adapters at the Edge**:
   - Driven adapters (e.g., storage, network, browser APIs) implement ports.
   - Driving adapters (e.g., UI components, CLI commands, HTTP handlers) invoke application use cases.

4. **Composition Root**:
   - Dependencies are wired exclusively in the composition root (e.g., `main.ts`, `ioc.ts`).
   - UI components and domain services must never instantiate concrete infrastructure adapters directly.

---

## 2. Layer Diagram

```mermaid
flowchart TD
    subgraph UI ["Driving Adapters (UI / CLI)"]
        Components["Vue / React / Angular SFCs"]
        CLI["CLI Commands"]
    end

    subgraph App ["Application Layer"]
        UseCases["Use Cases & Application Services"]
        Ports["Port Interfaces (Contracts)"]
    end

    subgraph Domain ["Domain Layer (Pure)"]
        Entities["Entities & Value Objects"]
        Policies["Domain Rules & Policies"]
    end

    subgraph Infra ["Driven Adapters (Infrastructure)"]
        HttpAdapter["HTTP / REST Client"]
        StorageAdapter["IndexedDB / Disk / Database"]
        ExtensionAdapter["Browser Extension API"]
    end

    Components --> UseCases
    CLI --> UseCases
    UseCases --> Domain
    UseCases --> Ports
    HttpAdapter -.->|implements| Ports
    StorageAdapter -.->|implements| Ports
    ExtensionAdapter -.->|implements| Ports
```

---

## 3. Companion API Contracts (`<entity>.api.md`)

Every shared port, entity, or domain service must have a companion contract:
- File name: `<name>.api.md` (adjacent to `<name>.ts` or `<name>.vue`)
- Strict line limit: ≤ 60 physical lines.
- Purpose: AI agents read this concise API summary in 1 tool call instead of parsing entire implementation files.
