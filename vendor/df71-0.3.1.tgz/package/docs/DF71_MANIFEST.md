# DF71: The Dark Factory 7-1 Manifest

> **Core Axiom**: *Measure 7 times on paper, cut 1 time in code.*

`df71` (Dark Factory 7-1) is an autonomous engineering harness designed to constrain AI agents and human developers alike. It enforces architectural discipline, eliminates codebase degradation, and prevents hallucinations by demanding 7 rigorous pre-checks before code is accepted.

---

## The 7 Measures (Measure 7 Times)

Before modifying or committing code, every agent and developer must satisfy the 7 rings of defense:

1. **Spec Identification (`Requirement: <ID>`)**:
   Every code change must trace back to an active living requirement from `openspec/`. Unspecified feature additions are rejected.

2. **Architecture Blueprint On Paper**:
   Before writing code, plan the complete file tree, class relationships, and line budgets using `templates/architecture-blueprint.md`. Find design flaws before wasting tokens on implementation.

3. **Catalog Discovery & Primitive Reuse (`df71 discover`)**:
   Never invent duplicate utilities or unapproved primitives. Agents must query `df71 discover --query <Entity>` to locate existing approved domain entities and shared components.

4. **Strict Hexagonal Boundaries (Ports & Adapters)**:
   The domain layer must remain pure (zero framework, database, or UI imports). UI talks only to Application Use Cases; external dependencies implement driven ports.

5. **Mandatory Companion Entity API Contracts (`<entity>.api.md`)**:
   Every shared component or service must maintain a concise adjacent contract (≤ 60 physical lines) documenting public props, methods, and a 3-line copy-paste snippet. Agents read this file in 1 single call instead of loading heavy implementations.

6. **Physical Line Budgets & Headroom (Hard Caps)**:
   Files must strictly respect their physical size caps (SFC ≤ 180, Composable ≤ 80, Adapter ≤ 220, Test ≤ 240). Reaching 80% capacity mandates decomposition before adding new logic.

7. **Environment Pinning & Verified Evidence (`make env`, `make test`, `CLEAN`)**:
   Runtime toolchains must be verified via `make env`. Tests must run green and produce valid evidence hashes before merge-gate authorization.

---

## The 1 Cut (Cut 1 Time)

- **Single, Flawless, Production-Ready Commit**:
  Because all architecture, types, budgets, and dependencies were measured 7 times, the resulting code compiles cleanly, passes all gates, and merges without regression.

```bash
# Standard workflow
df71 init      # Bootstrap stack, STACK.md, Makefile
df71 sync      # Synchronize rules into AGENTS.md
make check     # Run line budgets, tests, and static policies
df71 harness   # Execute fail-closed dark factory pipeline
```
