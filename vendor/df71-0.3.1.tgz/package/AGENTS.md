# AGENTS.md — OpenSpec Factory Kit

English only. This file is the **in-package agent description** for `@viafactory/kit`
and for work inside `viafactory/packages/kit` (legacy GitHub repo `dark-factory` is archived).

Process source of truth (living OpenSpec in this repo):

- `openspec/specs/dark-factory/spec.md`
- `openspec/specs/factory-kit/spec.md`

Cursor rules/skills under `templates/cursor/` are projections of those modules.

---

## What this package is

Brand-free, portable **dark factory** tooling:

1. CLI harness (`factory harness`) driven by consumer `factory.config.yaml`
2. Stack-agnostic builtins (`openspec-validate`, `living-spec-guard`, `factory-evidence-check`, `agent-docs-map-check`)
3. Automation levels L0–L2 (default **L1**: humans merge)
4. Kit-owned evidence Model allowlist for exact `*-fast` slugs
5. Templates for Cursor projections, GitHub labels, optional Langfuse hooks, openspec-flow

Product stack checks (Nx, Go, Angular, domain greps) **must not** live in kit core.
Consumers invoke them only via `run:` adapters in their own config.

---

## Install (consumer repositories)

```bash
pnpm add -D @viafactory/kit
```

Fallback before npm publish is live:

```bash
pnpm add -D "@viafactory/kit@github:ivan-varabyou/viafactory#v0.1.2&path:packages/kit"
```

Minimal consumer layout:

- `factory.config.yaml` — automation, roles, stages
- `package.json` script: `"harness:check": "factory harness"`
- Product OpenSpec under `openspec/specs/<product>/`
- Optional: copy projections from `templates/cursor/` into `.cursor/`

Do **not** clone product apps from any consumer monorepo to adopt the factory.

---

## Agent edit policy

| Surface | Agent in a **consumer** repo | Agent in **this** (`viafactory`) repo |
| --- | --- | --- |
| Product code / product OpenSpec | Allowed when Task `#N` cites a living `### Requirement:` | N/A |
| Consumer `factory.config.yaml` / `run:` adapters | Allowed for that consumer Task | N/A |
| Synced Cursor projections from kit templates | Prefer regenerating from kit version; avoid silent drift | Edit templates here via OpenSpec + PR |
| `@viafactory/kit` sources in `node_modules` | **Forbidden** | N/A |
| Kit CLI, builtins, evidence allowlist, process specs | **Forbidden in consumer** — open upstream PR here | Allowed only via OpenSpec change → Task → PR |
| Living `dark-factory` / `factory-kit` specs | Cite kit version; do not maintain a second conflicting SoT | Change only via `openspec/changes/<name>/` then archive |

Raising `automation.level` to **L2** requires explicit consumer config plus living L2 rules.
Agents MUST NOT `gh pr merge` at L1 (default) unless the human explicitly authorizes merge for named PR(s) in the same session.

---

## Dark factory loop (portable)

1. Living OpenSpec `### Requirement:` (or propose → validate → openspec-review → archive).
2. GitHub Task `#N` with scenarios as acceptance criteria. No `#N` → no product/kit code.
3. Tests first (every scenario, including reject paths). Red before green.
4. Minimum implementation.
5. `factory harness` / consumer `pnpm harness:check` until green.
6. Open or update PR (`Closes #<Task>` only — never `Closes #<Story>`).
7. Role `security-review` on PR head; post blocked findings / CLEAN on GitHub.
8. Ready-for-human only when CLEAN evidence matches head SHA (`factory merge-gate` / evidence check).
9. At L1: human merges. After Task closes, close parent Story if no open child Tasks remain.

Harness MUST NOT embed an LLM review stage.

---

## Model roles

| Role | May use cheap/Composer/flash? | Notes |
| --- | --- | --- |
| `ops-cheap` | Yes | Status, log reads, rerun known harness |
| `implement` | Session default | Writes tests/code for cited Task |
| `openspec-author` | No Composer/flash as review stand-in | Drafts OpenSpec changes |
| `openspec-review` | **No** Composer/flash; `fast` only if kit-allowlisted | Before archive |
| `security-review` | **No** Composer/flash; `fast` only if kit-allowlisted | On PR head |
| `intake-triage` | Prefer high-responsibility | Map evidence → requirement or change; redact secrets |

Kit-shipped exact fast allowlist (expand only via kit semver release):

- `grok-4.7-high-fast`
- `cursor-grok-4.6-high-fast`

Consumers MAY subset; they MUST NOT invent new `*-fast` entries.

---

## Review output contract

Blocked → numbered grounded fixes only (path/requirement + verified break; unsure → omit).

Clean security-review:

```text
Factory security-review: CLEAN
SHA: <full 40-hex>
Model: <slug>
```

Clean openspec-review: `CLEAN` + Change + Model.

No praise, strengths, non-blocking notes, or empty headings.

---

## Versioning and releases

- Package semver is independent of consumer app versions.
- Config schema version is `factory.config.yaml` → `version: 1` (separate axis).
- Process breaks and allowlist expansions are documented in `CHANGELOG.md`.
- Release flow: see `RELEASE.md` (tag `vX.Y.Z` → CI → npm + GitHub Release).

Consumer upgrade:

```bash
pnpm up @viafactory/kit
# refresh projections from the installed templates if needed
pnpm harness:check
```

---

## Working in this repository

- Branch: `feat/#N-short-name` or `fix/#N-short-name`.
- Commits / PR title: `#N - feat(kit): …` (or `test` / `fix` / `docs` / `chore`).
- PR body: `Closes #<Task>` only.
- Never commit secrets, tokens, or Cursor/AI authorship trailers.
- All documentation and agent projections in this repository: **English only**.
- Labels: run `bash scripts/bootstrap-labels.sh` (see `templates/github/README.md`).

---

## Hard locks

- No product brand in the core package id.
- No hardcoded mandatory Nx / Go / Angular harness path in kit core (KIT-01).
- Default automation **L1**; L2 is opt-in and evidence-gated.
- OpenSpec remains the only source of process and kit behavior truth.

## Discovery before implementation

For every code task, run `factory discover --query <entity-or-capability>` and inspect relevant existing contracts/consumers before creating components, services or engines. Read [project navigation](../../docs/agents/architecture/project-navigation.md) and use the [navigation skill](../../.agents/skills/project-navigation/SKILL.md). `factory.project.json` is the curated ownership/readiness source; a candidate is not approved. `factory project-check` is enforced by the harness across configured package sources, including kit. Update catalog references when moving public entities.
