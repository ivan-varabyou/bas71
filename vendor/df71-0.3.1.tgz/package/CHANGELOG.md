# Changelog

## Unreleased

- Add read-only project discovery and fail-closed source/catalog policies (Task #184).
- Ship opt-in Angular architecture adapter, source policy/navigation templates; core remains framework-independent.
- Consumers explicitly adopt factory.project.json and a project-check harness stage; no automatic policy migration or release.

All notable changes to `@viafactory/kit` are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Changed

- Release publishes `@ivan-varabyou/kit` to GitHub Packages (public package, private repo). Consumers alias `@viafactory/kit` → `npm:@ivan-varabyou/kit@x.y.z`.

## [0.2.1] - 2026-10-04

### Added

- Builtin `agent-docs-map-check` (KIT-DOC-*): fail closed if root `AGENTS.md` lacks markdown links to the five default `docs/agents/**` layers; `agentDocs.requiredLinks` is additive only.
- Templates under `templates/docs/agents/` for architecture, backend, apps, factory, acceptance.
- Living OpenSpec module `agent-docs` (portable hierarchical English AGENTS map).

## [0.2.0] - 2026-10-04

### Changed

- **Breaking:** package renamed `@openspec-factory/kit` → `@viafactory/kit`.
- Canonical home: `ivan-varabyou/viafactory` (`packages/kit`). Former `viaplatform` repo renamed.
- Install: `pnpm add -D "@viafactory/kit@github:ivan-varabyou/viafactory#v0.2.0&path:packages/kit"`
- Legacy `dark-factory` repo is **archived**; pin only `viafactory`. Historical `v0.1.x` tags remain on the archive for archaeology.

## [0.1.2] - 2026-10-03

### Fixed

- Ship prebuilt `dist/` in git tags so consumers can install via `github:…#vX.Y.Z` without pnpm `prepare` / allowBuilds friction.
- Remove `prepare` script (npm `prepublishOnly` still builds on registry publish).

## [0.1.1] - 2026-10-03

### Fixed

- Add `prepare` script so git installs (`github:…#vX.Y.Z`) build `dist/` for the `factory` CLI.

### Changed

- Repository visibility: public (KIT-03 install without cross-repo token).

## [0.1.0] - 2026-10-03

### Added

- Initial portable kit extracted from CrabStamp `packages/factory-kit`:
  - CLI: `factory harness`, `factory merge-gate`
  - Builtins: `openspec-validate`, `living-spec-guard`, `factory-evidence-check`
  - Config schema `factory.config.yaml` (`version: 1`)
  - Automation levels L0–L2 (default L1)
  - Kit-owned evidence fast allowlist
  - Optional Langfuse hook templates
  - openspec-flow install docs
  - Unit tests for KIT-01 … KIT-10 and observability non-blocking behavior

[Unreleased]: https://github.com/ivan-varabyou/viafactory/compare/v0.2.0...HEAD
[0.2.0]: https://github.com/ivan-varabyou/viafactory/releases/tag/v0.2.0
[0.1.2]: https://github.com/ivan-varabyou/dark-factory/releases/tag/v0.1.2
[0.1.1]: https://github.com/ivan-varabyou/dark-factory/releases/tag/v0.1.1
[0.1.0]: https://github.com/ivan-varabyou/dark-factory/releases/tag/v0.1.0
