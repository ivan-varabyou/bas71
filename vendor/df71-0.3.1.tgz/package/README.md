# df71 (Dark Factory 7-1)

> **"Measure 7 times on paper, cut 1 time in code."**  
> *Autonomous engineering harness for strict architectural discipline, stack neutrality, and AI agent constraints.*

[![License](https://img.shields.io/badge/license-Apache--2.0-blue.svg)](./LICENSE)
[![Russian Docs](https://img.shields.io/badge/docs-Русский-green.svg)](./README.ru.md)
[![Manifest](https://img.shields.io/badge/manifest-DF71-orange.svg)](./docs/DF71_MANIFEST.md)

---

## What is DF71?

`df71` transforms codebases into self-policing Dark Factories. It eliminates codebase degradation and agent hallucinations through 7 rigorous pre-checks before code is accepted.

### The 7 Measures (Measure 7 Times)
1. **Spec Identification**: Every change links to an active OpenSpec (`Requirement: <ID>`).
2. **Architecture Blueprint**: Review file trees, ports, and line budgets on paper before coding.
3. **Catalog Discovery**: Reuse approved primitives via `df71 discover` instead of writing duplicates.
4. **Hexagonal Boundaries**: Domain is pure; UI talks to use cases; infra implements ports.
5. **Companion Contracts**: Shared entities have adjacent `<entity>.api.md` (≤ 60 lines).
6. **Physical Line Budgets**: Hard physical line limits per file type (e.g. SFC ≤ 180, Composable ≤ 80).
7. **Environment Pinning & Evidence**: Verified via universal Makefile (`make env`, `make test`, `CLEAN`).

---

## Installation & Make Façade

```bash
npm install --save-dev df71   # or: pnpm add -D df71
```

Aliases provided: `df71`, `harness71`, `factory`.

Standard commands:
```bash
make env      # Verify & pin toolchains (node, pnpm, go, rust, etc.)
make dev      # Start local development server / watch mode
make test     # Run fast unit/integration test suites
make check    # Run linters, types, and line budget checks
make harness  # Execute fail-closed dark factory pipeline
make clean    # Remove build artifacts and temporary files
```

---

## Quick Start

```bash
npx df71 init      # 1. Initialize DF71 in repo (creates STACK.md & Makefile)
npx df71 sync      # 2. Synchronize Dark Factory rules into AGENTS.md
npx df71 discover  # 3. Discover reusable primitives (--query <Entity>)
make check         # 4. Verify line budgets and living spec invariants
npx df71 harness   # 5. Run dark factory harness pipeline
```

---

## Supported Stacks

`df71` ships built-in adapters with zero lock-in:
- **Vue 3 TypeScript** (SFC ≤ 180, Composables ≤ 80, Vitest)
- **React TypeScript** (Components ≤ 180, Hooks ≤ 80)
- **Angular TypeScript** (Components ≤ 180, Services ≤ 160)
- **Go Engine** (Modules, pkgs, race detector, golangci-lint)
- **Rust Cargo** (Crates, clippy, cargo test)
- **Python** (Pytest, ruff, mypy)
- **Generic** (Configurable for custom toolchains)

---

## Automation Levels

| Level | Description |
| --- | --- |
| `L0` | Advise-only; humans drive; no automated bot merges. |
| `L1` (default) | Agents open PRs with verified test evidence; humans merge. |
| `L2` (opt-in) | Bot may merge only when harness is green + CLEAN evidence on head SHA. |

Unset `automation.level` means **L1**. L2 is never the template default.
Merge-on-green without L2 is **forbidden** (agents MUST NOT treat green checks alone as merge success).

```bash
pnpm exec factory merge-gate --head-sha <40hex> --harness-exit <n> \
  --evidence-file ./evidence.txt --citation-file ./pr-body.txt
```

Optional openspec-flow conveyor (non-parallel with dark-factory): see
[`templates/openspec-flow/INSTALL.md`](./templates/openspec-flow/INSTALL.md).

See [DF71 Manifest](./docs/DF71_MANIFEST.md) and [Ports & Adapters](./docs/ARCHITECTURE_PORTS_AND_ADAPTERS.md).
