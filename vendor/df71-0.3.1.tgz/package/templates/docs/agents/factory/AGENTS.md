# Factory (agent layer)

Purpose: dark-factory process projection for this repository.

**OpenSpec (process SoT):** `openspec/specs/dark-factory/spec.md`  
**OpenSpec (kit):** Viafactory `openspec/specs/factory-kit/spec.md` / pin `@viafactory/kit`  
**OpenSpec (agent-docs):** Viafactory `openspec/specs/agent-docs/spec.md`

**Up:** [root AGENTS.md](../../../AGENTS.md)

Default Automation Level **L1** — humans merge; agents MUST NOT `gh pr merge` unless the human explicitly authorizes merge for named PR(s) in the same session.
English only.
