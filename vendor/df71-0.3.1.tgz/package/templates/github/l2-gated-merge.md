# Optional L2 gated merge (opt-in only)

**Not enabled by default.** Fresh kit templates use `automation.level: L1`.
Do not copy this into a consumer until that consumer has archived OpenSpec
allowing L2 and sets `automation.level: L2` explicitly.

At L1, merge-on-green is **forbidden** and MUST NOT be documented as success.

## Preconditions (all required)

1. `factory.config.yaml` has `automation.level: L2`
2. Harness exit code `0` on the PR head SHA
3. PR body/comments contain matching CLEAN security-review evidence for that SHA
4. Task/PR cites a living `### Requirement:`

## Suggested workflow steps (consumer-owned)

Pass the **real** exit code from the prior `factory harness` step into
`--harness-exit`. Never hardcode `0` — omit or assume-green is refused at L2.

```yaml
# .github/workflows/factory-l2-merge.yml  (ONLY after L2 is explicitly enabled)
- name: Factory harness
  id: factory_harness
  continue-on-error: true
  run: pnpm exec factory harness

- name: Factory L2 merge gate
  env:
    # Map step outcome to an integer exit for merge-gate (required; never assume 0).
    HARNESS_EXIT: ${{ steps.factory_harness.outcome == 'success' && '0' || '1' }}
  run: |
    pnpm exec factory merge-gate \
      --head-sha "${{ github.event.pull_request.head.sha }}" \
      --harness-exit "$HARNESS_EXIT" \
      --evidence-file ./pr-evidence.txt \
      --citation-file ./pr-body.txt
# Non-zero exit → do not merge. Zero → gated bot MAY merge.
```

CrabStamp and other L1 consumers MUST NOT install this as merge-on-green.
