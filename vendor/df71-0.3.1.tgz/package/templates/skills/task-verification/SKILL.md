---
name: task-verification
description: Protocol for defining Use Cases, verifying task execution with mandatory E2E click-through testing, auto-fixing regressions, and generating a Task Verification Report.
---

# Task Verification & Dark Factory Acceptance Protocol (`donor-acceptance-gate`)

This skill governs how tasks and features are specified, tested with deterministic automated gates, auto-fixed, and reported across all projects.

---

## 0. FUNDAMENTAL PRINCIPLE: DONOR IS THE GROUND TRUTH FOR BEHAVIOR

1. **Donor is the Single Source of Truth (SSOT)**: The donor web application is the reference of BOTH layout and behavior, not merely static screenshots.
2. **Pre-Generated Automated Behavior Specs**: Tests are compiled automatically from donor snapshots and inventories (`docs/agents/apps/strapi-snapshot/` or live crawling via `app-snapshot`) **AHEAD OF TIME**, before feature implementation. Agents DO NOT author subjective pass-through tests to validate their own code.
3. **No Fixing "By Eye"**: Fixing "by looking at a screenshot" or improvising UI mocks is **STRICTLY PROHIBITED**. Agents fix strictly in response to failing assertions in `results/report.md`.
4. **Deterministic Status "DONE"**: Status "DONE" can NEVER be declared verbally, manually, or via commit messages by an agent. Status "DONE" is ONLY granted when the acceptance gate exits with code 0 (`[PASS]`).
5. **Gate Integrity**: Modifying `config.json`, `spec/`, `tests/`, or gate assertions to make a failing test pass is forbidden.

---

## 1. THE 4-STAGE ACCEPTANCE PIPELINE (`pnpm verify`)

Every task and pull request must execute `pnpm --filter @viafactory/donor-acceptance-gate verify` (or root `pnpm verify`):

```
┌────────────────────────────────────────────────────────────────────────┐
│ Stage 1: Static Stubscan (Ast/Regex Scan)                             │
│ - Zero tolerance for non-functional UI or placeholder logic           │
│ - Fails on: href="#", empty handlers () => {}, console.log-only,       │
│   preventDefault-only, TODO/FIXME, "stub", "noop", "coming soon"       │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ PASS
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│ Stage 2: Multi-Viewport Matrix & Mobile-First Checks                   │
│ - Viewports: m360, m390, t768 (mobile-first) AND d1024, d1440 (desktop)│
│ - Asserts: scrollWidth <= clientWidth (no unwanted horizontal scroll) │
│ - Asserts: no DOM elements overflowing beyond viewport width           │
│ - Asserts: touch-target >= 44px on mobile/tablet viewports             │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ PASS
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│ Stage 3: Interactive Element Coverage & Visual Pixel Diff              │
│ - 100% of donor interactive elements from spec must exist & be visible │
│ - Missing or hidden elements = FAIL                                    │
│ - Untested / rogue interactive elements absent from donor = FAIL       │
│ - Pixel diff vs donor screenshot within threshold (default <= 8%)      │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ PASS
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│ Stage 4: Behavior Probes & Action Reaction Parity                      │
│ - Each interactive element is probed (click, input, select)            │
│ - Asserts observable effect parity with donor:                         │
│   * Navigation: target route matches donor                             │
│   * Modals/Dialogs: opening dialog/drawer matches donor                │
│   * State/ARIA: aria-expanded / DOM mutations match donor              │
│   * Network: triggers expected API request                             │
│ - Dead zones (clicking produces zero effect where donor reacts) = FAIL │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ PASS
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│ Stage 5: Acceptance Gate Verdict (results/report.md)                   │
│ - Exit Code 0 = ACCEPTED / PASS                                        │
│ - Exit Code 1 = REJECTED / FAIL (blocks status "done" and merge)       │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 2. PHASE 0: PRE-TASK PREPARATION & REUSABILITY DISCOVERY (MANDATORY BEFORE ANY CODING)

Before writing any new component, template, or service:
1. **Run Architectural Advisor**:
   ```bash
   pnpm --filter @viafactory/admin-platform arch:advisor
   ```
2. **Audit Shared Catalog (`@ui/shared` under prefix `vf-*`)**:
   - Check existing reusable atoms, molecules, and dialogs before writing custom HTML or classes:
     - Buttons: `<vf-button variant="primary|secondary|tertiary|danger|ghost|success">`
     - Status badges: `<vf-status-badge tone="published|draft|modified|active|error">`
     - Search inputs: `<vf-search-input>` (with debounce, clear trigger, keyboard shortcuts)
     - Data tables: `<vf-data-table>` (with sorting, column toggle, bulk select, actions)
     - Pagination: `<vf-pagination>` (page size, counter, navigation buttons)
     - Modals & Drawers: `<vf-modal-dialog>`, `<vf-column-config-dialog>`, `<vf-media-picker-modal>`
     - Subnav & Filters: `<vf-subnav>`, `<vf-filter-builder>`
   - **Rule of 2**: If an element or dialog pattern is needed across >= 2 pages or views, it MUST live in `@ui/shared` under prefix `vf-*` (never page-private).
3. **Audit Contracts & Ports (`@ui/contracts`)**:
   - Check existing ports (`ContentManagerClientPort`, `ContentManagerStatePort`), event bus topics (`EventBusService`), and shared entity contracts before creating ad-hoc state or network calls.
4. **Architectural Boundaries**:
   - UI code lives in `packages/admin-platform/src/frontend/` (`shared/`, `contracts/`, `features/`, `pages/`).
   - Host backend lives in `packages/admin-platform/src/host/` (Node 24 port 1338) and Crabstamp backend in `crabstamp/backend/`.

---

## 3. PHASE 1: RED STAGE FORMULATION & SPEC HYDRATION

At the **kickoff of every task** (BEFORE modifying implementation code):
1. **Spec Hydration / Compilation**:
   - Ensure the donor behavior spec is present under `packages/donor-acceptance-gate/spec/<page>/<viewport>.json`.
   - If using existing snapshots: run `pnpm --filter @viafactory/donor-acceptance-gate hydrate`.
   - If donor is running live: run `pnpm --filter @viafactory/donor-acceptance-gate crawl`.
2. **Audit Interactive Element Inventory**:
   - Inspect the generated spec elements: buttons, search inputs, filter toggles, checkboxes, table rows, drawers, modals.
3. **Formulate Explicit Use Cases**:
   - Map each interactive element in the task to its expected action and effect.
4. **Mandatory Zero-Stub Verification**:
   - Ensure every element planned for the UI is wired to real functional logic (API mutation, signal store update, or router navigation). Fake stubs are strictly rejected by `stubscan`.

---

## 4. CLEAN CODE, ARCHITECTURE & NAMING STANDARDS (SOLID & DRY)

During all implementation and refactoring phases, agents MUST strictly adhere to:
- **Readable Like a Book**: Code structure must be self-documenting and elegant.
- **Explicit Naming (ABSOLUTELY NO Cryptic Abbreviations)**:
  - All constants, variables, functions, interfaces, parameters, and component names MUST be fully spelled out.
  - **Forbidden**: `cm`, `subnav`, `ctb`, `btn`, `fn`, `idx`, `opts`, `batchDel`, `actKey`, `id_val`, `acc`.
  - **Required**: `contentManagerTableComponent`, `subNavigationMenuComponent`, `contentTypeBuilderService`, `filterAttributeOptions`, `executeBatchDeleteAction`, `activeContentTypeKey`.
- **DRY & SOLID Principles**:
  - Single Responsibility: One component per folder, separate `.component.html`, `.component.css`, `.component.ts`.
  - Don't Repeat Yourself: Extract reusable pure functions and contract interfaces.
- **Zero Inline Comments**:
  - Code must express intent through explicit naming and structure; comments explaining lines of code are prohibited.

---

## 5. AUTO-FIX LOOP & TASK ACCEPTANCE

1. **Run Verification**:
   ```bash
   export PATH="/home/express/.nvm/versions/node/v24.15.0/bin:/home/express/.local/share/pnpm/bin:$PATH"
   pnpm test
   pnpm verify
   pnpm harness:check
   ```
2. **If any gate stage fails**:
   - Open `packages/donor-acceptance-gate/results/report.md` (and screenshot diffs in `packages/donor-acceptance-gate/results/*.diff.png`).
   - Read the exact failing findings (e.g. `[missing-element]`, `[touch-target]`, `[hscroll]`, `[dead-zone]`, `[stub]`).
   - Fix ONLY what is reported in the failing findings.
   - Re-run `pnpm verify` until `report.md` shows `Dark Factory acceptance: PASS` and exits with code 0.

---

## 6. TASK VERIFICATION REPORT GENERATION

At the conclusion of verification, output a structured report artifact named `task_verification_report.md`:

```markdown
# 📋 Task Verification Report: [Task Title / ID]

> **Status**: [PASSED / IN_PROGRESS / BLOCKED]
> **OpenSpec Ref**: `openspec/specs/.../spec.md`
> **donor-acceptance-gate Verdict**: PASS (Exit Code 0)

---

### 1. Formulated Use Cases & Donor Element Coverage
- [x] UC-01: [Interactive element / button navigation verified]
- [x] UC-02: [Search & filter popovers with functional reactivity]
- [x] UC-03: [Batch actions / modal dialogs with real API integration]

### 2. donor-acceptance-gate Acceptance Verification Results
| Page | Viewport | Probed/Elements | Pixel Diff | Fails | Status |
|---|---|---|---|---|---|
| /admin/login | d1440 | 8/8 | 0.0% | 0 | PASS |
| /admin/content-manager | d1440 | 23/23 | 2.1% | 0 | PASS |
| /admin/content-manager | m390 | 23/23 | 3.4% | 0 | PASS |

- ✅ **Stubscan**: 0 stubs found in code (no empty handlers, no TODOs, no preventDefault-only).
- ✅ **Layout Checks**: scrollWidth <= clientWidth, no horizontal overflow, touch targets >= 44px.
- ✅ **Behavior Probe**: 100% of probed elements exhibited matching donor effects.

### 3. Issues Discovered & Fixes Applied
| Issue Description | Root Cause | Fix Applied | Status |
| --- | --- | --- | --- |
| E.g. Filter button dead zone | Missing event binding | Bound to openFilterPopover method | Fixed |

### 4. Remaining Action Items / Next Tasks
- [Next scheduled task from OpenSpec]
```
