<!-- df71:rules:start -->
## Dark Factory Rules (Generic Project) [df71]
- All handwritten source files must adhere strictly to physical line limits.
- Universal Make Façade: use `make env`, `make dev`, `make test`, `make df71:check`.
- Pre-task Git Hygiene: run `df71 stage-check --pre-task` before any task; stage must be clean with zero temp/secret/screenshot files.
- Companion API contracts: shared entities/components should have a companion `<name>.api.md` (≤ 60 lines) documenting public contract so agents minimize read calls.
### Project Architecture & Rules
- Keep all handwritten source files ≤ 220 physical lines.
- Always run tests and df71:check before committing.
- Ensure all environment variables are documented in .env.example.
- Dev mode: use `make dev` to run the local server.
<!-- df71:rules:end -->

# AGENTS.md — df71 Dark Factory Kit

English is the primary documentation language. Russian companion files carry the `.ru.md` suffix (`AGENTS.ru.md`).

Package: [`df71`](https://github.com/ivan-varabyou/df71)  
Living OpenSpec source of truth:
- `openspec/specs/dark-factory/spec.md` — lifecycle process
- `openspec/specs/factory-kit/spec.md` — CLI and dark factory contract

Templates for Cursor, GitHub labels, and optional Langfuse hooks are under `templates/`.

---

## What this package is: Dark Factory (Not a "Harness")

Brand-free, stack-agnostic **Dark Factory** framework. We distinguish a Dark Factory from a simple "test harness":
- A harness merely runs tests over existing code.
- A **Dark Factory** is a complete software manufacturing discipline with 7 quality gates enforced before and during code authoring ("Measure 7 times on paper, cut 1 time in code").

Any repository can adopt it:
1. Universal Make Façade & verification gate (`make df71:check` / `df71 check`)
2. Stack-agnostic builtins (`openspec-validate`, `living-spec-guard`, `factory-evidence-check`, `agent-docs-map-check`, `line-budget-check`)
3. Automation levels L0–L2 (default **L1**: humans merge)
4. Kit-owned evidence Model allowlist for exact `*-fast` slugs
5. Stack adapters for Vue 3 TS, React TS, Angular TS, Go, Rust, Python, Generic
6. Templates for Cursor projections, GitHub labels, optional Langfuse hooks, openspec-flow
7. Companion Entity API Contracts (`<entity>.api.md` ≤ 60 lines) next to shared components

Product-specific stack checks (CI scripts, domain greps) **must not** live in kit core.
Consumers invoke them only via `run:` adapters in their own config.

---

## Dark Factory Philosophy: Mechanical Constraints Over Prompt Words

Motto: **"Measure 7 times in mechanical gates, cut 1 time in code"**.
- Agents are NOT constrained by text prompts or verbal agreements — agents hallucinate and bypass soft rules.
- Agents are constrained strictly by **fail-closed automated gates** (compilers, linters, physical line budget counters, git hygiene scanners, and typecheckers) configured for the project's stack.
- If code violates a constraint, the build fails mechanically (`exitCode != 0`). Zero subjective negotiation.

## Self-Learning Feedback Loop: Upstream vs Project Customization

The Dark Factory self-learns and continuously hardens its constraints when defects, edge cases, or agent bypasses are discovered:

1. **Systemic / Universal Learnings (Upstream `df71`)**:
   - If an issue is applicable across repositories (e.g. agent git hygiene bypasses, secrets leakage, test screenshot junk, universal line budget bloat, missing contract validations):
   - It MUST be codified as an automated test and builtin check inside **`df71`**.
   - After testing (`make df71:check`), a new semver release of `df71` is published.
   - Run `df71 fleet-sync` (or project `autoSync`) so ALL projects across the fleet immediately inherit the fix and guardrail.

2. **Domain / Project-Specific Learnings (Local Customization)**:
   - If an issue is specific to a single product domain, database schema, or custom pipeline (e.g. a specific SQL invariant or custom migration script):
   - It MUST NOT pollute `df71` core.
   - It is codified locally on that project in `factory.project.json` (policies, scopes) or as a custom stage in `factory.config.yaml` (`run: "bash scripts/..."`).

---

## Install (consumer repositories)

```bash
npm install --save-dev df71
# or:
pnpm add -D df71
```

Aliases: `df71`, `factory`, `harness71` (backward-compatibility).

Minimal consumer layout:
- `factory.config.yaml` — automation level, stages
- `Makefile` with `df71:check` and `check` targets
- `package.json` script: `"df71:check": "df71 check"`
- Product OpenSpec under `openspec/specs/<product>/`
- Optional: copy projections from `templates/cursor/` into `.cursor/`

---

## Agent edit policy

| Surface | Agent in a **consumer** repo | Agent in **df71** repo |
| --- | --- | --- |
| Product code / product OpenSpec | Allowed when Task `#N` cites a living `### Requirement:` | N/A |
| Consumer `factory.config.yaml` / `run:` adapters | Allowed for that consumer Task | N/A |
| Synced Cursor projections from kit templates | Prefer regenerating via `df71 sync`; avoid silent drift | Edit templates here via OpenSpec + PR |
| `df71` sources in `node_modules` | **Forbidden** | N/A |
| Kit CLI, builtins, evidence allowlist, process specs | **Forbidden in consumer** — open upstream PR here | Allowed only via OpenSpec change → Task → PR |
| Living `dark-factory` / `factory-kit` specs | Cite kit version; do not maintain a second conflicting SoT | Change only via `openspec/changes/<name>/` then archive |

Raising `automation.level` to **L2** requires explicit consumer config plus living L2 rules.
Agents MUST NOT `gh pr merge` at L1 (default) unless the human explicitly authorizes merge for named PR(s) in the same session.

---

## Dark factory loop (portable)

0. **Pre-task Stage & Hygiene Gate**: run `make stage-check` (or `df71 stage-check --pre-task`). Verify git stage is clean (commit prior task or clean/stash) with zero garbage (no temp files, secrets `.env`, or screenshots).
1. Living OpenSpec `### Requirement:` (or propose → validate → openspec-review → archive).
2. GitHub Task `#N` with scenarios as acceptance criteria. No `#N` → no code.
3. Tests first (every scenario, including reject paths). Red before green.
4. Minimum implementation.
5. `make df71:check` / `pnpm run df71:check` until green.
6. Open or update PR (`Closes #<Task>` only — never `Closes #<Story>`).
7. Role `security-review` on PR head; post blocked findings / CLEAN on GitHub.
8. Ready-for-human only when CLEAN evidence matches head SHA (`df71 merge-gate`).
9. At L1: human merges. After Task closes, close parent Story if no open child Tasks remain.

Verification gates MUST NOT embed an LLM review stage.

---

## Dual Development Streams: Features (Ideas) vs Bugs (Issues)

Agents operate in one of two standardized execution streams:

```mermaid
flowchart TD
    subgraph StreamA["Stream 1: Feature Stream (Idea / Spec-Driven)"]
        A1["1. Problem / Idea Formulation"] --> A2["2. OpenSpec Proposal (openspec/changes/<name>/)"]
        A2 --> A3["3. Living Requirement in spec.md"]
        A3 --> A4["4. GitHub Story & Task #N with Scenarios"]
        A4 --> A5["5. Red-TDD -> Minimum Code -> make df71:check"]
    end

    subgraph StreamB["Stream 2: Bug Triage Stream (Issue / Defect-Driven)"]
        B1["1. User Bug Report (GitHub Issue: type:bug)"] --> B2["2. Triage & Redaction: df71 triage <ID>"]
        B2 --> B3["3. Reproducing Failing Test in src/*.test.ts"]
        B3 --> B4["4. Upstream vs Custom Check (df71 vs local project)"]
        B4 --> B5["5. Fix Defect -> make df71:check -> Closes #ID"]
    end
```

- **When building new capabilities**: Use Stream 1. No implementation code without an OpenSpec-backed Task `#N`.
- **When resolving defects or user reports**: Use Stream 2. Run `df71 triage` to find unassigned bug issues, write a reproducing test, fix, and verify.

---

## Companion Entity API Contracts

Every shared component, port, or domain service MUST have an adjacent companion contract:
- Filename: `<name>.api.md` (next to `<name>.ts` or `<name>.vue`)
- Max 60 physical lines.
- Purpose: agents read the compact contract in 1 `read_file` call, not the full implementation.

Use `templates/entity.api.md` as the starting template.

---

## Client Planning, Dev Workbench & Bottom-Up Construction

Agents planning or building new clients, frontend subsystems, or UI screens MUST follow the 5-layer Bottom-Up hierarchy:

```mermaid
flowchart TD
    S0["1. Requirements Intake\n(Exhaustive OpenSpec mapping: routes, states, data contracts)"] --> S1
    S1["2. Shared Domain Contracts\n(<name>.api.md ≤ 60 lines, ports, DTOs)"] --> S2
    S2["3. Dev Workbench (make dev)\n(Isolated Storybook/Playground with dynamic input controls)"] --> S3
    S3["4. Reusable Atoms & Molecules\n(Button, Input, Badge, TableRow — ≤ 120 lines)"] --> S4
    S4["5. Feature Organisms\n(FilterableTable, Drawer, Modal Form — ≤ 180 lines)"] --> S5
    S5["6. Screen Composition\n(Pure layout orchestration of verified entities — NO monoliths!)"]
```

### Invariants:
1. **Interactive Dev Workbench First**: Before any production screen is linked to routing, reusable components MUST be registered in a Dev Workbench (`make dev`) with interactive controls (knobs for text, props, toggles, mock data) to verify visual states under dynamic inputs.
2. **Zero Monolithic Screens**: Directly creating a 400+ line screen component without breaking down into shared atoms and molecules is **STRICTLY FORBIDDEN**.
3. **Skill Reference**: Use the `client-planning` skill (`.agents/skills/client-planning/SKILL.md`) for detailed checklists and execution.

---

## Model roles

| Role | May use cheap/flash? | Notes |
| --- | --- | --- |
| `ops-cheap` | Yes | Status, log reads, rerun known checks |
| `implement` | Session default | Writes tests/code for cited Task |
| `openspec-author` | No flash as review stand-in | Drafts OpenSpec changes |
| `openspec-review` | **No** flash; `fast` only if kit-allowlisted | Before archive |
| `security-review` | **No** flash; `fast` only if kit-allowlisted | On PR head |
| `intake-triage` | Prefer high-responsibility | Map evidence → requirement or change; redact secrets |

Kit-shipped exact fast allowlist (expand only via kit semver release):
- `grok-4.7-high-fast`
- `cursor-grok-4.6-high-fast`

Consumers MAY subset; they MUST NOT invent new `*-fast` entries.

---

## Review output contract

Blocked → numbered grounded fixes only (path/requirement + verified break; unsure → omit).

Clean security-review:
```text
Factory security-review: CLEAN
SHA: <full 40-hex>
Model: <slug>
```

Clean openspec-review: `CLEAN` + Change + Model.

No praise, strengths, non-blocking notes, or empty headings.

---

## Versioning and releases

- Package semver is independent of consumer app versions.
- Config schema version is `factory.config.yaml` → `version: 1` (separate axis).
- Process breaks and allowlist expansions are documented in `CHANGELOG.md`.
- Release flow: see `RELEASE.md` (tag `vX.Y.Z` → CI → npm + GitHub Release).

Consumer upgrade:
```bash
npm install df71@latest
df71 sync        # refresh AGENTS.md managed block
make df71:check  # verify dark factory gates still green
```

---

## Working in this repository (Developing the df71 package)

Agents modifying the `df71` repository itself MUST adhere to dogfooding principles: df71 is built with df71's own Dark Factory standards.

### Developer & Agent Interface (Make & npm)
Every agent working in this repo must use the standardized commands:
- `make env` — Verify Node.js (>=20) and pnpm (>=9) are available.
- `make stage-check` — Verify clean git stage and hygiene before a new task.
- `make test` (or `pnpm test`) — Run the Vitest test suite.
- `make lint` (or `pnpm lint`) — Run ESLint across all TypeScript sources.
- `make typecheck` (or `pnpm typecheck`) — Run TypeScript compile check (`tsc --noEmit`).
- `make build` (or `pnpm build`) — Compile TypeScript sources to `dist/`.
- `make df71:check` (or `pnpm run df71:check`) — **Primary Dark Factory Gate**: executes lint, typecheck, Vitest, and `df71 check` line-budget/policy checks.
- `make check` — Standard alias for `make df71:check`.

### 6-Step Development Cycle for df71 Code Changes
1. **Spec Requirement First**:
   - Check `openspec/specs/dark-factory/spec.md` and `openspec/specs/factory-kit/spec.md`.
   - Any new feature or behavioral change requires an OpenSpec change (`openspec/changes/<change-name>/`) or must cite an existing living `### Requirement:`.
2. **TDD — Tests in `src/*.test.ts`**:
   - Write tests first. Always include reject/fail-closed scenarios (invalid config, missing files, disallowed models).
   - Verify that tests fail before implementing changes (Red before Green).
3. **Minimum Implementation**:
   - Write the minimum necessary code in `src/` or `adapters/`.
   - Adhere strictly to hexagonal separation: core discovery and validation must remain stack-agnostic; stack adapters isolate framework specifics.
4. **Mandatory Dark Factory Gate (`make df71:check`)**:
   - Execute `make df71:check`. All linting, typing, tests, and budgets must be 100% green.
   - Run `make build` to ensure `dist/` builds cleanly.
5. **Bilingual Documentation**:
   - All documentation is maintained in both English (`.md`) and Russian (`.ru.md`).
   - If `README.md` is updated, update `README.ru.md`.
   - If `AGENTS.md` is updated, update `AGENTS.ru.md`.
6. **Git Branch & Commit Conventions**:
   - Branch: `task/<ID>-short-name`.
   - Commit / PR title: `feat(<module>): <summary>`, `Requirement: <ID>`, `Closes #<Issue>`.
   - PR body: `Closes #<Task>` only (never `Closes #<Story>`).
   - Never commit secrets, tokens, or AI authorship trailers.

---

## Hard locks

- No product brand in the core package id.
- No hardcoded mandatory Nx / Go / Angular path in kit core (KIT-01).
- Default automation **L1**; L2 is opt-in and evidence-gated.
- OpenSpec remains the only source of process and kit behavior truth.

## Discovery before implementation

For every code task, run `df71 discover --query <entity>` and inspect existing contracts before creating components, services, or engines. Read `templates/docs/agents/architecture/project-navigation.md` and use the navigation skill. `factory.project.json` is the curated ownership/readiness source; a candidate is not approved. `df71 project-check` is enforced across configured package sources. Update catalog references when moving public entities.
