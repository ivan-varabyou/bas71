# df71 — Dark Factory Kit

> **"Measure 7 times on paper, cut 1 time in code."**  
> *Stack-agnostic, brand-free autonomous Dark Factory engine for architectural discipline, line budgets, and AI agent control.*

[![License](https://img.shields.io/badge/license-Apache--2.0-blue.svg)](./LICENSE)
[![Russian Docs](https://img.shields.io/badge/docs-Russian-blue.svg)](./README.ru.md)
[![Manifest](https://img.shields.io/badge/manifest-DF71-orange.svg)](./docs/DF71_MANIFEST.md)

---

## What is DF71, and Why Dark Factory (Not a "Harness")?

We intentionally avoid calling this project merely a "harness":
- A standard **test harness** only executes test runners on code that is already written.
- **DF71 is a Dark Factory**: an end-to-end autonomous software manufacturing framework. It enforces quality, boundaries, and specifications **before** code is ever committed ("Measure 7 times in mechanical gates, cut 1 time in code"). Agents are constrained by hard automated gates (linters, typecheckers, line budgets, stage hygiene) rather than prompt text.

### The 7 Quality Gates ("Measure 7 Times in Checks")
1. **Stage Hygiene Gate**: `make stage-check` ensures a clean git stage and rejects any stray secrets (`.env`), temp files, or screenshots.
2. **Spec Identification**: Every code change must trace back to an active living OpenSpec requirement (`Requirement: <ID>`).
3. **Architecture Blueprint & Contracts**: `<entity>.api.md` (≤ 60 lines) adjacent to shared entities for single-read agent context.
4. **Catalog Discovery**: Query `df71 discover` to reuse existing approved primitives and components.
5. **Physical Line Budgets**: Hard physical line limits (SFC ≤ 180, Composable ≤ 80, Adapter ≤ 220, Test ≤ 240).
6. **Stack Toolchain Gate**: Compilers (`tsc`), linters (`eslint`, `clippy`, `golangci-lint`), and tests fail closed before merge.
7. **Environment Pinning & Evidence**: Makefile façade (`make env`, `make test`, `CLEAN evidence` matching head SHA).

### Self-Learning Feedback Loop (Upstream vs Custom)
When a defect, edge case, or agent loophole is identified on any project:
- **Systemic fixes** (useful to all projects): codified into `df71` core via tests + release, then propagated via `df71 fleet-sync`.
- **Domain-specific fixes** (specific to product logic): codified locally in `factory.project.json` or custom `run:` stages in `factory.config.yaml`.

---

## Universal Interface: Make & `df71:check`

Every project governed by DF71 operates through a standardized Make interface, with `df71:check` serving as the unified verification gate:

```bash
make env         # Verify development environment (.env, runtime dependencies)
make stage-check # Pre-task gate: verify clean git stage and reject forbidden secrets/garbage
make dev         # Start local dev server / watch mode
make test        # Run unit and integration tests
make df71:check  # Unified Dark Factory gate: lint, typecheck, tests, line budgets, and project policies
make release     # Full release lifecycle: verify, bump, tag, push, and GitHub release
make gh:init     # Bootstrap GitHub labels, milestones, and branch protection
make check       # Standard alias for make df71:check
make clean       # Clean build and test artifacts
```

### Zero-Install Standalone Usage:
Run DF71 anywhere without local installation:
```bash
npx --yes df71@latest check
npx --yes df71@latest triage
npx --yes df71@latest release

# Or install standalone binary wrapper:
curl -fsSL https://raw.githubusercontent.com/ivan-varabyou/df71/main/scripts/install.sh | bash
```

### Example Consumer `package.json` Setup:
```json
{
  "scripts": {
    "df71:check": "df71 check",
    "check": "make df71:check"
  }
}
```

---

## Quick Start (Consumer Repositories)

```bash
npm install --save-dev df71   # or: pnpm add -D df71
npx df71 init                 # 1. Detect stack, generate STACK.md, Makefile, and factory.config.yaml
npx df71 sync                 # 2. Sync dark factory rules into AGENTS.md
npx df71 discover --query Nav # 3. Search approved catalog before inventing new components
make df71:check               # 4. Verify all dark factory quality gates
```

CLI aliases: `df71`, `factory`, `harness71` (kept for backward compatibility).

---

## Developing the `df71` Package (Agent & Contributor Guide)

When working inside this repository (`df71`), the process is governed by its own Dark Factory discipline (dogfooding):

### 1. Repository Layout
- `src/` — CLI, check gates (`cli-check.ts`), pipeline runner, telemetry, and evidence verification.
- `src/adapters/` & `adapters/` — Stack adapters (Vue 3 TS, React TS, Angular TS, Go, Rust, Python, Generic).
- `templates/` — Distributed templates (`Makefile`, `factory.config.yaml`, Cursor rules, skills).
- `schemas/` — JSON Schemas for configs (`factory.config.schema.json`, `factory.project.schema.json`).
- `openspec/specs/` — Living specification source of truth (`dark-factory`, `factory-kit`).

### 2. Step-by-Step Agent Workflow
1. **Spec Anchor First**:
   - Every change must cite a living requirement in `openspec/specs/dark-factory/spec.md` or `openspec/specs/factory-kit/spec.md`, or create a proposal under `openspec/changes/<change-name>/`.
2. **TDD — Tests Before Code**:
   - Write or update tests in `src/*.test.ts`.
   - Always cover both green paths and fail-closed reject paths.
   - Verify RED before GREEN.
3. **Minimum Implementation**:
   - Implement changes in `src/` or relevant adapters.
   - Respect file line budgets and modular boundaries.
4. **Mandatory Local Gate (`make df71:check`)**:
   - Run `make df71:check` (or `pnpm run df71:check`).
   - Executes: `pnpm run lint` → `pnpm run typecheck` → `pnpm run test` → `node bin/factory.js check`.
   - Never commit or open PR if `make df71:check` fails.
5. **Build Step**:
   - Run `make build` (`pnpm run build`) to produce updated `dist/`.
6. **Bilingual Documentation**:
   - All documentation changes must be synchronized: English is primary (`README.md`, `AGENTS.md`, `docs/*.md`), Russian companion carries `.ru.md`.

---

## Supported Stacks

Out-of-the-box adapters with zero lock-in:
- **Vue 3 TypeScript** (SFC ≤ 180, Composables ≤ 80, Vitest)
- **React TypeScript** (Components ≤ 180, Hooks ≤ 80)
- **Angular TypeScript** (Components ≤ 180, Services ≤ 160)
- **Go Engine** (Modules, packages, race detector, golangci-lint)
- **Rust Cargo** (Crates, clippy, cargo test)
- **Python** (Pytest, ruff, mypy)
- **Generic** (Configurable for custom toolchains)

---

## Automation Levels

| Level | Meaning |
| --- | --- |
| `L0` | Advise-only; human-driven; no automated bot merges. |
| `L1` (default) | Agents open PRs with verified tests; **humans merge**. |
| `L2` (opt-in) | Bot MAY merge only when factory checks pass + CLEAN evidence on head SHA + explicit `automation.level: L2`. |

Merge-on-green without L2 is **strictly forbidden**.

```bash
pnpm exec factory merge-gate --head-sha <40hex> --harness-exit <n> \
  --evidence-file ./evidence.txt --citation-file ./pr-body.txt
```

Optional openspec-flow conveyor (non-parallel with dark-factory): see
[`templates/openspec-flow/INSTALL.md`](./templates/openspec-flow/INSTALL.md).

See [DF71 Manifest](./docs/DF71_MANIFEST.md) and [Ports and Adapters Architecture](./docs/ARCHITECTURE_PORTS_AND_ADAPTERS.md).
