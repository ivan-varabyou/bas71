# dark-factory Specification

## Purpose

Portable dark-factory process: OpenSpec-backed issues, TDD with reject paths, harness, open PR, then second-model security-review dialogue on GitHub (findings → fixes → CLEAN) with evidence matching head SHA before ready-for-human, merge gate defaulting to human (Automation Level L1) with opt-in gated bot merge (L2) only under living `factory-kit` rules, cost/quality model routing, and future customer intake that never invents requirements. Process SoT for agents and for copying into other repositories. Product stack locks stay in other OpenSpec modules.

## Requirements

### Requirement: Factory process source of truth
The living module `openspec/specs/dark-factory/spec.md` SHALL be the only source of truth for the dark-factory lifecycle (problem → OpenSpec → GitHub issue → TDD → harness → open PR → security-review dialogue on the PR → ready-for-human → merge gate), model routing roles, customer intake rules, and projection sync. The default merge gate is **human merge** (Automation Level L1). Automation Level L2 (opt-in, post-MVP) MAY allow a gated bot merge only under living `factory-kit` L2 rules. Chat, memory, and ad-hoc agent improvisation SHALL NOT define a parallel process. Cursor rules, skills, root/`docs/agents/**` `AGENTS.md` maps (when agent-docs is adopted), and package `AGENTS.md` files SHALL be projections that cite this module and other living OpenSpec modules they summarize. When this module changes via an archived OpenSpec change, projections SHALL be updated in the same archive PR or in a GitHub Task cut the same calendar day with label `priority:critical`.

#### Scenario: Projection cites living module
- **GIVEN** a Cursor dark-factory rule/skill or `docs/agents/factory/AGENTS.md` describes the factory lifecycle
- **WHEN** that file is inspected
- **THEN** it SHALL name `openspec/specs/dark-factory/spec.md` (in the kit/process home repository) as the process source of truth

#### Scenario: Archive without projection update is incomplete
- **GIVEN** an archived change that modifies `dark-factory`
- **WHEN** the archive PR is prepared
- **THEN** either the projections (including affected `docs/agents/**` pages when present) are updated in that PR or a Critical Task linking the archive commit is opened before the human is told the change is done

### Requirement: Work enters only through OpenSpec-backed issues
No implementation code SHALL be written without a GitHub Task `#N` that cites a living `### Requirement:` (and parent Story). If the problem is not yet a living requirement, an `openspec/changes/<name>/` SHALL be proposed, validated, reviewed per OpenSpec delta review, and archived before the Task is cut. Acceptance criteria on the Task SHALL be the requirement's `#### Scenario` lines and SHALL NOT invent behavior absent from OpenSpec.

#### Scenario: Chat request without requirement stops
- **GIVEN** a human asks to implement behavior with no living `### Requirement:`
- **WHEN** the agent starts work
- **THEN** it SHALL refuse to write product code and SHALL open or update an OpenSpec change instead

#### Scenario: Task cites requirement
- **GIVEN** a GitHub Task created from the factory
- **WHEN** its body is inspected
- **THEN** it SHALL name the OpenSpec module path and the `### Requirement:` title, and list acceptance criteria matching scenarios

### Requirement: Tests first including reject paths
For every `#### Scenario` on the Task, the agent SHALL add an automated test (unit or integration) that fails before the feature exists and passes after. Reject, empty, and boundary scenarios SHALL each have a test. A change that only covers the happy path SHALL NOT be treated as done.

#### Scenario: Reject path has a test
- **GIVEN** a requirement scenario that rejects invalid input
- **WHEN** the Task is implemented
- **THEN** a test SHALL assert that rejection before the feature is marked green

#### Scenario: Red before green
- **GIVEN** new tests for the Task scenarios
- **WHEN** they are first run against the branch without the feature
- **THEN** they SHALL fail for the missing behavior

### Requirement: Harness gate before review
`pnpm harness:check` SHALL pass (`[HARNESS PASSED]`) on the feature branch before the pre-PR security review is requested. The harness SHALL NOT embed an LLM review or nits stage.

#### Scenario: Review not started on red harness
- **GIVEN** harness exits non-zero
- **WHEN** the agent considers security review
- **THEN** it SHALL fix harness first and SHALL NOT claim the branch is ready for PR

### Requirement: Pre-PR security review by a second model
After harness is green, the writing agent SHALL open or update a GitHub pull request for the Task (`Closes #<Task>`) **before** treating the security-review loop as complete, so that review dialogue is recorded on GitHub. A **different** model from the writing session SHALL then perform one read-only **security and production-ready** review of the PR head (or branch tip that is the PR head) against the base (`main` / `origin/main`) and the cited `### Requirement:`. The review model SHALL be role `security-review` selected by **first available** slug from the consumer's priority list (living projection and/or `factory.config.yaml` roles). Blocking findings only: security, local-first, SSOT/typing, OpenSpec mismatch, contracts, hot-path SQL/performance, and other production-ready defects in those classes. Style, naming, and DRY preferences are not findings.

**If that review returns blocking findings**, the writing agent SHALL post those findings as a GitHub PR comment, fix **all** of them, rerun harness, push the fix commits to the PR branch, post a short PR comment naming the new SHA and which finding numbers were addressed (with machine-parseable implement Provider + Model attribution lines per living attribution requirement), and request **one** new security-review on the new commit SHA until CLEAN (incomplete fix sets are not done). **If the first review is CLEAN on the PR head SHA**, that CLEAN SHALL be posted on the PR and no further security-review is required. A second consecutive clean pass on an unchanged SHA is NOT required. Composer and flash models SHALL NOT fill role `security-review`. Slugs containing `fast` SHALL NOT fill that role unless the exact slug is on the **kit-owned** evidence allowlist.

The agent SHALL NOT complete the security-review→fix loop only in local chat without posting blocked findings, fix notes, and CLEAN (or quota-blocked status) as PR comments (or the PR body for the final CLEAN evidence). Review replies SHALL be terse to save tokens. A blocked review SHALL contain the verdict line `Factory security-review: BLOCKED`, then labeled lines `Provider: <id>`, `Model: <slug>`, `Role: security-review`, `SHA: <full>`, and `Outcome: BLOCKED` (preferred order), then a numbered list of items the writing agent must fix (each item names the file or requirement and the concrete change) — and SHALL NOT include praise or non-blocking commentary. A clean review SHALL contain the verdict line `Factory security-review: CLEAN` (or `CLEAN` with equivalent labeled lines), then `Provider: <id>`, `Model: <slug>`, `Role: security-review`, `SHA: <full>`, and `Outcome: CLEAN` — and SHALL NOT include filler text. Review replies SHALL NOT include praise, summaries of what is already fine, "non-blocking notes", "strengths", or empty sections. `Provider:` is the runtime that invoked the model (for example `cursor`, `anthropic`, `openrouter`, `antigravity`). Agents SHALL ensure `factory-evidence-check` can still extract matching `SHA:` and allowed `Model:` from the CLEAN evidence block (labeled parse after the Task that updates the checker; until then a temporary transitional order that keeps `SHA:` then `Model:` immediately after the verdict and still includes `Provider:` is allowed only for that transition).

Every blocking finding SHALL be **grounded**: it MUST cite a path in the reviewed diff (and line when useful) or a living/`openspec/changes` `### Requirement:` title, and state an observable break the reviewer verified. Findings MUST NOT be invented, speculative, or based on guessed code that is not in the diff. If the reviewer is unsure a defect is real, it SHALL omit the finding rather than pad the list.

#### Scenario: Writing model does not self-approve
- **GIVEN** the same model session that wrote the diff
- **WHEN** security review is required
- **THEN** that session SHALL launch a separate Task with role `security-review` and SHALL NOT treat its own judgment as a clean pass

#### Scenario: PR open before review loop completes
- **GIVEN** harness is green on the Task branch and no open PR exists yet
- **WHEN** the agent starts the security-review loop
- **THEN** it SHALL open a PR for the Task before or immediately when posting the first security-review result

#### Scenario: Blocked findings posted on the PR
- **GIVEN** security-review returns blocking findings on SHA `A` for an open PR
- **WHEN** the review completes
- **THEN** those findings SHALL appear as a GitHub PR comment naming SHA `A`, Provider id, the model slug, `Role: security-review`, and `Outcome: BLOCKED`

#### Scenario: Fix follow-up posted on the PR
- **GIVEN** blocking findings were posted on the PR for SHA `A` and the writer fixed them in commit `B`
- **WHEN** the writer requests re-review
- **THEN** it SHALL have pushed `B` to the PR branch and posted a PR comment naming SHA `B` and the addressed finding numbers

#### Scenario: Two clean passes on one SHA
- **GIVEN** the first security-review on SHA `A` returned blocking findings, and the agent fixed them in commit `B`
- **WHEN** the agent wants to mark the PR ready for human merge
- **THEN** it SHALL obtain one clean pass that names SHA `B` and SHALL post that CLEAN on the PR

#### Scenario: Flash model refused for security-review
- **GIVEN** an agent attempts to run security-review with a flash, Composer, or non-allowlisted fast slug
- **WHEN** the factory rules are applied
- **THEN** that run SHALL NOT count as a clean pass

#### Scenario: Blocked review is findings-only
- **GIVEN** security-review finds a blocking OpenSpec mismatch
- **WHEN** it returns its reply
- **THEN** the reply SHALL list that fix and SHALL NOT include a strengths section or non-blocking commentary

#### Scenario: Clean review is minimal
- **GIVEN** security-review finds no blocking issues on SHA `A`
- **WHEN** it returns its reply
- **THEN** the reply SHALL include `CLEAN` (or `Factory security-review: CLEAN`), Provider id, SHA `A`, the model slug, `Role: security-review`, and `Outcome: CLEAN`, and SHALL omit filler text and a multi-pass counter

#### Scenario: Second pass on unchanged SHA not required
- **GIVEN** the first security-review returned CLEAN on SHA `A` and no new commit exists
- **WHEN** the agent prepares the ready-for-human notification
- **THEN** it SHALL NOT run another security-review on SHA `A`

#### Scenario: Ungrounded finding is invalid
- **GIVEN** a review comment that claims a bug without citing a diff path or requirement and without an observable break
- **WHEN** the writing agent evaluates findings
- **THEN** that comment SHALL NOT count as a blocking finding

#### Scenario: Finding without citation is invalid
- **GIVEN** a review item states an observable break but cites no diff path and no `### Requirement:`
- **WHEN** the writing agent evaluates findings
- **THEN** that item SHALL NOT count as a blocking finding

#### Scenario: Finding without observable break is invalid
- **GIVEN** a review item cites a path or requirement but does not state a verified observable break
- **WHEN** the writing agent evaluates findings
- **THEN** that item SHALL NOT count as a blocking finding

#### Scenario: Unsure means omit
- **GIVEN** the reviewer suspects a possible issue but cannot verify it in the diff or cited OpenSpec
- **WHEN** composing the reply
- **THEN** the reviewer SHALL omit that item rather than list it as a finding

#### Scenario: All blocking findings must clear before CLEAN
- **GIVEN** security-review returned multiple blocking findings
- **WHEN** the writing agent claims the PR is ready for human merge
- **THEN** every listed finding SHALL be fixed and a new CLEAN pass SHALL name the new SHA and SHALL be posted on the PR

#### Scenario: Local-only review fix loop forbidden
- **GIVEN** security-review produced blocking findings
- **WHEN** the writer fixes them and later opens a PR that only contains a final CLEAN with no prior blocked/fix comments
- **THEN** that SHALL NOT satisfy this requirement's dialogue rules

### Requirement: Security review evidence on the PR
The PR body or a PR comment SHALL include an evidence block naming the reviewed commit SHA, the Provider id, and the model slug for one clean security and production-ready review. The PR body SHALL also include machine-parseable implement attribution lines:

```text
Factory implement:
Provider: <id>
Model: <slug>
```

(writing-session Provider and Model for the Task). Each security-review evidence or status comment SHALL include `Provider: <id>`, `Model: <slug>`, `Role: security-review`, `SHA: <full>`, and `Outcome: BLOCKED|CLEAN|quota` after the verdict line `Factory security-review: CLEAN|BLOCKED|quota` (preferred labeled order). The agent SHALL NOT notify the human that the PR is ready unless CLEAN evidence matches the PR head SHA. Agents SHALL NOT add workflows that `git push` from issue/PR comments at any automation level. At Automation Level L1 (default), human merge remains the merge gate: agents SHALL NOT run `gh pr merge` (including `--auto`) and SHALL NOT add workflows that merge on green checks alone, **except** when the human explicitly authorizes merge for named PR(s) in the same working session — then the agent MAY run `gh pr merge` for those authorized PR(s) only. At Automation Level L2 (opt-in only, see factory-kit), a gated bot merge MAY occur only when living L2 rules and `automation.level: L2` are satisfied. A PR MAY remain open while security-review is in progress or quota-blocked; it SHALL NOT be marked ready-for-human without matching CLEAN evidence.

#### Scenario: Ready notification requires matching SHA
- **GIVEN** evidence that names SHA `A` and the PR head is SHA `B`
- **WHEN** the agent prepares a ready-for-human message
- **THEN** it SHALL rerun security-review on `B` before that message

#### Scenario: Agent does not merge
- **GIVEN** Automation Level L1 and a green PR with clean security-review evidence and **no** explicit human merge authorization in the session
- **WHEN** the agent finishes its turn
- **THEN** it SHALL leave merge to the human and SHALL NOT invoke `gh pr merge`

#### Scenario: Agent merges when human authorizes
- **GIVEN** Automation Level L1 and a green PR with clean security-review evidence matching head SHA
- **AND** the human explicitly authorizes merge for that PR in the same working session
- **WHEN** the agent continues the factory loop
- **THEN** the agent MAY run `gh pr merge` for that authorized PR and SHALL NOT treat green checks alone as authorization

#### Scenario: Stale-session authorization is invalid
- **GIVEN** Automation Level L1 and a prior session where the human authorized merge
- **WHEN** a new working session starts without a fresh explicit authorization
- **THEN** the agent SHALL NOT invoke `gh pr merge` based on the prior session

#### Scenario: Unnamed authorization is invalid
- **GIVEN** Automation Level L1 and the human says merge is allowed without identifying the PR or current work that maps to a PR
- **WHEN** the agent considers merging
- **THEN** the agent SHALL NOT invoke `gh pr merge`

#### Scenario: Quota blocked comment on open PR
- **GIVEN** an open PR and every `security-review` slug fails due to quota
- **WHEN** the agent stops the review loop
- **THEN** it SHALL post a PR comment that includes `Role: security-review`, `Outcome: quota`, Provider id(s), and the attempted Model slug(s) as applicable, and SHALL NOT mark the PR ready-for-human

#### Scenario: PR body names implement model
- **GIVEN** a factory Task PR is opened or updated after harness green
- **WHEN** the PR body is inspected
- **THEN** it SHALL include `Factory implement:` with `Provider: <id>` and `Model: <slug>` for the writing-session runtime and model

### Requirement: OpenSpec delta review before archive
Before `openspec archive`, a read-only review with role `openspec-review` SHALL inspect the change (`proposal.md`, `design.md`, delta specs, `tasks.md`). The reviewer SHALL use a **different model family** from the change author when both are available. Default for this repo: `gpt-5.6-sol-medium` when the author was a Claude model. The review SHALL fail closed on missing scenarios, invented behavior outside the proposal, or deltas that conflict with other living specs. Archive SHALL NOT proceed until findings are fixed and the review is clean.

OpenSpec-review replies SHALL follow the same terse contract as security-review: blocked replies are a numbered fix list only; clean replies are only `CLEAN` plus enough identity to trust the pass (change name and model slug). No praise, no non-blocking section, no empty headings. Every finding SHALL cite the change file or conflicting living `### Requirement:` and state a verified observable break; speculative or unverified items SHALL be omitted.

#### Scenario: Archive blocked on open findings
- **GIVEN** openspec-review reports a missing reject-path scenario
- **WHEN** archive is attempted
- **THEN** the agent SHALL fix the change and SHALL NOT archive until a clean pass

#### Scenario: OpenSpec clean reply is minimal
- **GIVEN** openspec-review finds no blocking issues on a change
- **WHEN** it returns its reply
- **THEN** the reply SHALL be limited to a clean verdict and identity fields and SHALL NOT include filler commentary

#### Scenario: Spec review omits unverified claims
- **GIVEN** openspec-review cannot verify a suspected conflict in another living module
- **WHEN** composing the reply
- **THEN** it SHALL omit that claim rather than report it as a finding

#### Scenario: Spec finding without observable break is invalid
- **GIVEN** an openspec-review item cites a file but does not state a verified observable break
- **WHEN** the author evaluates findings
- **THEN** that item SHALL NOT count as a blocking finding

### Requirement: Model routing by responsibility
Factory steps SHALL select models by role. Role `ops-cheap` MAY run status commands, log reads, and reruns of already-known harness/tests. Role `implement` writes tests and code for a cited Task. Role `openspec-author` drafts changes. Role `openspec-review` and role `security-review` are high-responsibility and SHALL NOT use Composer or flash slugs. Slugs containing `fast` SHALL NOT fill those roles unless the exact slug is on the **kit-owned** evidence allowlist for that role. Projections MAY list current primary and fallback slugs per role; slug renames require an OpenSpec change or a projection update Task that does not weaken the role rules.

When the primary slug for `openspec-review` or `security-review` is unavailable because of quota exhaustion, provider outage, or API error, the agent SHALL attempt the next fallback slug listed for **that same role** in the projection. The agent SHALL NOT substitute role `ops-cheap` or any Composer/flash slug for those reviews. If all listed slugs for the role fail, the agent SHALL stop, report the failure to the human (and on an open PR, as a PR comment), and SHALL NOT declare a PR ready without a completed review for that role. An open PR without CLEAN evidence is allowed while waiting for quota.

#### Scenario: Cheap model may rerun harness
- **GIVEN** harness must be rerun after a one-line fix
- **WHEN** only command execution is needed
- **THEN** role `ops-cheap` MAY perform that rerun

#### Scenario: Cheap model may not security-review
- **GIVEN** pre-PR security review is required
- **WHEN** model selection runs
- **THEN** role `ops-cheap` SHALL NOT be selected

#### Scenario: Quota forces same-role fallback
- **GIVEN** the primary `security-review` slug returns a quota or unavailable error
- **WHEN** the agent retries the review
- **THEN** it SHALL use the next projection fallback for `security-review` and SHALL NOT use a flash/Composer slug

#### Scenario: All review slugs exhausted stops the factory
- **GIVEN** every listed `security-review` slug fails
- **WHEN** the agent would otherwise mark a PR ready
- **THEN** it SHALL stop and notify the human instead of skipping the review

#### Scenario: Allowlisted fast slug may security-review
- **GIVEN** slug `grok-4.7-high-fast` (or another exact kit-allowlisted id) is listed for role `security-review`
- **WHEN** higher-priority review slugs are unavailable
- **THEN** that allowlisted slug MAY produce a valid CLEAN evidence pass

### Requirement: Customer problem intake
A future intake path MAY accept customer chat text, log excerpts, and UI/support screenshots as **triage evidence** for a GitHub issue or OpenSpec change. Intake SHALL map evidence to an existing living `### Requirement:` or SHALL open/update an `openspec/changes/<name>/` proposal. Intake SHALL NOT cut an implementation Task that adds product behavior absent from OpenSpec. Secrets, credentials, session tokens, and personal data that are not required to reproduce the bug SHALL be redacted from issue bodies and from attached log text before publish. Screenshots attached to GitHub issues are support evidence only; they SHALL NOT be creative-work media for timestamping, SHALL NOT be stored in product databases, and SHALL NOT be uploaded through product media APIs (`FormData` / `File` / `Blob` to integration backends remain forbidden). If the only attachment is creative media the customer wants processed, intake SHALL refuse the product upload path and SHALL point them at the client local-first flow.

#### Scenario: Complaint without requirement opens a change
- **GIVEN** customer chat describes behavior with no living requirement
- **WHEN** intake triage completes
- **THEN** it SHALL create or update an OpenSpec change and SHALL NOT create an implementation Task for inventing that behavior

#### Scenario: Matched requirement cuts a Task
- **GIVEN** customer evidence clearly matches a living `### Requirement:` scenario
- **WHEN** intake triage completes
- **THEN** it MAY create a GitHub Task citing that requirement with evidence links and redacted logs

#### Scenario: Secrets redacted
- **GIVEN** a customer log containing an API key or password
- **WHEN** the GitHub issue body is written
- **THEN** those secret values SHALL be redacted or omitted

#### Scenario: Creative media not accepted as product upload
- **GIVEN** a customer sends only a media file they want timestamped on-chain
- **WHEN** intake triage runs
- **THEN** it SHALL refuse to send that file to any product integration API and SHALL NOT treat intake as a media upload endpoint

### Requirement: Dual development streams — feature creation and reactive bug triage
The dark factory lifecycle SHALL support two deterministic execution streams:
1. **Feature Creation Stream (Proactive / Idea-Driven)**:
   Problem or idea formulation -> OpenSpec proposal (`openspec/changes/<name>/`) -> living requirement -> Story -> child Tasks with Given-When-Then scenarios -> Red-TDD -> minimum implementation -> gate verification -> PR.
2. **Bug Triage & Maintenance Stream (Reactive / Issue-Driven)**:
   User bug report or defect issue (`type:bug`) -> triage via `df71 triage <ID>` -> secret redaction -> reproducible failing regression test in `src/*.test.ts` asserting expected fix -> OpenSpec requirement alignment -> code fix -> `make df71:check` -> PR with `Closes #<BugID>`.

Agents without an assigned feature task SHALL inspect the issue backlog via `df71 triage` (or `gh issue list --label type:bug`), reproduce the issue with a failing test, and resolve it under the same fail-closed mechanical gates.

#### Scenario: Bug triage starts with reproducing test
- **GIVEN** an open bug issue on GitHub
- **WHEN** an agent initiates triage via `df71 triage`
- **THEN** it SHALL create a reproducing test that fails on current code before modifying product implementation

#### Scenario: Bug fix closes issue
- **GIVEN** a verified bug fix PR with green harness
- **WHEN** the PR is merged
- **THEN** its body SHALL cite `Closes #<BugID>` to automatically close the tracking issue

### Requirement: Portable factory package
The `dark-factory` living spec SHALL be written so another repository can adopt it by copying `openspec/specs/dark-factory/`, projecting rules/skills, and binding model slugs for that host. Product-specific stack locks (monorepo toolchains, secrets managers, local media) remain in other modules; this module SHALL NOT hard-require product domains to state the lifecycle.

#### Scenario: Lifecycle readable without product domains
- **GIVEN** only `openspec/specs/dark-factory/spec.md`
- **WHEN** an implementer reads the factory steps
- **THEN** they SHALL be able to follow issue → TDD → harness → open PR → security-review dialogue → ready-for-human → human merge without reading `backend-anchoring`

### Requirement: External model router deferred
The Cursor-hosted factory SHALL run using the role→slug projection table and same-role fallbacks. An external multi-provider router (for example OpenRouter) MAY be introduced later for a production customer-intake or orchestration service that selects models by role outside Cursor. Until that service is specified and implemented via OpenSpec, agents SHALL NOT require OpenRouter (or equivalent) to complete issue → TDD → harness → open PR → security-review dialogue → ready-for-human. Introducing such a router SHALL NOT weaken high-responsibility role bans on Composer/flash models, and SHALL NOT accept non-allowlisted `fast` slugs for those roles.

#### Scenario: Factory runs without OpenRouter
- **GIVEN** no OpenRouter (or equivalent) integration is configured
- **WHEN** an agent executes the dark-factory loop in Cursor
- **THEN** it SHALL still be able to complete reviews using projection primary/fallback slugs

#### Scenario: Future router keeps role bans
- **GIVEN** a future production intake service routes models via an external provider API
- **WHEN** it selects a model for `security-review`
- **THEN** it SHALL still refuse Composer, flash, and non-allowlisted fast classes for that role

### Requirement: Parent Story closes when all Tasks are done
A GitHub **Story** (`type:story`) SHALL remain open while any open GitHub **Task** (`type:task`) cites that Story as its parent. When the last such Task is closed (normally by merging a PR whose body contains `Closes #<Task>` into `main`), the Story SHALL be closed with `gh issue close` and a short comment that lists the completed child Task numbers discoverable via `gh` for that parent. Agents SHALL NOT leave a fully-delivered Story open once they observe that no open child Tasks remain. Closing a Story with `gh issue close` is allowed and is **not** a PR merge. At Automation Level L1, agents SHALL NOT run `gh pr merge` (including `--auto`) under this requirement **unless** the human explicitly authorized merge for that PR in the same working session (see Security review evidence on the PR). At Automation Level L2, a gated bot merge MAY run only under living `factory-kit` L2 rules. A Story SHALL NOT be closed while any open Task still cites it as parent. Task PR bodies SHALL continue to use `Closes #<Task>` only and SHALL NOT use `Closes #<Story>`.

#### Scenario: Last Task merge closes Story
- **GIVEN** Story `#S` has exactly one open child Task `#T` and a PR with `Closes #T` merges to `main`
- **WHEN** the agent observes `#T` closed and finds no other open Tasks citing `#S`
- **THEN** it SHALL close `#S` with a comment that lists `#T` and any other child Task numbers returned by `gh` for `#S`

#### Scenario: Sibling Task keeps Story open
- **GIVEN** Story `#S` has open Tasks `#T1` and `#T2`
- **WHEN** only the PR for `#T1` merges (`Closes #T1`)
- **THEN** `#S` SHALL remain open

#### Scenario: Story Closes keyword not used on Task PRs
- **GIVEN** an agent opens a PR for a Task whose parent Story still has work remaining or even when it is the last Task
- **WHEN** composing the PR body
- **THEN** the body SHALL contain `Closes #<Task>` and SHALL NOT contain `Closes #<Story>`

### Requirement: Automation level defaults to L1
Consumers of the dark-factory process SHALL default to **Automation Level L1**: agents MAY complete OpenSpec → Task → TDD → harness → open PR → security-review dialogue on the PR until CLEAN evidence matches head SHA; humans merge; agents SHALL NOT `gh pr merge` or enable merge-on-green **unless** the human explicitly authorizes merge for named PR(s) in the same working session. **L2** (gated bot merge) is post-MVP and SHALL require explicit `automation.level: L2` plus the living `factory-kit` L2 rules. Projections and kit templates SHALL NOT enable L2 by default.

#### Scenario: DF-L1 agent does not merge
- **GIVEN** Automation Level L1 (default) and no explicit human merge authorization in the session
- **WHEN** a PR is ready-for-human
- **THEN** the agent SHALL NOT merge the PR

#### Scenario: DF-L1 human-authorized merge
- **GIVEN** Automation Level L1 and explicit human merge authorization for PR `#P` in the same session
- **WHEN** `#P` has harness green and CLEAN evidence matching head SHA
- **THEN** the agent MAY merge `#P` via `gh pr merge` without enabling L2 or merge-on-green

### Requirement: Process package is the share unit
When another repository adopts this factory, it SHALL depend on the portable factory-kit package (or vendored copy at a pinned version) plus OpenSpec, rather than forking upstream product apps. Product stack locks remain outside `dark-factory` / factory-kit core.

#### Scenario: DF-KIT adopt without product apps
- **GIVEN** an adopting consumer repository
- **WHEN** it installs factory-kit and OpenSpec per kit docs
- **THEN** it SHALL be able to run builtin harness stages without cloning upstream `apps/` or `backend/`

### Requirement: Client planning and bottom-up entity workbench
When bootstrapping a new client application, feature module, or frontend subsystem, agents SHALL perform comprehensive requirements intake (user journeys, state transitions, domain entities, and data contracts) in OpenSpec BEFORE writing production screens. Implementation SHALL follow a strict bottom-up hierarchy:
1. Shared domain contracts and ports (`<entity>.api.md` ≤ 60 lines).
2. Shared reusable atoms and UI primitives (Button, Input, Badge, Dialog overlay).
3. Molecules and composite components (Form groups, Filter bars, Table rows).
4. Organisms and feature sections (Data tables, Headers, Complex modal dialogs).
5. Pages, screens, and routing (constructed ONLY from verified components).

Before assembling full production screens, projects SHALL establish an interactive **Dev Mode Entity Workbench** (or Storybook / Playground route accessible via `make dev`), where shared entities and components are rendered in isolation with interactive input controls (knobs for props, states, and mock payloads). Agents SHALL verify visual, boundary, and interactive behavior in the Dev Workbench before using components in full screen assemblies. Authoring monolithic screens directly without workbench verification of constituent entities is PROHIBITED.

#### Scenario: Full screen authoring without workbench entities stops
- **GIVEN** a new client screen or page is required
- **WHEN** an agent attempts to author the full page before underlying shared atoms and molecules are registered in the Dev Workbench
- **THEN** the gate SHALL refuse the task until constituent entities are specified, tested, and demonstrated in the Dev Workbench with interactive inputs

#### Scenario: Dev workbench allows interactive input values
- **GIVEN** a shared UI entity in the Dev Workbench
- **WHEN** the developer or agent interacts with the workbench in dev mode (`make dev`)
- **THEN** it SHALL provide input controls (text, select, toggle, mock state) to inspect and exercise the entity under varying boundary values

### Requirement: Security-review dialogue is GitHub-visible
The security-review loop for a Task PR SHALL leave an auditable comment history on that PR: each blocked review, each writer fix acknowledgment (with new SHA), and the final CLEAN (or quota-blocked stop). Each of those comments SHALL be machine-parseable with Provider, Role, Model, SHA (or New SHA for fixes), and Outcome so different providers and review models across rounds remain visible for later stats. Chat-only or worktree-only resolution without those PR comments SHALL NOT count as a completed factory security-review dialogue.

#### Scenario: DF-GH history has blocked then clean
- **GIVEN** a PR that required one fix round during security-review
- **WHEN** the PR is marked ready-for-human
- **THEN** the PR conversation SHALL include at least one BLOCKED findings comment and one later CLEAN comment naming the ready head SHA

#### Scenario: Each review round names its model and outcome
- **GIVEN** security-review round N on SHA `A` uses Provider `P` and model slug `M` and returns BLOCKED or CLEAN (or the loop stops with quota)
- **WHEN** that round is posted to the PR
- **THEN** the PR comment SHALL include `Provider: P`, `Role: security-review`, `Model: M`, `SHA: A`, and `Outcome: BLOCKED|CLEAN|quota`

#### Scenario: Writer fix comment names implement model
- **GIVEN** the writing agent pushed fix commit `B` after a blocked review
- **WHEN** it posts the fix acknowledgment on the PR
- **THEN** that comment SHALL include `Provider: <id>`, `Role: implement`, `Model: <slug>`, `New SHA: B`, and `Outcome: fix`

### Requirement: Machine-parseable factory model attribution on PRs
Factory Task PRs SHALL expose stable, greppable attribution lines so later stats can measure which **Provider** (invoking runtime) and which **Model** implemented or fixed code and which Provider/Model reviewed each round (and with what Outcome). Provider ids include at least `cursor`, `anthropic` (direct cloud), `openrouter`, and `antigravity` (or the id this consumer standardizes for that runtime). Provider is the runtime that invoked the model, so Cursor-routed Claude SHALL use `Provider: cursor` with the Cursor model slug — not `Provider: anthropic`. The PR body SHALL include:

```text
Factory implement:
Provider: <id>
Model: <slug>
```

for the Task writing session. Each security-review PR comment SHALL include after `Factory security-review: CLEAN|BLOCKED|quota` the labeled lines `Provider: <id>`, `Model: <slug>`, `Role: security-review`, `SHA: <full>`, and `Outcome: BLOCKED|CLEAN|quota` (preferred order). Each writer fix acknowledgment PR comment SHALL include lines `Provider: <id>`, `Model: <slug>`, `Role: implement`, `New SHA: <full>`, and `Outcome: fix`. Comments SHALL stay terse (no praise). Optional telemetry systems (for example Langfuse) MAY consume these lines later and are out of scope of this requirement. Omitting Provider, Role, Model, or Outcome on a review or fix round SHALL NOT satisfy this requirement even if prose mentions a provider or model name. A CLEAN evidence block that omits extractable `SHA:` / `Model:` for `factory-evidence-check` SHALL NOT satisfy the ready gate.

#### Scenario: Attribution lines present for implement and review
- **GIVEN** a factory Task PR that completed security-review with CLEAN matching head SHA
- **WHEN** a stats consumer greps the PR body and comments for `Factory implement:`, `Provider:`, `Role:`, `Model:`, and `Outcome:`
- **THEN** it SHALL find implement Provider and Model on the PR body and at least one security-review comment with `Outcome: CLEAN` naming that head SHA and including Provider and Model

#### Scenario: Distinct review models across rounds remain visible
- **GIVEN** round 1 security-review used Provider `P1` and model `A` with `Outcome: BLOCKED` and round 2 used Provider `P2` and model `B` with `Outcome: CLEAN`
- **WHEN** the PR comment history is inspected
- **THEN** both Provider/Model pairs SHALL appear with their respective Outcome values

#### Scenario: Missing Outcome line is incomplete
- **GIVEN** a security-review PR comment that names a Provider, Model, and SHA but omits `Outcome:`
- **WHEN** attribution completeness is checked
- **THEN** that comment SHALL NOT satisfy this requirement

#### Scenario: Missing Provider line is incomplete
- **GIVEN** a security-review PR comment that names a Model, SHA, Role, and Outcome but omits `Provider:`
- **WHEN** attribution completeness is checked
- **THEN** that comment SHALL NOT satisfy this requirement

#### Scenario: Missing Provider on implement body is incomplete
- **GIVEN** a factory Task PR body that includes `Factory implement: Model: <slug>` (or equivalent Model-only implement attribution) and omits `Provider:`
- **WHEN** attribution completeness is checked
- **THEN** that PR body SHALL NOT satisfy this requirement

#### Scenario: Missing Provider on fix comment is incomplete
- **GIVEN** a writer fix acknowledgment PR comment that names Model, Role implement, New SHA, and Outcome fix but omits `Provider:`
- **WHEN** attribution completeness is checked
- **THEN** that comment SHALL NOT satisfy this requirement

#### Scenario: Cursor-routed model uses Provider cursor
- **GIVEN** the writing or review session invoked a Claude model through Cursor Agent
- **WHEN** attribution lines are posted on the PR
- **THEN** they SHALL use `Provider: cursor` with the Cursor model slug and SHALL NOT use `Provider: anthropic` solely because the underlying model is Claude

#### Scenario: Attribution lines do not break ready-gate order
- **GIVEN** a CLEAN security-review comment that must pass `factory-evidence-check`
- **WHEN** the comment is composed
- **THEN** the evidence block SHALL include labeled `SHA:` and `Model:` that the checker can extract, and SHALL also include `Provider:`, `Role:`, and `Outcome:` for attribution completeness
