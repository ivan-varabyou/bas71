# factory-kit Specification

## Purpose

Living spec for a **portable, brand-free** factory package other repositories can depend on via semver: a CLI-driven harness with stack-agnostic builtins (`openspec-validate`, `living-spec-guard`, `factory-evidence-check`), consumer `run:` adapters for product-specific checks, optional Langfuse hooks that never fail the harness, optional openspec-flow conveyor aligned with `dark-factory`, and **L1 (human merge) as the default** automation level with kit-owned evidence Model slug allowlists.

## Requirements

### Requirement: Portable factory-kit package
The monorepo SHALL provide a **brand-free** factory-kit package (published or workspace name WITHOUT a third-party product brand in the core package id; e.g. `@viafactory/kit`) that ships: (1) a CLI entry that runs a configured harness stage list, (2) a JSON Schema for `factory.config.yaml`, (3) builtin stages that are stack-agnostic (`openspec-validate`, `living-spec-guard`, `factory-evidence-check`, `agent-docs-map-check`), (4) templates for Cursor process projections, GitHub label docs, optional Langfuse Cursor hooks, and English stub agent-docs layers under `templates/docs/agents/`. Product- or stack-specific checks (Nx, Go, Angular, domain greps) SHALL NOT be hardcoded in the kit core; they SHALL be invoked only via consumer `run:` adapters in config. Versioning SHALL be semver so other repositories can depend on and upgrade the kit independently of product app versions.

#### Scenario: KIT-01 core has no product stack hardcode
- **GIVEN** the factory-kit package sources
- **WHEN** they are grepped for mandatory `nx run-many` or `go test ./...` as the only harness path
- **THEN** no such hard dependency SHALL exist in kit core; those commands MAY appear only in example adapters or consumer config

#### Scenario: KIT-02 config drives stages
- **GIVEN** a valid `factory.config.yaml` listing builtin and `run:` stages
- **WHEN** `factory harness` (or equivalent CLI) executes
- **THEN** stages SHALL run in order and the first non-zero stage exit SHALL fail the harness closed

#### Scenario: KIT-03 other repo can install
- **GIVEN** a second repository with OpenSpec and a minimal `factory.config.yaml`
- **WHEN** it depends on `@viafactory/kit` and runs the CLI
- **THEN** OpenSpec validate + living-spec guard + evidence builtins SHALL be available without copying consumer product `apps/` or backends

### Requirement: Factory observability stages (optional Langfuse)
Factory-kit SHALL define a stable stage id vocabulary for observability (`openspec-author`, `openspec-review`, `implement`, `harness`, `security-review`, and consumer-defined ids). When Langfuse (or compatible OTLP) is enabled in config and credentials are present, Cursor hook templates shipped by the kit SHALL emit spans/tags including at least `stage`, `issue` (when known), `model` (when known), `sha` (when known), and `outcome` (`CLEAN`|`FAIL`|`quota`|`aborted`). When observability is disabled, or when credentials are missing, or when the telemetry endpoint is unreachable, harness SHALL still pass. Traces SHALL NOT include secrets, tokens, or private key material.

#### Scenario: KIT-04 harness without Langfuse still passes
- **GIVEN** `observability.langfuse.enabled` is false or unset
- **WHEN** factory harness runs all required stages green
- **THEN** harness SHALL print success and SHALL NOT fail solely due to missing Langfuse

#### Scenario: KIT-04b enabled without credentials still passes
- **GIVEN** `observability.langfuse.enabled` is true and Langfuse credentials are missing
- **WHEN** factory harness runs all required stages green
- **THEN** harness SHALL still pass and SHALL NOT require Langfuse for success

#### Scenario: KIT-05 stage tags present when enabled
- **GIVEN** Langfuse enabled with valid local credentials and a completed security-review session using kit hooks
- **WHEN** traces are queried for that session
- **THEN** at least one span or generation SHALL carry tag/metadata `stage=security-review` (or the configured key) and SHALL NOT contain Infisical/AWS secret values

### Requirement: openspec-flow conveyor is optional and non-parallel
Consumers MAY install openspec-flow (GitHub App or CLI shim) using labels configured in `factory.config.yaml` (defaults `openspec:go`, `openspec:spec`, `openspec:impl`). That conveyor SHALL drive the same OpenSpec change → archive → Task → impl PR lifecycle defined by living `dark-factory` and SHALL NOT invent requirements outside OpenSpec. Spec-PR merge SHALL remain a human gate at L1; at L2 a gated bot merge MAY occur only under living L2 rules. Impl-PR SHALL require factory harness green and matching security-review evidence before ready-for-merge. Kit docs SHALL state that merge-on-green without L2 is forbidden. There is no separate `autoMerge` config field; only `automation.level` controls merge automation.

#### Scenario: KIT-06 flow labels documented
- **GIVEN** factory-kit templates/docs for openspec-flow
- **WHEN** an operator reads the install guide
- **THEN** the three labels and the mapping to dark-factory steps SHALL be named, and a parallel chat-only impl path SHALL be forbidden

### Requirement: Automation levels L0–L2
Factory automation SHALL be expressed as a single field `automation.level` in `factory.config.yaml` and living process rules:

- **L0** — human-driven; agents MAY advise only.
- **L1** (default) — agents may open OpenSpec changes, implement Tasks, run harness, obtain CLEAN security-review, and open PRs; **humans merge**; agents SHALL NOT `gh pr merge` / `--auto`, **except** when the human explicitly authorizes merge for named PR(s) in the same working session per living `dark-factory`.
- **L2** (opt-in, post-MVP) — a bot MAY merge only when ALL of: harness green on head SHA, CLEAN security-review evidence matching head SHA, OpenSpec requirement cited, and `automation.level: L2` set; L2 SHALL NOT be the default in templates.

Raising a consumer to L2 SHALL require an archived OpenSpec change in that consumer (or this kit’s living requirement already allowing L2) plus explicit `automation.level: L2`. “100% automation” without L2 config and evidence SHALL be refused. Missing CLEAN evidence or a red harness at L2 SHALL refuse bot merge.

#### Scenario: KIT-07 default is L1 human merge
- **GIVEN** a fresh factory.config template from the kit
- **WHEN** automation level is read
- **THEN** it SHALL be L1 (or unset meaning L1) and agents SHALL NOT merge PRs without explicit human authorization in the same session

#### Scenario: KIT-07b human-authorized L1 merge
- **GIVEN** automation level is L1 and the human explicitly authorizes merge for a named PR in the same session
- **WHEN** that PR has harness green and CLEAN evidence matching head SHA
- **THEN** the agent MAY `gh pr merge` that PR and SHALL NOT treat that as L2 or merge-on-green

#### Scenario: KIT-08 L2 refused without config
- **GIVEN** automation level is L1
- **WHEN** an agent or workflow attempts auto-merge on green checks alone
- **THEN** the factory SHALL treat that as forbidden and SHALL NOT document it as success

#### Scenario: KIT-09 L2 refuses merge without CLEAN evidence
- **GIVEN** `automation.level` is L2 and the PR head SHA has no matching CLEAN security-review evidence (or harness exited non-zero)
- **WHEN** a bot or workflow attempts to merge
- **THEN** the merge SHALL be refused

#### Scenario: KIT-09b L2 refuses merge without OpenSpec citation
- **GIVEN** `automation.level` is L2 and the Task/PR does not cite a living `### Requirement:`
- **WHEN** a bot or workflow attempts to merge
- **THEN** the merge SHALL be refused

### Requirement: Kit-owned evidence allowlist for fast slugs
The factory-kit evidence checker SHALL own the exact set of Model: slug strings that MAY contain `fast` and still count as a valid security-review or openspec-review CLEAN pass. Consumers MAY select a subset of that kit-shipped set in config. Consumers SHALL NOT add an arbitrary `*-fast` Model: value that is absent from the kit allowlist and have evidence-check accept it. Expanding the allowlist requires a kit version that documents the new exact slug.

#### Scenario: KIT-10 consumer cannot invent fast allowlist entry
- **GIVEN** a consumer config lists Model slug `unknown-vendor-fast` that is not in the kit-shipped allowlist
- **WHEN** evidence-check validates a CLEAN block naming that Model
- **THEN** evidence-check SHALL reject the evidence

### Requirement: Agent docs map templates and structural check
The factory-kit package SHALL ship English stub templates under `templates/docs/agents/` for the standard layer entrypoints (architecture, backend, apps, factory, acceptance) and SHALL provide a stack-agnostic harness builtin `agent-docs-map-check`. When that builtin is listed in consumer `factory.config.yaml` stages, harness SHALL fail closed if root `AGENTS.md` lacks markdown links to the **default five** standard layer entrypoints required by living `agent-docs`. Optional config key `agentDocs.requiredLinks` MAY **add** extra repo-relative paths that MUST also be linked; it SHALL NOT remove or replace the default five. The check SHALL NOT LLM-review prose quality. Product stack commands SHALL remain `run:` adapters only.

#### Scenario: KIT-DOC-01 missing layer link fails
- **GIVEN** a consumer config includes builtin `agent-docs-map-check` and root `AGENTS.md` lacks a link to `docs/agents/backend/AGENTS.md`
- **WHEN** harness runs that stage
- **THEN** the process SHALL exit non-zero with a clear agent-docs map message

#### Scenario: KIT-DOC-02 present links pass
- **GIVEN** root `AGENTS.md` links to all default layer entrypoints and any additive `agentDocs.requiredLinks`
- **WHEN** only `agent-docs-map-check` runs
- **THEN** that stage SHALL pass

#### Scenario: KIT-DOC-02b additive links cannot drop defaults
- **GIVEN** `agentDocs.requiredLinks` lists only a custom path and root `AGENTS.md` omits `docs/agents/factory/AGENTS.md`
- **WHEN** `agent-docs-map-check` runs
- **THEN** the stage SHALL fail because the default five remain mandatory

#### Scenario: KIT-DOC-03 templates are brand-free
- **GIVEN** kit templates under `templates/docs/agents/`
- **WHEN** grepped for a third-party product brand as a hard dependency
- **THEN** stubs SHALL remain usable by any consumer without renaming the kit package
