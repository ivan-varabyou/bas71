# agent-docs Specification

## Purpose

Portable hierarchical agent documentation map shared by Viafactory and all consumer repositories: thin root `AGENTS.md`, layered `docs/agents/**`, English-only agent-facing docs, and update-with-behavior sync. Product go-live checklists and product service inventories stay in consumer OpenSpec/content.

## Requirements

### Requirement: Root AGENTS.md is a map

A consumer (or this) repository root `AGENTS.md` SHALL act as a thin orientation map for agents: product/repo one-liner, non-negotiable hard locks, and links to layered docs under `docs/agents/**`. It SHALL NOT embed full endpoint catalogs, full DB schemas, or long sprint status (sprint status remains a handoff file such as `AGENT-HANDOFF.md`). Links SHALL use repo-relative markdown paths so agents can open lower layers on demand (including `@docs/agents/...` mentions in Cursor).

#### Scenario: DOC-01 root stays thin

- **GIVEN** root `AGENTS.md`
- **WHEN** an agent needs detailed service or domain notes
- **THEN** that detail SHALL be reached via a link into `docs/agents/**` rather than inlined as the primary content of the root file

#### Scenario: DOC-02 required layer links exist

- **GIVEN** the agent-docs tree is adopted in a repository
- **WHEN** root `AGENTS.md` is inspected
- **THEN** it SHALL link to at least `docs/agents/architecture/AGENTS.md`, `docs/agents/backend/AGENTS.md`, `docs/agents/apps/AGENTS.md`, `docs/agents/factory/AGENTS.md`, and `docs/agents/acceptance/AGENTS.md`

### Requirement: Layered AGENTS.md tree

Repositories that adopt agent-docs SHALL maintain `docs/agents/` with layered `AGENTS.md` covering architecture, backend, apps, factory kit/process, and acceptance entrypoints. Each layer page SHALL state its purpose, cite the living OpenSpec module path(s) it summarizes, link upward to the parent map and downward to children, and call out non-obvious invariants briefly. Obvious framework facts SHALL be omitted. Product-specific children (per-service notes, domain DSN notes, gateway notes) SHALL live under those layers and SHALL NOT be required by name in this portable module. In the Viafactory monorepo, the apps layer SHALL link the admin integration playbook child `docs/agents/apps/admin-integration.md` when admin-cms is adopted. Agent-facing documentation SHALL be written in **English**, including: root `AGENTS.md`, `docs/agents/**`, living OpenSpec modules under `openspec/specs/**`, active/archived OpenSpec change prose under `openspec/changes/**` (except historical archives already merged before this requirement), and Cursor projections under `.cursor/rules/**` and `.cursor/skills/**`. A parallel non-English agent-docs tree SHALL NOT be maintained. Optional non-English MAY exist only as a thin top-level human README overlay (e.g. `README.ru.md` or a short section in `README.md`) that links to the English map.

#### Scenario: DOC-03 children linked from layers not dumped at root

- **GIVEN** a consumer that documents multiple backend services or domains
- **WHEN** an agent opens `docs/agents/backend/AGENTS.md`
- **THEN** per-service or per-domain notes SHALL be reachable via child links under that layer rather than pasted into root `AGENTS.md`

#### Scenario: DOC-03b English-only agent-facing docs

- **GIVEN** root `AGENTS.md`, any `docs/agents/**` page, a living `openspec/specs/*/spec.md`, an active or newly authored `openspec/changes/**` prose file, or a Cursor rule/skill projection
- **WHEN** the documentation language is inspected
- **THEN** those agent-facing pages SHALL be English and SHALL NOT require a non-English twin file to be authoritative

#### Scenario: DOC-03c apps layer links admin integration playbook

- **GIVEN** Viafactory `docs/agents/apps/AGENTS.md` after admin integration playbook exists
- **WHEN** an agent opens that apps layer page
- **THEN** it SHALL link to `docs/agents/apps/admin-integration.md`

#### Scenario: DOC-04 non-obvious invariants at the owning layer

- **GIVEN** a layer or child page that summarizes a living OpenSpec invariant
- **WHEN** read by an agent
- **THEN** it SHALL briefly state the non-obvious invariant and cite the living module path, without inventing stricter limits than that module

### Requirement: Docs update with behavior changes

A pull request that changes public routing, route ownership, data-store topology, factory-kit pin/automation defaults, or admin/ops mutation surface in a repository that adopted agent-docs SHALL update the corresponding `docs/agents/**` page(s) in the same PR, or open a GitHub Task labeled `priority:critical` the same calendar day that links the behavior commit. Docs SHALL NOT invent behavior absent from living OpenSpec.

#### Scenario: DOC-05 behavior change without doc update is incomplete

- **GIVEN** a PR that changes a surface covered by an adopted `docs/agents/**` page
- **WHEN** the PR is prepared for ready-for-human
- **THEN** the owning `docs/agents/**` page(s) SHALL be updated in that PR or a Critical Task linking the commit SHALL exist

#### Scenario: DOC-06 docs are not a parallel SoT

- **GIVEN** a conflict between a docs/agents page and a living `openspec/specs/*/spec.md` requirement
- **WHEN** an agent chooses the source of truth
- **THEN** the living OpenSpec module SHALL win and the docs page SHALL be corrected via the same change process

### Requirement: Packages lane map linked from agent docs

Repositories that adopt Viafactory agent-docs in this monorepo SHALL link `packages/README.md` from root `AGENTS.md` and from `docs/agents/architecture/AGENTS.md`. The backend layer page SHALL name Admin backend packages (`admin-cms`, `admin-host`, `admin-release`). The apps layer page SHALL name Admin frontend (`admin-shell`) and Shared contracts. The factory layer page SHALL name Process / harness (`kit`). Identity packages (`authn`, `access`) SHALL be cited from architecture (and backend when summarizing engines), not presented as Admin frontend.

#### Scenario: DOC-PKG-01 packages map is reachable from root and architecture

- **GIVEN** root `AGENTS.md` and `docs/agents/architecture/AGENTS.md` in this repository
- **WHEN** an agent needs package ownership orientation
- **THEN** both pages SHALL link to `packages/README.md`, and agents SHALL NOT infer ownership from folder sort order alone

#### Scenario: DOC-PKG-02 layers name the correct lanes

- **GIVEN** `docs/agents/backend/AGENTS.md`, `docs/agents/apps/AGENTS.md`, and `docs/agents/factory/AGENTS.md`
- **WHEN** those pages are inspected
- **THEN** each SHALL name the packages for its lane(s) and SHALL NOT dump the full alphabetical `packages/` listing as the only guidance
