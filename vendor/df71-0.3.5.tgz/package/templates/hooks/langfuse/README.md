# Langfuse Cursor hook stubs

Optional. When `observability.langfuse.enabled` is false/unset, or credentials are missing, harness MUST still pass (KIT-04 / KIT-04b / KIT-OBS).

The kit harness also best-effort POSTs a harness trace when enabled and `LANGFUSE_PUBLIC_KEY` + `LANGFUSE_SECRET_KEY` are set. Unreachable hosts, HTTP errors, timeouts, or missing credentials MUST NOT change the harness exit code.

Emit tags when enabled: `stage`, `issue`, `model`, `sha`, `outcome` (`CLEAN`|`FAIL`|`quota`|`aborted`).

Never send secrets, tokens, or private keys in traces.
