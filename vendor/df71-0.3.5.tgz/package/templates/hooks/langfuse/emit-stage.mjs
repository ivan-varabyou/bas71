#!/usr/bin/env node
/**
 * Cursor hook template — optional Langfuse stage emit.
 *
 * Usage (env):
 *   LANGFUSE_PUBLIC_KEY / LANGFUSE_SECRET_KEY [/ LANGFUSE_HOST]
 *   FACTORY_STAGE (required) — openspec-author|openspec-review|implement|harness|security-review|…
 *   FACTORY_OUTCOME — CLEAN|FAIL|quota|aborted (default FAIL)
 *   FACTORY_ISSUE / FACTORY_MODEL / FACTORY_SHA — optional tags
 *
 * Exit code is always 0. Missing credentials or network errors are ignored
 * so hooks never fail the agent session or harness (KIT-04 / KIT-04b).
 */
import { createRequire } from "node:module";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = dirname(fileURLToPath(import.meta.url));

async function main() {
  try {
    const require = createRequire(import.meta.url);
    // Prefer the installed package; fall back to relative dist when developing the kit.
    let kit;
    try {
      kit = require("df71");
    } catch {
      kit = require(join(__dirname, "../../../dist/index.js"));
    }

    const stage = (process.env.FACTORY_STAGE ?? "").trim();
    if (!stage) {
      return;
    }
    const outcomeRaw = (process.env.FACTORY_OUTCOME ?? "FAIL").trim();
    const allowed = new Set(["CLEAN", "FAIL", "quota", "aborted"]);
    const outcome = allowed.has(outcomeRaw) ? outcomeRaw : "FAIL";

    const tags = kit.buildObservabilityTags({
      stage,
      outcome,
      issue: process.env.FACTORY_ISSUE,
      model: process.env.FACTORY_MODEL,
      sha: process.env.FACTORY_SHA,
      stageTagKey: process.env.FACTORY_STAGE_TAG_KEY || "stage",
    });

    await kit.emitObservabilityEvent({
      enabled: true,
      credentials: kit.resolveLangfuseCredentials(process.env),
      tags,
      env: process.env,
      name: `factory.hook.${stage}`,
    });
  } catch {
    // Best-effort only.
  }
}

await main();
process.exit(0);
