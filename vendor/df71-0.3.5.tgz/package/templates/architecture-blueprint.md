# Architecture Blueprint: <feature and task>

## Identity and scope

- State: DRAFT
- OpenSpec requirement and scenario links:
- Change/task link:
- Working revision and relevant dirty paths:
- Blueprint revision/date:
- Author; reviewer identity and review scope:
- User-visible outcome and explicit scope boundaries:
- Donor routes/inventory, where applicable:

Replace all placeholders before READY_FOR_RED. Expand the tree to every affected leaf; do not leave wildcard paths or ellipses. The example below illustrates notation, not a prescribed architecture or validated repository inventory.

## Discovery and applicable policies

| Query/check | Command | Exit code | Evidence and implications |
|---|---|---|---|
| Capability and consumers | factory discover --query <symbol> | | |
| Source policy | factory project-check | | |
| Stack architecture | <configured command> | | |

| Scope/file type | Policy/config path and rule | Effective cap | Warning/refactoring threshold | Conflict resolution |
|---|---|---:|---:|---|

No new numerical caps or minimum headroom are introduced by this template. Use actual scoped policy; if no cap exists, record N/A and assess responsibility/cohesion. Estimates are approximate, not exact-size promises.

## Full proposed file tree

Notation: ID; operation CREATE/MODIFY/MOVE/DELETE/REUSE; layer/owner; current → estimated final [upper estimate]; cap; headroom; responsibility.
For MOVE include old and new exact paths. For DELETE the final count is zero. REUSE means no edit.

```text
<source-root>/
├── contracts/
│   ├── resource.interfaces.ts  [F01 CREATE; contracts; 0 → 40 [50]; cap=<policy>; headroom=<cap-50>; resource port]
│   └── resource.tokens.ts      [F02 CREATE; contracts; 0 → 12 [16]; cap=<policy>; headroom=<cap-16>; injection token]
├── features/resource/
│   ├── widgets/ (or tabs/)     [Sub-components grouped in dedicated subfolders, never flat in feature root]
│   │   └── resource-summary/
│   │       ├── resource-summary.component.ts   [F03 CREATE; feature; 0 → 80 [100]; cap=250; headroom=150; summary widget]
│   │       ├── resource-summary.component.html [F04 CREATE; feature; 0 → 45 [60]; cap=150; headroom=90; widget template]
│   │       └── resource-summary.component.css  [F05 CREATE; feature; 0 → 25 [35]; cap=150; headroom=115; widget layout]
│   └── resource-subnav/
│       └── resource-subnav.component.ts        [F06 CREATE; feature; 0 → 60 [80]; cap=250; headroom=170; feature subnav]
├── pages/resource-page/
│   ├── resource-page.component.ts   [F07 CREATE; page; 0 → 90 [110]; cap=150; headroom=40; page orchestration]
│   ├── resource-page.component.html [F08 CREATE; page; 0 → 55 [70]; cap=200; headroom=130; page composition]
│   └── resource-page.component.css  [F09 CREATE; page; 0 → 30 [40]; cap=150; headroom=110; page layout]
└── shared/ui/button/
    └── button.component.ts          [F10 REUSE; shared; <current> → <current>; cap=150; existing action primitive]
```

The completed tree must also list real adapter/provider registration, shared template/style dependencies, route registration, translations, test files, configuration and documentation needed by the feature.

| Directory/operation | File count | Current lines | Final estimate | Upper estimate |
|---|---:|---:|---:|---:|

## Per-file detail cards (repeat for every leaf)

### <ID — exact path>

- Operation, owner and layer:
- Single responsibility; responsibilities explicitly assigned elsewhere:
- Public exports/selectors, input/output types:
- State ownership and lifetime:
- Size breakdown: contract + state + validation + orchestration + rendering/formatting = estimate:
- Upper estimate, uncertainty, cap, headroom, threshold:
- Dependencies (edge IDs below):
- Actual/planned consumers:
- OpenSpec scenarios and verifying test paths:
- For existing files: measured current count and expected final count:
- For generated files: generator/source path:

## Dependency graph and permitted directions

```text
<route registration> → <page> → <shared component>
<page/state> → <port interface and token>
<composition root> → <provider binding> → <consumer adapter> → <endpoint>
<consumer adapter> implements <port interface>
```

| Edge ID | Source file ID | Target exact path + symbol | Kind (import/type/render/event/call) | Allowed by rule | Reason |
|---|---|---|---|---|---|

| Port | Interface path | Token path | Adapter path | Provider/composition root path | Consumers | Lifetime |
|---|---|---|---|---|---|---|

Explain cycle avoidance, platform/consumer separation and shared dependency boundaries.

## Reuse & Extraction Decisions

### ♻️ Reused Shared Primitives (Active in >= 2 components)

| Capability | Discovery query | Existing path/symbol | Readiness | Consumer/test evidence | Decision and reason | Planned consumers |
|---|---|---|---|---|---|---|

### 📦 Extracted for Reuse / Domain Dialogs (@frontend/shared candidates)

| Capability | Target path/symbol | Responsibility & Boundary | Rule of 2 justification | Planned consumers | Adjacent contract (*.api.md) |
|---|---|---|---|---|---|

For each extension: list contract compatibility, affected consumers and regression tests. For each new shared primitive: name the concrete consumers and ensure Rule of 2 compliance. For local composition: explain the domain-specific responsibility.

## Use cases and functional connections

| Scenario | Route/control | Component and handler | State owner | Port/adapter/endpoint | Success update | Loading/empty/error/denied | E2E test path |
|---|---|---|---|---|---|---|---|

Include input validation, keyboard/focus behavior, i18n keys, event payloads and cleanup where applicable. Every rendered action must have a real behavior and test mapping.

## Paper decomposition findings

| Finding ID | File/edge | Violated rule | Responsibility/size/coupling evidence | Replacement design | State |
|---|---|---|---|---|---|

For each finding include BEFORE and AFTER tree fragments, redistributed responsibilities, updated line estimates and replacement edges. Resolve findings before source/test implementation. Do not move a large component's logic wholesale into a giant controller.

## Architecture review matrix

| Rule and source | File/edge IDs | Evidence | Result (PASS/BLOCKED/N/A with reason) | Correction |
|---|---|---|---|---|
| Complete exact-path inventory | | | | |
| Physical-line caps and warning thresholds | | | | |
| Single responsibility and coupling | | | | |
| Layer directions, cycles and IoC bindings | | | | |
| Shared reuse and Rule of 2 | | | | |
| Explicit names, interfaces and safe types | | | | |
| Separate templates/styles and nesting | | | | |
| Real actions, state ownership and error paths | | | | |
| i18n, accessibility and security | | | | |
| Scenario/test coverage and donor parity | | | | |

- Unresolved findings and policy conflicts:
- Decision: DRAFT / BLOCKED / READY_FOR_RED
- Reviewer, blueprint revision and evidence:
- Re-review triggers: changed files, scope, budgets, dependencies or public contracts.

## Verification and implementation reconciliation

| Scenario/rule | Exact command | Planned test/evidence file | Expected result |
|---|---|---|---|

Include configured architecture checks, relevant tests, formatting, harness and donor acceptance where applicable. Do not equate specification validation with architecture validation.

After implementation:

| File ID/path | Planned upper lines | Actual formatted lines | Planned/actual contract or dependency difference | Resolution/re-review |
|---|---:|---:|---|---|

Record command exit codes and unresolved existing failures. Plan readiness is not implementation acceptance.
