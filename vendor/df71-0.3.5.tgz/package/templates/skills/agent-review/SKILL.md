---
name: agent-review
description: Protocol for dual-agent development and review pipeline (Developer Gemini 3.7 + Reviewer Gemini 3.8), conducting rigorous donor parity, zero-stub functional audit, modular architecture decomposition, IoC provider architecture, and automated continuous loop until clean acceptance.
---

# Dual-Agent Review Protocol (`agent-review`)

This skill defines the multi-model pairing and automated continuous review protocol between the **Developer Agent** (Gemini 3.7) and the **Reviewer Agent** (Gemini 3.8). It enforces strict donor parity, functional completeness (Zero-Stub Rule), architectural decomposition, IoC/Provider interfaces, and automated gate enforcement before any task can be accepted as complete.

---

## 0. FUNDAMENTAL PRINCIPLES & MODEL PAIRING

1. **Role Separation (Dual-Model Gate)**:
   - **Developer Agent (`implement`)**: Powered by **Gemini 3.7** (Flash / Thinking). Responsible for writing clean feature code, modular components, unit/E2E tests, and resolving findings.
   - **Reviewer Agent (`security-review` / `openspec-review`)**: Powered by **Gemini 3.8** (Flash / Thinking / distinct model). Acts as an independent, adversarial auditor. The exact same model slug used for implementation SHALL NOT approve its own review.
2. **Unbroken Pipeline (Continuous Loop until Clean Pass)**:
   - The task pipeline **MUST NOT terminate, mark done, or proceed to merge** while any review findings remain open, while functionality is incomplete, or while monolithic god-components exist.
   - If findings are reported by the Reviewer, control immediately returns to the Developer for remediation and refactoring, followed by a re-review on the new commit SHA.
3. **Automated Enforcement First (Linter & Harness Over Manual Review)**:
   - Architecture invariants, typing, import sorting, and size constraints must be verified automatically by `pnpm harness:check` and static AST tests. The Reviewer focuses on runtime functional correctness, donor parity, and design elegance.
4. **Zero Technical Debt Carryover**:
   - Every completed task MUST leave its domain slice 100% production-ready. No temporary stubs or "we'll wire this in the next task" shortcuts.

---

## 1. ARCHITECTURAL LAYERS & UPFRONT REUSABILITY

```
┌────────────────────────────────────────────────────────────────────────┐
│ Tier 4: Pages / Routed Orchestrators (`pages/*-page.component.ts`)     │
│ - Thin orchestrators ONLY: reads route params, injects root stores/facades │
│ - Assembles ready feature sections. ZERO inline raw fetch/business logic.│
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ delegates to
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│ Tier 3: Sections & Layout Slices (`sections/*`)                        │
│ - Semantic page regions (HeaderSection, ContentTableSection, FormSection)│
│ - Coordinates layout grid hierarchy and multiple feature modules       │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ delegates to
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│ Tier 2: Feature Modules & Sub-Features (`features/*` / `components/*`)  │
│ - Single-responsibility interactive blocks:                            │
│   e.g. `FilterBuilderComponent`, `ColumnConfiguratorComponent`,        │
│        `PaginationComponent`, `MediaPickerModalComponent`              │
│ - Dedicated state/signals for the specific feature flow                │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ delegates to
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│ Tier 1: Reusable Primitives & UI Kit (`shared/*` / `@ui/kit/*`)        │
│ - Pure, reusable, stateless/micro-state presentation primitives:       │
│   Buttons, Badges, Chips, Inputs, Dropdowns, Tooltips, TableCells      │
│ - Anticipate future features during donor analysis and extract here    │
└────────────────────────────────────────────────────────────────────────┘
```

### IoC Provider Architecture & Dependency Injection:
1. **Interface-First Design**: All business services, clients, stores, and event buses MUST implement an explicit TypeScript interface (Port).
2. **Token-Based Injection**: Injected via `InjectionToken` (`ADMIN_API_BASE_URL`, `ADMIN_AUTH_STORE`, `CONTENT_MANAGER_CLIENT`). Implementation classes can be swapped seamlessly without modifying contracts or consumer pages.
3. **Mandatory Post-Implementation Reusability Self-Audit**:
   Immediately after feature development and before review handover, the Developer Agent MUST answer:
   - *"What components, widgets, services, or utilities developed in this task could or should be reused in upcoming tasks (e.g. Content-Type Builder, Settings, Media Library)?"*
   - *"Does this task introduce any page-private variants (`cm-*`, `ctb-*`, `settings-*`) of generic UI archetypes?"*
   - Apply the **"Rule of 2"**: Any component, modal dialog, filter, or table widget appearing on or needed by **two or more distinct routes** MUST be extracted to `@ui/shared` under the unified `vf-*` prefix (`vf-button`, `vf-pagination`, `vf-data-table`, `vf-modal-dialog`, `vf-filter-builder`, `vf-subnav`, `vf-status-badge`, `vf-confirm-dialog`, `vf-search-input`).

---

## 2. 6-DIMENSION REVIEW CHECKLIST

The Reviewer Agent evaluates the pull request / commit diff against 6 mandatory dimensions:

```
┌────────────────────────────────────────────────────────────────────────┐
│ 1. Task Requirements & OpenSpec Acceptance Criteria                   │
│ - Verified against living spec `### Requirement:` and `#### Scenario`  │
│ - Every Given/When/Then scenario has passing test coverage             │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ PASS
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│ 2. Donor Parity & Behavioral Inspection                                │
│ - Compared against donor reference (`docs/agents/apps/strapi-reference.md`,│
│   screenshots in `shots-full/`, and hydrated DOM snapshots)            │
│ - Single Types open form directly; Collection Types open table view    │
│ - Visual alignment, correct layout hierarchy, and responsive behavior  │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ PASS
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│ 3. Mandatory Zero-Stub & Real Functional Execution Rule                │
│ - ZERO placeholder buttons, empty handlers `() => {}`, or `href="#"`   │
│ - Every rendered button, modal, form input, slider arrow, and filter   │
│   triggers real reactive signal updates and Host API calls             │
│ - Real E2E tests: Angular component signals & DOM tested, NO mock arrays│
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ PASS
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│ 4. Anti-God-Entity & File Complexity Limits (ADM-ARCH)                 │
│ - Component files <= 250 lines (SOFT WARNING at 200 lines triggers     │
│   mandatory refactoring: extract sub-components, *.utils.ts, *.constants.ts)│
│ - Template files <= 150 lines (extract dialogs, drawers, sub-toolbars) │
│ - Test files <= 350 lines (split into focused feature flow suites)     │
│ - Zero God-Components: A component MUST NOT combine multiple distinct  │
│   modal forms, complex tables, and business fetching in a single class │
│ - Strict 4-tier hierarchy: Pages -> Sections -> Features -> Shared Kit │
│ - 100% of interfaces in dedicated `*.interfaces.ts`                    │
│ - Zero Unsafe Casts: NO `as` (except `as const`) and NO `any`          │
│ - Explicit Naming: NO cryptic abbreviations (`val`, `col`, `btn`, etc.)│
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ PASS
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│ 5. Cross-Page Reusability & Shared Component Extraction (Rule of 2)    │
│ - Verify all generic UI patterns (buttons, pagination, filter popovers,│
│   data tables, modal shells, badges) reside in `@ui/shared`            │
│ - Reject page-private duplication (`cm-button`, `ctb-pagination`, etc.)│
│ - Ensure extracted shared components have clean, documented Inputs/Outputs│
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ PASS
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│ 6. Security & Secret Exposure Hygiene                                  │
│ - Zero credentials, tokens, or private keys exposed in query params    │
│ - Strict Bearer token authorization on all Host API endpoints          │
│ - Proper 401/403 handling on unauthorized actions                      │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 3. THE DUAL-AGENT PIPELINE LOOP

```mermaid
flowchart TD
    Start([Task Kickoff]) --> DevPhase[Developer Gemini 3.7: Implement, Modularize & Test]
    DevPhase --> LocalGates[Run pnpm test & pnpm harness:check]
    LocalGates --> GateCheck{Gates Green?}
    GateCheck -- No --> DevFix[Developer: Fix Local Errors]
    DevFix --> LocalGates
    GateCheck -- Yes --> ReviewPhase[Reviewer Gemini 3.8: Audit Parity, Functional Flow & IoC]
    ReviewPhase --> FindingsCheck{Any Findings, Stubs, or God-Files?}
    FindingsCheck -- Yes: REVISE --> ReviewReport[Generate Review Findings Report]
    ReviewReport --> DevRemediation[Developer Gemini 3.7: Refactor & Fix Findings]
    DevRemediation --> LocalGates
    FindingsCheck -- No: PASS --> SignOff[Reviewer: Emit Clean Sign-off]
    SignOff --> Done([Task Verified & Completed])
```

---

## 4. REVIEW FINDINGS REPORT TEMPLATE

When the Reviewer Agent identifies deficiencies, it outputs a structured report:

```markdown
# 🔍 Review Findings Report

- **Task**: [Task Name / Issue #N]
- **Developer Model**: Gemini 3.7
- **Reviewer Model**: Gemini 3.8
- **Verdict**: ❌ REVISE (Findings Detected)

## 1. Functional Deficiencies & Stubs
- [ ] `path/to/file.html:L45`: Slider arrow buttons have no `(click)` handlers.
- [ ] `path/to/page.ts`: Single Types incorrectly open table view instead of edit form.

## 2. Donor Reference Parity Deviations
- [ ] Host API response structure does not match donor (`results/pagination` missing).
- [ ] View configuration endpoint `GET /content-manager/content-types/:uid/configuration` missing.

## 3. Architecture & File Complexity Invariants (Anti-God-Entity)
- [ ] `path/to/page.component.ts` has 265 lines (exceeds 250-line component limit). Decompose into sub-components.
- [ ] `path/to/page.component.html` has 180 lines (exceeds 150-line template limit). Extract modal dialog to a separate component.

## 4. Reusable Component & Duplication Audit (Rule of 2)
- [ ] `cm-button` duplicates common button behavior needed by Task 4 (CTB) and Task 5 (Settings). Extract to `@ui/shared/vf-button`.
- [ ] Pagination logic in `cm-pagination` must be generalized to `VfPaginationComponent` for reuse across Settings Users/Tokens.

## 5. Required Fix Actions
1. Extract modal dialog and sub-toolbars to reduce component size below 200 lines.
2. Relocate generic widgets (button, pagination, filter) to `@ui/shared/`.
3. Route Single Types directly to EditView form.
4. Rerun `pnpm test` and `pnpm harness:check`.
```

---

## 5. FINAL CLEAN SIGN-OFF TEMPLATE

Once all findings are resolved and automated gates are green, the Reviewer outputs:

```markdown
# ✅ Review Sign-off: PASS

- **Task**: [Task Name / Issue #N]
- **Developer Model**: Gemini 3.7
- **Reviewer Model**: Gemini 3.8
- **Verdict**: ✅ PASS (Clean & Production-Ready)
- **Architectural Decomposition**: Clean 4-tier hierarchy & IoC tokens (zero God-components, files within limits).
- **Shared UI Reusability**: Rule of 2 enforced; generic components cleanly extracted to `@ui/shared/vf-*`.
- **Unit & Contract Tests**: 100% Passed.
- **Harness Check**: `[factory] harness passed` (0 errors).
- **Zero-Stub Confirmation**: 100% of interactive UI elements execute functional Host/State logic.
- **Scope Status**: In-scope requirements 100% complete and production-ready.
```
