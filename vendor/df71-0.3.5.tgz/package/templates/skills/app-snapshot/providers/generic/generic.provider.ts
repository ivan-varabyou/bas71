import type { Page } from 'playwright';
import type { DonorProvider, AuthOptions, EndpointClassification, InteractiveElementDescriptor } from '../donor-provider.interface.ts';

export class GenericDonorProvider implements DonorProvider {
  readonly name = 'generic';
  readonly description = 'Universal fallback provider for any web or admin application';

  async authenticate(page: Page, options: AuthOptions): Promise<void> {
    if (options.token) {
      await page.addInitScript((token) => {
        window.localStorage.setItem('auth_token', token);
        window.localStorage.setItem('token', token);
        window.sessionStorage.setItem('auth_token', token);
      }, options.token);
    } else if (options.email && options.password && options.loginUrl) {
      await page.goto(options.loginUrl, { waitUntil: 'networkidle' });
      await page.fill('input[type="email"], input[name="email"], input[name="username"], input[type="text"]', options.email);
      await page.fill('input[type="password"], input[name="password"]', options.password);
      await page.click('button[type="submit"], input[type="submit"], button:has-text("Sign in"), button:has-text("Login"), button:has-text("Log in")');
      await page.waitForLoadState('networkidle');
    }
  }

  classifyEndpoint(pathname: string): EndpointClassification {
    const lower = pathname.toLowerCase();
    if (lower.includes('/admin') || lower.includes('/manage') || lower.includes('/operator') || lower.includes('/internal')) {
      return { plane: 'admin', zone: this.inferZone(lower, 'admin') };
    }
    if (lower.startsWith('/api') || lower.startsWith('/v1') || lower.startsWith('/v2') || lower.startsWith('/auth')) {
      return { plane: 'public', zone: this.inferZone(lower, 'api') };
    }
    return { plane: 'internal', zone: 'static_or_other' };
  }

  isSafeInteraction(element: InteractiveElementDescriptor): boolean {
    const label = (element.label || '').toLowerCase();
    const destructiveWords = ['delete', 'remove', 'destroy', 'drop', 'revoke', 'purge', 'reset', 'clear database'];
    return !destructiveWords.some((word) => label.includes(word));
  }

  private inferZone(pathname: string, defaultPrefix: string): string {
    const segments = pathname.split('/').filter(Boolean);
    if (segments.length >= 2) {
      return segments.slice(0, 2).join('-');
    }
    return defaultPrefix;
  }
}
