import type { Page } from 'playwright';

export interface AuthOptions {
  token?: string;
  email?: string;
  password?: string;
  loginUrl?: string;
}

export interface InteractiveElementDescriptor {
  id: string;
  tag: string;
  type?: string;
  role?: string;
  label?: string;
  selector: string;
  disabled: boolean;
}

export interface EndpointClassification {
  plane: 'public' | 'admin' | 'internal';
  zone: string;
}

export interface DonorProvider {
  /**
   * Unique name of the donor provider (e.g. 'strapi', 'directus', 'generic')
   */
  readonly name: string;
  readonly description: string;

  /**
   * Optional URL to the donor platform official feature documentation
   */
  readonly documentationUrl?: string;

  /**
   * Optional default login URL if relative or standard
   */
  readonly defaultLoginUrl?: string;

  /**
   * Performs authentication on the page (injecting token, cookie, or submitting login form)
   */
  authenticate(page: Page, options: AuthOptions): Promise<void>;

  /**
   * Classifies an observed HTTP pathname into architectural planes and logical feature zones
   */
  classifyEndpoint(pathname: string): EndpointClassification;

  /**
   * Filters whether an interactive element is safe to click during automatic interaction crawl
   */
  isSafeInteraction?(element: InteractiveElementDescriptor): boolean;
}
