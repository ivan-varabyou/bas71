import type { Page } from 'playwright';
import type { DonorProvider, AuthOptions, EndpointClassification, InteractiveElementDescriptor } from '../donor-provider.interface.ts';

/**
 * Specialized provider for Strapi CMS v4/v5 admin panels and APIs.
 * Official features reference: https://docs.strapi.io/cms/features
 */
export class StrapiDonorProvider implements DonorProvider {
  readonly name = 'strapi';
  readonly description = 'Specialized provider for Strapi CMS v4/v5 admin panels and APIs';
  readonly documentationUrl = 'https://docs.strapi.io/cms/features';
  readonly defaultLoginUrl = '/admin/auth/login';

  async authenticate(page: Page, options: AuthOptions): Promise<void> {
    if (options.token) {
      await page.addInitScript((token) => {
        // Strapi stores the admin auth token in localStorage under "jwtToken" (JSON string) or "strapi_jwt"
        window.localStorage.setItem('jwtToken', JSON.stringify(token));
        window.localStorage.setItem('strapi_jwt', token);
      }, options.token);
    } else if (options.email && options.password) {
      const loginUrl = options.loginUrl || this.defaultLoginUrl;
      await page.goto(loginUrl, { waitUntil: 'networkidle' });
      await page.fill('input[name="email"], input[type="email"]', options.email);
      await page.fill('input[name="password"], input[type="password"]', options.password);
      await page.click('button[type="submit"], button:has-text("Sign in")');
      await page.waitForLoadState('networkidle');
    }
  }

  classifyEndpoint(pathname: string): EndpointClassification {
    if (pathname.startsWith('/api/') || pathname.startsWith('/auth/')) {
      return { plane: 'public', zone: 'content-api' };
    }
    if (pathname.startsWith('/content-manager/')) {
      return { plane: 'admin', zone: 'content-manager' };
    }
    if (pathname.startsWith('/content-type-builder/')) {
      return { plane: 'admin', zone: 'content-type-builder' };
    }
    if (pathname.startsWith('/admin/')) {
      return { plane: 'admin', zone: 'admin-core' };
    }
    if (pathname.startsWith('/users-permissions/')) {
      return { plane: 'admin', zone: 'users-permissions' };
    }
    if (pathname.startsWith('/i18n/')) {
      return { plane: 'admin', zone: 'i18n' };
    }
    return { plane: 'internal', zone: 'strapi-misc' };
  }

  isSafeInteraction(element: InteractiveElementDescriptor): boolean {
    const label = (element.label || '').toLowerCase();
    const destructiveWords = ['delete', 'remove', 'unpublish', 'destroy', 'drop', 'reset'];
    return !destructiveWords.some((word) => label.includes(word));
  }
}
