import type { DonorProvider } from './donor-provider.interface.ts';
import { GenericDonorProvider } from './generic/generic.provider.ts';
import { StrapiDonorProvider } from './strapi/strapi.provider.ts';

export * from './donor-provider.interface.ts';

const providers: Record<string, () => DonorProvider> = {
  generic: () => new GenericDonorProvider(),
  strapi: () => new StrapiDonorProvider(),
};

export function getDonorProvider(name?: string): DonorProvider {
  const normalized = (name || 'generic').toLowerCase();
  const factory = providers[normalized];
  if (factory) {
    return factory();
  }
  console.warn(`[donor-registry] Unknown provider "${name}", falling back to "generic"`);
  return new GenericDonorProvider();
}

export function listSupportedProviders(): string[] {
  return Object.keys(providers);
}
