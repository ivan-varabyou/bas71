---
name: app-snapshot
description: >-
  Use this skill when the user wants to create a complete functional snapshot
  (contract, tests, UI inventory, API map) of any donor web application for
  reimplementation in a different stack. The skill uses an IoC Provider
  architecture: the core engine is universal, while donor-specific behaviors
  (auth, routing, plane classification) are plugged in via Donor Providers.
  Execution is adaptive: it first normalizes and presents the route manifest
  for human review, then pilots on 1-2 screens, and finally self-optimizes
  during deep route-by-route analysis.
---

# App Snapshot — Universal Provider-Driven Donor → Contract Skill

Create an exhaustive, test-backed functional snapshot of **any donor web application**
so another team or agent can reimplement equivalent functionality in a **target stack**
with 100% contract parity.

## Core Architectural Phases

```
┌────────────────────────────────────────────────────────────────────────┐
│  Phase 1: Manifest Discovery & Route Normalization (HUMAN CHECKPOINT)  │
│  - Crawl app navigation & extract all distinct screens                 │
│  - Normalize URLs into patterns (/collection-types/:model, /roles/:id)  │
│  - Group by zones & present structured table for user confirmation     │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ User confirms / adjusts scope
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│  Phase 2: Pilot Validation (1-2 screens) & Self-Optimization           │
│  - Run on 1 List + 1 Form screen                                       │
│  - Validate: DOM elements, click simulation, XHR/Fetch recording       │
│  - Self-tune: extract auth headers, CSRF tokens, calibrate timeouts    │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ Pilot quality gate passed
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│  Phase 3: Deep Route-by-Route Analysis (Iterative)                     │
│  - Deep dive screen-by-screen based on confirmed manifest              │
│  - Map every button, input, modal to its underlying API request        │
│  - Write Given/When/Then acceptance use cases                          │
│  - Generate dual-target Vitest contract tests                          │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ Cross-route inventories available
                                    ▼
┌────────────────────────────────────────────────────────────────────────┐
│  Phase 4: Cross-Page Component Clustering & Shared UI Normalization    │
│  - Scan interactive elements & DOM structures across all routes        │
│  - Identify recurring patterns (Rule of 2: appears on >= 2 pages)       │
│  - Cluster into Atomic design system (@ui/shared/vf-*)                 │
│  - Generate shared-components.yaml catalog & prevent page-level silos  │
└────────────────────────────────────────────────────────────────────────┘
```

---

## Token Economy & Model Tiering (Cost Optimization)

To conserve tokens and budget, subagents and tasks MUST use model tiering according to task complexity:

| Tier | Model | Tasks | Token Cost |
|---|---|---|---|
| **Tier 1 (Mechanical)** | `flash_lite` | Running crawler scripts, capturing DOM, extracting JSON files, parsing raw HARs, checking statuses, running Vitest commands. | **Lowest (~10x cheaper)** |
| **Tier 2 (Synthesis)** | `flash` | Route normalization, parsing API schemas, generating standard CRUD test stubs, authoring Given/When/Then use cases. | **Low (Fast & Cheap)** |
| **Tier 3 (Deep Analysis)**| `pro` / `inherit` | Complex architectural gap analysis vs OpenSpec, multi-role security matrix reviews (CSRF, step-up), final release sign-off. | **Higher (Use sparingly)** |

> [!TIP]
> When delegating subtasks with `invoke_subagent`, **always set `Model: 'flash_lite'` or `Model: 'flash'`** for mechanical capture, crawling, and API parsing. Never run mechanical scraping on `pro`.


## Phase 1 — Manifest Discovery & Normalization (Checkpoint)

Before doing any heavy crawling or deep inspections, the skill discovers and normalizes
all screens in the application:

```bash
node --experimental-strip-types scripts/discover-manifest.ts \
  --url "<donor-url>" \
  --provider "<provider-name>" \
  --auth-token "$TOKEN" \
  --output "manifest.json"
```

### What the agent presents to the user:

The agent renders a clean Markdown table of all normalized routes grouped by zone:

| Zone | Normalized Pattern | Action Type | Priority | Status |
|---|---|---|---|---|
| `content-manager` | `/content-manager/collection-types/:uid` | List view | High | In Scope |
| `content-manager` | `/content-manager/collection-types/:uid/create` | Form / Create | High (Pilot) | In Scope |
| `content-manager` | `/content-manager/collection-types/:uid/:id` | Form / Edit | High | In Scope |
| `content-type-builder` | `/content-type-builder/content-types` | Schema List | High | In Scope |
| `settings` | `/settings/roles` | Matrix / List | Normal | In Scope |
| `settings` | `/settings/users` | List / CRUD | Normal | In Scope |
| `plugins` | `/marketplace` | External store | Low | **EXCLUDED** |

> **User Checkpoint:** The user confirms or adjusts:
> - Are all required screens captured?
> - Should any screens be excluded (e.g. marketplace, binary media)?
> - Which 2 screens should be selected for the **Pilot**?

---

## Phase 2 — Pilot Run (1-2 screens) & Self-Optimization

Once the user approves the manifest, run a pilot on the selected 1-2 screens:

```bash
# Capture pilot page
node --experimental-strip-types scripts/capture-page.ts \
  --url "<donor-url>/path/to/pilot" \
  --provider "<provider-name>" \
  --auth-token "$TOKEN" \
  --output "captures/pilot-screen" \
  --interactions all

# Extract and classify API
node --experimental-strip-types scripts/extract-api.ts \
  --input "captures/pilot-screen/requests.json" \
  --provider "<provider-name>" \
  --output "api-contract/pilot-contract.json"

# Generate contract tests
node --experimental-strip-types scripts/gen-contract-test.ts \
  --api "api-contract/pilot-contract.json" \
  --output-dir "tests/contract-api"
```

### Self-Optimization Checks during Pilot:
1. **Network timing**: If page requests took longer than 2s, calibrate wait thresholds.
2. **Auth mechanisms**: Automatically detect where JWT/session tokens are sent (Authorization header vs Cookie) and feed into test generators.
3. **Dynamic elements**: Check if modal triggers spawn new child forms not initially in the route manifest, and register them.
4. **Report Pilot results to human**: Element count, API endpoints discovered, sample test run.

---

## Phase 3 — Deep Route-by-Route Analysis

Iterate through the confirmed manifest routes:
1. Execute `capture-page.ts` for each route.
2. Extract all interactive elements: buttons (save, publish, delete, filter, sort), form fields, relation selectors.
3. Record underlying API requests triggered by each interaction.
4. Author Given/When/Then acceptance stories per screen.
5. Generate dual-target Vitest tests and baseline HARs.

---

## Phase 4 — Cross-Page Component Clustering & Shared UI Normalization

To prevent component duplication and page-level silos (e.g. creating `cm-button`, `ctb-button`, `settings-button`, or separate pagination/filter components per feature), the skill enforces **Cross-Page Component Clustering**:

```bash
node --experimental-strip-types scripts/cluster-components.ts \
  --captures "captures/" \
  --output "ui-inventory/shared-components.yaml" \
  --threshold 2
```

### The "Rule of 2" (Cross-Page Threshold)
- If an interactive UI pattern, composite widget, or dialog structure appears on **two or more distinct routes**, it **MUST NOT** be implemented as a page-private component.
- It MUST be extracted into the shared UI library (`@ui/shared` or `@ui/components`) using the unified prefix `vf-*` (e.g., `vf-button`, `vf-pagination`, `vf-data-table`, `vf-modal-dialog`, `vf-filter-builder`, `vf-subnav`).

### Archetype Taxonomy & Mapping:
| Archetype | Category | Target Shared Path | Page-Local Names Unified | Purpose & Inputs/Outputs |
|---|---|---|---|---|
| **Button** | Atom | `@ui/shared/vf-button` | `cm-button`, `btn-create`, `btn-filter`, `btn-back` | Variants (`primary`, `secondary`, `danger`, `ghost`, `icon`), sizes (`sm`, `md`), loading state. |
| **Search Input** | Molecule | `@ui/shared/vf-search-input` | `cm-search-input`, `search-box-row`, `subnav-search` | Expandable/inline search with debounce and clear trigger. |
| **Pagination** | Molecule | `@ui/shared/vf-pagination` | `cm-pagination`, `table-pagination` | Page links, entries-per-page select, total count label. |
| **Filter Builder** | Molecule | `@ui/shared/vf-filter-builder` | `cm-filter-builder`, `filter-popover` | Attribute/operator/value builder, active filter chips bar. |
| **Column Config** | Molecule | `@ui/shared/vf-column-config-dialog` | `cm-column-config-dialog`, `configure-view` | Checkbox toggles for column visibility, reset to defaults. |
| **Data Table** | Organism | `@ui/shared/vf-data-table` | `cm-table`, `content-table` | Sortable columns, select-all checkbox, row click navigation, row action menu `···`. |
| **Modal / Drawer** | Organism | `@ui/shared/vf-modal-dialog` | `cm-modal`, `ctb-modal`, `edit-modal` | Backdrop, header, tab bar, scrollable content slot, footer actions (Save/Cancel/Delete). |
| **Confirm Dialog** | Molecule | `@ui/shared/vf-confirm-dialog` | `delete-confirm-overlay`, `confirm-dialog` | Destructive action confirmation dialog with alert icon and confirm/cancel triggers. |
| **Sub Navigation** | Molecule | `@ui/shared/vf-subnav` | `cm-subnav`, `ctb-subnav`, `settings-subnav` | Section collapsible groups, count badges, active route indicator, search bar. |
| **Status Badge** | Atom | `@ui/shared/vf-status-badge` | `status-badge`, `count-badge` | Status indicators (`Draft`, `Published`, `Active`, `Disabled`). |
| **Media Picker** | Organism | `@ui/shared/vf-media-picker-modal` | `cm-media-picker-modal`, `media-library-picker` | Asset grid, upload tab, multi-selection, search & filters. |

## Output Artifacts

```
<output-dir>/
├── README.md                      # Target developer instructions
├── page-manifest.yaml             # Confirmed normalized route catalog
├── api-contract/
│   ├── public-api.json            # Consumer-facing API + schemas
│   └── admin-api.json             # Operator-facing API + schemas
├── ui-inventory/
│   ├── elements/                  # Interactive element descriptors per route
│   ├── shared-components.yaml     # Clustered reusable components for @ui/shared
│   ├── use-cases/                 # Given/When/Then acceptance specifications
│   └── state-machines/            # Lifecycle diagrams (Draft → Published)
└── tests/
    └── contract-api/              # Vitest contract tests for target verification
```

---

## Donor Providers & Official Feature References

Donor providers encapsulate vendor-specific details and map them to standard contracts and documentation:
- **`generic`**: Universal fallback provider using heuristic DOM & REST discovery (`providers/generic/generic.provider.ts`).
- **`strapi`**: Specialized Strapi 5/v4 provider (`providers/strapi/strapi.provider.ts`).
  - **Official Feature Docs:** [`https://docs.strapi.io/cms/features`](https://docs.strapi.io/cms/features)
  - **Live Reference Snapshot & Acceptance Contracts:** [`docs/agents/apps/strapi-snapshot/`](../../../docs/agents/apps/strapi-snapshot/README.md)
  - **Look-alike Task & Shot Map:** [`docs/agents/apps/strapi-reference.md`](../../../docs/agents/apps/strapi-reference.md)

---

---

## Architectural Hard Locks for Target Reimplementation (Zero Hardcoding)

When generating or reimplementing any target application based on donor snapshots:
1. **Zero Hardcoded Entity Mocks**: Entity relation options, dynamic block schemas, and dropdown items MUST be derived dynamically from backend schema/store ports (`relationOptionsMap`, `cmStore.entries`), never hardcoded mock string arrays inside components.
2. **Centralized Route Enum/Constants**: Every route path MUST be exported from a central constants map (e.g. `ADMIN_UI_PATHS`), never written as inline string literals across routes or templates.
3. **Strict Union Types & Constants**: Every dynamic block, status badge, or relation type MUST be declared in dedicated `*.interfaces.ts` and `*.constants.ts` (e.g. `DynamicBlockType = "quote" | "media" | "richtext"`).
4. **All UI Text in Translation Dictionaries**: Raw button labels and text strings MUST reside in i18n dictionaries (`TranslationDictionary`).
5. **Automated Architectural Linter Checks (`architecture.test.ts`)**: The repository includes fail-closed architectural unit tests (`ADM-ARCH-01` through `ADM-ARCH-14`) that reject any hardcoded external asset URLs, mock data arrays, or unsafe casts.

---

## Integration with Dark Factory Acceptance Gate (`donor-acceptance-gate`)

The inventory, screenshots, and action definitions produced by this skill serve as the direct behavior specification for `@viafactory/donor-acceptance-gate`:
1. **Offline Hydration (From Existing Snapshots)**:
   ```bash
   pnpm --filter @viafactory/donor-acceptance-gate hydrate
   ```
   Compiles `ui-inventory/*.yaml` and reference screenshots into multi-viewport specs (`m360`, `m390`, `t768`, `d1024`, `d1440`).
2. **Live Crawling (When Donor is Running)**:
   ```bash
   pnpm --filter @viafactory/donor-acceptance-gate crawl
   ```
   Captures fresh DOM, layout bounding boxes, and action mutation/request effects directly from the live donor instance.
3. **Deterministic Gate Verification**:
   ```bash
   pnpm verify
   ```
   Validates the target clone against the behavior specification (Zero stubs, layout, coverage, pixel diff, action effect parity).

