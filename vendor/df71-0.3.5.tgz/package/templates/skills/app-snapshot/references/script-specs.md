# Script Specifications & Automation Runbook

This document details the command-line helper scripts shipped with the `app-snapshot` skill.
All scripts can be executed natively in Node 24 using:
`node --experimental-strip-types <script.ts>` or via `npx tsx <script.ts>`.

---

## Architecture: Donor Providers

The scripts rely on a modular Provider Architecture (`providers/`):
- `providers/donor-provider.interface.ts`: Contract defining `authenticate()`, `classifyEndpoint()`, and `isSafeInteraction()`.
- `providers/generic/generic.provider.ts`: Universal fallback adapter for any web/SPA/admin application.
- `providers/strapi/strapi.provider.ts`: Specialized adapter for Strapi v4/v5 CMS.
- Providers are selected via the `--provider <name>` flag (defaults to `generic`).

---

## 1. `scripts/capture-page.ts`

Uses Playwright to render a donor page, record network requests (XHR/Fetch), extract all interactive DOM elements, and simulate safe user interactions (clicks, form inputs).

### Usage

```bash
node --experimental-strip-types scripts/capture-page.ts \
  --url "http://localhost:1337/admin/content-manager/collection-types/api::article.article" \
  --provider "strapi" \
  --output "./captures/cm-article-list" \
  --auth-token "<JWT_TOKEN>" \
  --interactions all
```

### Options

| Flag | Type | Description |
|---|---|---|
| `--url` | string | **Required.** The absolute URL to capture. |
| `--provider` | string | Provider name (`generic` or `strapi`). Default: `generic`. |
| `--output` | string | Target directory to write artifacts. Default: `./capture-output`. |
| `--auth-token` | string | Bearer / localStorage JWT token for authenticated views. |
| `--login-url` | string | Login URL if token not available. |
| `--email` | string | Email for login page authentication. |
| `--password` | string | Password for login page authentication. |
| `--interactions`| `none` \| `inspect` \| `all` | `inspect` (DOM only) or `all` (clicks safe buttons). |
| `--no-headless` | boolean | Launch visible browser window for debugging. |

### Generated Outputs

- `screenshot.png`: Full-page capture.
- `elements.json`: Comprehensive list of all interactive buttons, inputs, links, dropdowns, and attributes.
- `requests.json`: All recorded API calls triggered by page load and user clicks.
- `network.har`: Standard HAR archive of the network session.
- `interactions.json`: Execution log of simulated clicks and their network side-effects.

---

## 2. `scripts/extract-api.ts`

Aggregates recorded network calls from `requests.json`, classifies endpoints into Public vs Admin API planes via the provider, extracts query parameters, payloads, and infers JSON Schemas.

### Usage

```bash
node --experimental-strip-types scripts/extract-api.ts \
  --input "./captures/cm-article-list/requests.json" \
  --provider "strapi" \
  --output "./api-contract/cm-article-list.json"
```

### Options

| Flag | Type | Description |
|---|---|---|
| `--input`, `--requests` | string | Path to recorded `requests.json`. |
| `--provider` | string | Provider name (`generic` or `strapi`). Default: `generic`. |
| `--output` | string | Destination file for the JSON contract summary. |

---

## 3. `scripts/gen-contract-test.ts`

Generates ready-to-run Vitest acceptance tests based on the extracted API contract.

### Usage

```bash
node --experimental-strip-types scripts/gen-contract-test.ts \
  --api "./api-contract/cm-article-list.json" \
  --output-dir "./tests/contract-api"
```

### Test Execution

Run the contract tests against the donor:

```bash
SNAPSHOT_TARGET_URL=http://localhost:1337 npx vitest run tests/contract-api
```

Run the same contract tests against the Go target:

```bash
SNAPSHOT_TARGET_URL=http://localhost:8084 npx vitest run tests/contract-api
```
