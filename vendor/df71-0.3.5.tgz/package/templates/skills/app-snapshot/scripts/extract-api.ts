#!/usr/bin/env tsx
import fs from 'fs';
import path from 'path';
import { getDonorProvider } from '../providers/index.ts';

interface RecordedRequest {
  url: string;
  method: string;
  headers: Record<string, string>;
  postData?: string;
  status: number;
  responseHeaders: Record<string, string>;
  responseBody?: any;
  resourceType: string;
  timestamp: string;
  trigger?: string;
}

interface EndpointSummary {
  method: string;
  urlPath: string;
  plane: 'public' | 'admin' | 'internal';
  zone: string;
  triggers: string[];
  sampleRequest?: any;
  sampleResponse?: any;
  responseSchema?: any;
  statusCodes: number[];
  count: number;
}

function inferType(val: any): any {
  if (val === null) return { type: 'null' };
  if (Array.isArray(val)) {
    return {
      type: 'array',
      items: val.length > 0 ? inferType(val[0]) : {},
    };
  }
  if (typeof val === 'object') {
    const properties: Record<string, any> = {};
    for (const key of Object.keys(val)) {
      properties[key] = inferType(val[key]);
    }
    return {
      type: 'object',
      properties,
    };
  }
  return { type: typeof val };
}

function normalizePath(fullUrl: string): { pathname: string; query: Record<string, string> } {
  try {
    const parsed = new URL(fullUrl);
    const query: Record<string, string> = {};
    parsed.searchParams.forEach((v, k) => {
      query[k] = v;
    });
    return { pathname: parsed.pathname, query };
  } catch {
    const [pathname, search] = fullUrl.split('?');
    return { pathname, query: {} };
  }
}

function parseArgs() {
  const args = process.argv.slice(2);
  let requestsPath = '';
  let outputPath = './api-contract.json';
  let providerName = 'generic';

  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--input' || args[i] === '--requests') {
      requestsPath = args[++i];
    } else if (args[i] === '--output') {
      outputPath = args[++i];
    } else if (args[i] === '--provider') {
      providerName = args[++i];
    }
  }

  return { requestsPath, outputPath, providerName };
}

function main() {
  const { requestsPath, outputPath, providerName } = parseArgs();
  const provider = getDonorProvider(providerName);

  if (!requestsPath) {
    console.error('Usage: extract-api.ts --input <requests.json> --output <output.json> [--provider <name>]');
    process.exit(1);
  }

  const raw = fs.readFileSync(requestsPath, 'utf-8');
  const requests: RecordedRequest[] = JSON.parse(raw);

  const endpointMap = new Map<string, EndpointSummary>();

  for (const req of requests) {
    const { pathname } = normalizePath(req.url);
    const { plane, zone } = provider.classifyEndpoint(pathname);
    const key = `${req.method.toUpperCase()} ${pathname}`;

    if (!endpointMap.has(key)) {
      let sampleRequest: any = undefined;
      if (req.postData) {
        try {
          sampleRequest = JSON.parse(req.postData);
        } catch {
          sampleRequest = req.postData;
        }
      }

      endpointMap.set(key, {
        method: req.method.toUpperCase(),
        urlPath: pathname,
        plane,
        zone,
        triggers: req.trigger ? [req.trigger] : [],
        sampleRequest,
        sampleResponse: req.responseBody,
        responseSchema: req.responseBody ? inferType(req.responseBody) : undefined,
        statusCodes: [req.status],
        count: 1,
      });
    } else {
      const existing = endpointMap.get(key)!;
      existing.count++;
      if (req.trigger && !existing.triggers.includes(req.trigger)) {
        existing.triggers.push(req.trigger);
      }
      if (!existing.statusCodes.includes(req.status)) {
        existing.statusCodes.push(req.status);
      }
      if (!existing.sampleResponse && req.responseBody) {
        existing.sampleResponse = req.responseBody;
        existing.responseSchema = inferType(req.responseBody);
      }
    }
  }

  const endpoints = Array.from(endpointMap.values());
  const publicEndpoints = endpoints.filter((e) => e.plane === 'public');
  const adminEndpoints = endpoints.filter((e) => e.plane === 'admin');

  const summary = {
    provider: provider.name,
    totalRequests: requests.length,
    uniqueEndpoints: endpoints.length,
    publicEndpointsCount: publicEndpoints.length,
    adminEndpointsCount: adminEndpoints.length,
    endpoints,
  };

  fs.mkdirSync(path.dirname(outputPath), { recursive: true });
  fs.writeFileSync(outputPath, JSON.stringify(summary, null, 2));

  console.log(`[extract-api] (${provider.name}) Processed ${requests.length} requests into ${endpoints.length} unique endpoints.`);
  console.log(`  -> Public: ${publicEndpoints.length}`);
  console.log(`  -> Admin: ${adminEndpoints.length}`);
  console.log(`[extract-api] Output saved to: ${outputPath}`);
}

main();
