#!/usr/bin/env tsx
import { chromium } from 'playwright';
import fs from 'fs';
import path from 'path';
import { getDonorProvider } from '../providers/index.ts';

interface Options {
  url: string;
  output: string;
  provider: string;
  authToken?: string;
  loginUrl?: string;
  email?: string;
  password?: string;
  interactions?: 'none' | 'inspect' | 'all';
  headless?: boolean;
}

function parseArgs(): Options {
  const args = process.argv.slice(2);
  const options: Options = {
    url: '',
    output: './capture-output',
    provider: 'generic',
    interactions: 'inspect',
    headless: true,
  };

  for (let i = 0; i < args.length; i++) {
    switch (args[i]) {
      case '--url':
        options.url = args[++i];
        break;
      case '--output':
        options.output = args[++i];
        break;
      case '--provider':
        options.provider = args[++i];
        break;
      case '--auth-token':
        options.authToken = args[++i];
        break;
      case '--login-url':
        options.loginUrl = args[++i];
        break;
      case '--email':
        options.email = args[++i];
        break;
      case '--password':
        options.password = args[++i];
        break;
      case '--interactions':
        options.interactions = args[++i] as any;
        break;
      case '--no-headless':
        options.headless = false;
        break;
    }
  }

  if (!options.url) {
    console.error('Error: --url is required');
    process.exit(1);
  }

  return options;
}

interface RecordedRequest {
  url: string;
  method: string;
  headers: Record<string, string>;
  postData?: string;
  status: number;
  responseHeaders: Record<string, string>;
  responseBody?: any;
  resourceType: string;
  timestamp: string;
  trigger?: string;
}

interface InteractiveElement {
  id: string;
  tag: string;
  type?: string;
  role?: string;
  name?: string;
  label?: string;
  text?: string;
  placeholder?: string;
  selector: string;
  ariaLabel?: string;
  classes: string[];
  disabled: boolean;
  boundingBox?: { x: number; y: number; width: number; height: number };
}

async function main() {
  const options = parseArgs();
  const provider = getDonorProvider(options.provider);

  fs.mkdirSync(options.output, { recursive: true });

  console.log(`[capture-page] Provider: ${provider.name} (${provider.description})`);
  console.log(`[capture-page] Target URL: ${options.url}`);
  console.log(`[capture-page] Output dir: ${options.output}`);

  const browser = await chromium.launch({
    headless: options.headless,
  });

  const harPath = path.join(options.output, 'network.har');
  const context = await browser.newContext({
    recordHar: { path: harPath, mode: 'full' },
    viewport: { width: 1440, height: 900 },
  });

  const page = await context.newPage();
  const recordedRequests: RecordedRequest[] = [];
  let currentTrigger = 'page_load';

  page.on('response', async (response) => {
    const req = response.request();
    const resourceType = req.resourceType();
    if (['xhr', 'fetch'].includes(resourceType)) {
      let responseBody: any = null;
      try {
        const text = await response.text();
        try {
          responseBody = JSON.parse(text);
        } catch {
          responseBody = text.slice(0, 500);
        }
      } catch {
        responseBody = null;
      }

      recordedRequests.push({
        url: req.url(),
        method: req.method(),
        headers: await req.allHeaders(),
        postData: req.postData() ?? undefined,
        status: response.status(),
        responseHeaders: await response.allHeaders(),
        responseBody,
        resourceType,
        timestamp: new Date().toISOString(),
        trigger: currentTrigger,
      });
    }
  });

  // Delegate Authentication to Provider
  await provider.authenticate(page, {
    token: options.authToken,
    email: options.email,
    password: options.password,
    loginUrl: options.loginUrl,
  });

  // Navigate to Target Page
  console.log(`[capture-page] Navigating to ${options.url}...`);
  currentTrigger = 'initial_navigation';
  await page.goto(options.url, { waitUntil: 'networkidle', timeout: 30000 });
  await page.waitForTimeout(1000);

  // Take screenshot
  const screenshotPath = path.join(options.output, 'screenshot.png');
  await page.screenshot({ path: screenshotPath, fullPage: true });
  console.log(`[capture-page] Saved full screenshot to ${screenshotPath}`);

  // Catalog interactive elements
  console.log('[capture-page] Inspecting interactive DOM elements...');
  const elements = await page.evaluate(() => {
    const list: InteractiveElement[] = [];
    const candidates = document.querySelectorAll(
      'button, input, select, textarea, a[href], [role="button"], [role="link"], [role="checkbox"], [role="switch"], [role="tab"], [role="combobox"], [data-testid]'
    );

    let counter = 0;
    candidates.forEach((el) => {
      const htmlEl = el as HTMLElement;
      if (!htmlEl.offsetParent && htmlEl.tagName !== 'BODY') {
        return; // not visible
      }

      const rect = htmlEl.getBoundingClientRect();
      const id = htmlEl.id || `elem_${++counter}`;
      const tag = htmlEl.tagName.toLowerCase();
      const type = (htmlEl as HTMLInputElement).type || undefined;
      const role = htmlEl.getAttribute('role') || undefined;
      const name = (htmlEl as HTMLInputElement).name || undefined;
      const ariaLabel = htmlEl.getAttribute('aria-label') || undefined;
      const placeholder = (htmlEl as HTMLInputElement).placeholder || undefined;
      const text = (htmlEl.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 100);
      const classes = Array.from(htmlEl.classList);
      const disabled = (htmlEl as HTMLButtonElement).disabled || false;

      let selector = tag;
      if (htmlEl.id) {
        selector += `#${htmlEl.id}`;
      } else if (htmlEl.getAttribute('data-testid')) {
        selector += `[data-testid="${htmlEl.getAttribute('data-testid')}"]`;
      } else if (name) {
        selector += `[name="${name}"]`;
      } else if (ariaLabel) {
        selector += `[aria-label="${ariaLabel}"]`;
      } else if (classes.length > 0) {
        selector += `.${classes.slice(0, 2).join('.')}`;
      }

      list.push({
        id,
        tag,
        type,
        role,
        name,
        label: ariaLabel || text || name || id,
        text: text || undefined,
        placeholder,
        selector,
        ariaLabel,
        classes,
        disabled,
        boundingBox: {
          x: Math.round(rect.x),
          y: Math.round(rect.y),
          width: Math.round(rect.width),
          height: Math.round(rect.height),
        },
      });
    });

    return list;
  });

  fs.writeFileSync(path.join(options.output, 'elements.json'), JSON.stringify(elements, null, 2));
  console.log(`[capture-page] Cataloged ${elements.length} interactive elements.`);

  const interactionsLog: Array<{ elementId: string; action: string; status: string; requests: number }> = [];

  // Execute safe interactions filtered by Provider
  if (options.interactions === 'all') {
    console.log('[capture-page] Executing safe interactions filtered by provider...');
    const candidateButtons = elements.filter((e) => {
      if (e.disabled) return false;
      if (e.tag !== 'button' && e.role !== 'button') return false;
      if (provider.isSafeInteraction && !provider.isSafeInteraction(e)) return false;
      return true;
    });

    for (const btn of candidateButtons.slice(0, 15)) {
      const beforeReqCount = recordedRequests.length;
      currentTrigger = `click:${btn.id}:${btn.label}`;
      try {
        console.log(`  -> Clicking [${btn.tag}] "${btn.label}" (${btn.selector})...`);
        const locator = page.locator(btn.selector).first();
        if (await locator.isVisible()) {
          await locator.click({ timeout: 2000 });
          await page.waitForTimeout(500);
          interactionsLog.push({
            elementId: btn.id,
            action: 'click',
            status: 'success',
            requests: recordedRequests.length - beforeReqCount,
          });
        }
      } catch (err: any) {
        interactionsLog.push({
          elementId: btn.id,
          action: 'click',
          status: `failed: ${err.message?.slice(0, 60)}`,
          requests: recordedRequests.length - beforeReqCount,
        });
      }
    }
  }

  fs.writeFileSync(path.join(options.output, 'interactions.json'), JSON.stringify(interactionsLog, null, 2));
  fs.writeFileSync(path.join(options.output, 'requests.json'), JSON.stringify(recordedRequests, null, 2));

  await context.close();
  await browser.close();

  console.log(`[capture-page] Finished successfully. Output in ${options.output}`);
}

main().catch((err) => {
  console.error('[capture-page] Unhandled error:', err);
  process.exit(1);
});
