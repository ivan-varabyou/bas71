#!/usr/bin/env tsx
import { chromium } from 'playwright';
import fs from 'fs';
import path from 'path';
import { getDonorProvider } from '../providers/index.ts';

interface Options {
  url: string;
  provider: string;
  authToken?: string;
  loginUrl?: string;
  email?: string;
  password?: string;
  output: string;
  headless?: boolean;
}

function parseArgs(): Options {
  const args = process.argv.slice(2);
  const options: Options = {
    url: '',
    provider: 'generic',
    output: './page-manifest.yaml',
    headless: true,
  };

  for (let i = 0; i < args.length; i++) {
    switch (args[i]) {
      case '--url':
        options.url = args[++i];
        break;
      case '--provider':
        options.provider = args[++i];
        break;
      case '--auth-token':
        options.authToken = args[++i];
        break;
      case '--login-url':
        options.loginUrl = args[++i];
        break;
      case '--email':
        options.email = args[++i];
        break;
      case '--password':
        options.password = args[++i];
        break;
      case '--output':
        options.output = args[++i];
        break;
      case '--no-headless':
        options.headless = false;
        break;
    }
  }

  if (!options.url) {
    console.error('Usage: discover-manifest.ts --url <app-url> [--provider strapi|generic] [--output manifest.json]');
    process.exit(1);
  }

  return options;
}

export interface ManifestRoute {
  id: string;
  zone: string;
  title: string;
  rawUrl: string;
  normalizedPattern: string;
  type: 'list' | 'detail' | 'form' | 'settings' | 'auth' | 'other';
  priority: 'pilot' | 'high' | 'normal' | 'low';
  status: 'discovered' | 'in_scope' | 'excluded';
}

function normalizeRoutePattern(pathname: string): { normalizedPattern: string; type: ManifestRoute['type'] } {
  // Replace UUIDs / hashes
  let pattern = pathname.replace(/[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}/g, ':uuid');
  // Replace numeric IDs
  pattern = pattern.replace(/\/\d+(?=\/|$)/g, '/:id');

  let type: ManifestRoute['type'] = 'other';
  if (pattern.includes('/create') || pattern.includes('/new')) {
    type = 'form';
  } else if (pattern.includes('/:id') || pattern.includes('/:uuid')) {
    type = 'detail';
  } else if (pattern.includes('/settings') || pattern.includes('/configuration')) {
    type = 'settings';
  } else if (pattern.includes('/login') || pattern.includes('/auth')) {
    type = 'auth';
  } else if (pattern.includes('/list') || pattern.includes('/collection-types') || pattern.match(/\/[a-z-]+s$/)) {
    type = 'list';
  }

  return { normalizedPattern: pattern, type };
}

async function main() {
  const options = parseArgs();
  const provider = getDonorProvider(options.provider);

  console.log(`[discover-manifest] Discovering routes for: ${options.url} using provider [${provider.name}]`);

  const browser = await chromium.launch({ headless: options.headless });
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const page = await context.newPage();

  // Authenticate
  await provider.authenticate(page, {
    token: options.authToken,
    email: options.email,
    password: options.password,
    loginUrl: options.loginUrl,
  });

  // Navigate to initial app view
  await page.goto(options.url, { waitUntil: 'networkidle', timeout: 30000 });
  await page.waitForTimeout(1500);

  // Extract all navigational links and interactive routes
  const discoveredLinks = await page.evaluate(() => {
    const links: Array<{ href: string; text: string; role?: string }> = [];
    document.querySelectorAll('a[href], nav [role="link"], [data-testid*="nav"]').forEach((el) => {
      const a = el as HTMLAnchorElement;
      const href = a.getAttribute('href') || '';
      const text = (el.textContent || '').trim().replace(/\s+/g, ' ');
      if (href && !href.startsWith('http://') && !href.startsWith('https://') && !href.startsWith('mailto:')) {
        links.push({ href, text });
      }
    });
    return links;
  });

  const uniqueRoutes = new Map<string, ManifestRoute>();

  for (const item of discoveredLinks) {
    const cleanPath = item.href.split('?')[0].split('#')[0];
    if (!cleanPath || cleanPath === '/' || cleanPath === '#') continue;

    const { normalizedPattern, type } = normalizeRoutePattern(cleanPath);
    const classification = provider.classifyEndpoint(cleanPath);

    const id = cleanPath.replace(/^\//, '').replace(/[^a-zA-Z0-9_-]/g, '-');

    if (!uniqueRoutes.has(normalizedPattern)) {
      uniqueRoutes.set(normalizedPattern, {
        id,
        zone: classification.zone,
        title: item.text || id,
        rawUrl: cleanPath,
        normalizedPattern,
        type,
        priority: type === 'list' ? 'high' : 'normal',
        status: 'discovered',
      });
    }
  }

  const manifestRoutes = Array.from(uniqueRoutes.values());
  const manifest = {
    discoveredAt: new Date().toISOString(),
    donorUrl: options.url,
    provider: provider.name,
    totalDiscovered: manifestRoutes.length,
    zones: Array.from(new Set(manifestRoutes.map((r) => r.zone))),
    routes: manifestRoutes,
  };

  fs.mkdirSync(path.dirname(options.output), { recursive: true });
  fs.writeFileSync(options.output, JSON.stringify(manifest, null, 2));

  console.log(`[discover-manifest] Discovered ${manifestRoutes.length} unique normalized routes across ${manifest.zones.length} zones.`);
  console.log(`[discover-manifest] Manifest saved to: ${options.output}`);

  await browser.close();
}

main().catch((err) => {
  console.error('[discover-manifest] Error:', err);
  process.exit(1);
});
