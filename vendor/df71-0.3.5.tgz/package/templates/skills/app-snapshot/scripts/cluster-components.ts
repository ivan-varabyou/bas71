#!/usr/bin/env tsx
import fs from 'node:fs';
import path from 'node:path';

interface InteractiveElement {
  id?: string;
  tag?: string;
  type?: string;
  role?: string;
  name?: string;
  label?: string;
  text?: string;
  placeholder?: string;
  selector?: string;
  ariaLabel?: string;
  classes?: string[];
}

interface PageCaptureInventory {
  route: string;
  pageName: string;
  elements: InteractiveElement[];
}

interface ComponentArchetypeMatch {
  archetype: string;
  sharedComponentName: string;
  category: 'atom' | 'molecule' | 'organism';
  description: string;
  targetPath: string;
  inputs: string[];
  outputs: string[];
}

interface ClusteredComponentReport {
  sharedComponentName: string;
  archetype: string;
  category: 'atom' | 'molecule' | 'organism';
  targetPath: string;
  pageOccurrencesCount: number;
  routes: string[];
  currentLocalNames: string[];
  suggestedInputs: string[];
  suggestedOutputs: string[];
  extractionPriority: 'critical' | 'high' | 'medium';
}

const ARCHETYPES: ComponentArchetypeMatch[] = [
  {
    archetype: 'button',
    sharedComponentName: 'vf-button',
    category: 'atom',
    description: 'Universal interactive button with variants (primary, secondary, danger, ghost, icon) and sizes',
    targetPath: 'src/ui/shared/vf-button',
    inputs: ['variant', 'size', 'icon', 'disabled', 'loading', 'ariaLabel'],
    outputs: ['clicked'],
  },
  {
    archetype: 'search-input',
    sharedComponentName: 'vf-search-input',
    category: 'molecule',
    description: 'Collapsible or inline search input with debounce, clear button and icon',
    targetPath: 'src/ui/shared/vf-search-input',
    inputs: ['query', 'placeholder', 'collapsible', 'isExpanded'],
    outputs: ['queryChange', 'expandedChange'],
  },
  {
    archetype: 'pagination',
    sharedComponentName: 'vf-pagination',
    category: 'molecule',
    description: 'Data pagination with page buttons, total count label, and per-page selector dropdown',
    targetPath: 'src/ui/shared/vf-pagination',
    inputs: ['currentPage', 'totalPages', 'entriesPerPage', 'totalEntries', 'availableOptions'],
    outputs: ['pageChange', 'entriesPerPageChange'],
  },
  {
    archetype: 'filter-builder',
    sharedComponentName: 'vf-filter-builder',
    category: 'molecule',
    description: 'Multi-attribute filter popover with condition rows, operator selection, and active filter chips bar',
    targetPath: 'src/ui/shared/vf-filter-builder',
    inputs: ['availableFields', 'activeFilterCriteria'],
    outputs: ['addCriterion', 'removeCriterion', 'clearAllCriteria', 'closePopover'],
  },
  {
    archetype: 'column-config-dialog',
    sharedComponentName: 'vf-column-config-dialog',
    category: 'molecule',
    description: 'Interactive dialog for toggling visible table columns and resetting defaults',
    targetPath: 'src/ui/shared/vf-column-config-dialog',
    inputs: ['columns'],
    outputs: ['toggleColumn', 'resetDefaults', 'closeDialog'],
  },
  {
    archetype: 'data-table',
    sharedComponentName: 'vf-data-table',
    category: 'organism',
    description: 'Data grid with select-all checkbox, sortable column headers, row menus, dynamic cells and empty states',
    targetPath: 'src/ui/shared/vf-data-table',
    inputs: ['columns', 'data', 'selectedIds', 'sortField', 'sortDirection', 'isCompactMode'],
    outputs: ['rowClick', 'selectionChange', 'sortChange', 'actionMenuTrigger'],
  },
  {
    archetype: 'modal-dialog',
    sharedComponentName: 'vf-modal-dialog',
    category: 'organism',
    description: 'Modal overlay with header, title, tabs bar, body slot, and action footer buttons',
    targetPath: 'src/ui/shared/vf-modal-dialog',
    inputs: ['isOpen', 'title', 'subtitle', 'tabs', 'activeTab', 'primaryActionLabel', 'secondaryActionLabel'],
    outputs: ['close', 'tabChange', 'primaryAction', 'secondaryAction'],
  },
  {
    archetype: 'confirm-dialog',
    sharedComponentName: 'vf-confirm-dialog',
    category: 'molecule',
    description: 'Destructive / warning confirmation modal with alert icon, message, cancel and confirm buttons',
    targetPath: 'src/ui/shared/vf-confirm-dialog',
    inputs: ['isOpen', 'title', 'message', 'confirmLabel', 'cancelLabel', 'isDanger'],
    outputs: ['confirm', 'cancel'],
  },
  {
    archetype: 'subnav',
    sharedComponentName: 'vf-subnav',
    category: 'molecule',
    description: 'Left subnavigation sidebar with section headers, count pills, search input, and active link indicators',
    targetPath: 'src/ui/shared/vf-subnav',
    inputs: ['title', 'sections', 'activeItemKey', 'searchPlaceholder'],
    outputs: ['itemSelect', 'searchQueryChange'],
  },
  {
    archetype: 'status-badge',
    sharedComponentName: 'vf-status-badge',
    category: 'atom',
    description: 'Colored status pill badge (Draft, Published, Active, Disabled, Error, Warning)',
    targetPath: 'src/ui/shared/vf-status-badge',
    inputs: ['status', 'label', 'variant'],
    outputs: [],
  },
  {
    archetype: 'media-picker-modal',
    sharedComponentName: 'vf-media-picker-modal',
    category: 'organism',
    description: 'Asset browser modal for uploading, selecting, filtering and attaching media files',
    targetPath: 'src/ui/shared/vf-media-picker-modal',
    inputs: ['isOpen', 'multiple', 'acceptedTypes', 'selectedAssetIds'],
    outputs: ['close', 'selectAssets'],
  },
];

function classifyElement(element: InteractiveElement): ComponentArchetypeMatch | null {
  const selector = (element.selector || '').toLowerCase();
  const text = (element.text || '').toLowerCase();
  const classes = (element.classes || []).map((c) => c.toLowerCase()).join(' ');
  const aria = (element.ariaLabel || '').toLowerCase();
  const id = (element.id || '').toLowerCase();

  if (
    selector.includes('pagination') ||
    classes.includes('pagination') ||
    text.includes('entries per page') ||
    id.includes('pagination')
  ) {
    return ARCHETYPES.find((a) => a.archetype === 'pagination') || null;
  }

  if (
    selector.includes('filter') ||
    classes.includes('filter') ||
    text.includes('filters') ||
    id.includes('filter')
  ) {
    return ARCHETYPES.find((a) => a.archetype === 'filter-builder') || null;
  }

  if (
    selector.includes('column') ||
    classes.includes('configure') ||
    text.includes('configure the view') ||
    id.includes('configure')
  ) {
    return ARCHETYPES.find((a) => a.archetype === 'column-config-dialog') || null;
  }

  if (
    selector.includes('media-picker') ||
    classes.includes('media-picker') ||
    text.includes('add more assets') ||
    id.includes('media-picker')
  ) {
    return ARCHETYPES.find((a) => a.archetype === 'media-picker-modal') || null;
  }

  if (
    selector.includes('delete-confirm') ||
    text.includes('are you sure you want to delete') ||
    classes.includes('delete-confirm')
  ) {
    return ARCHETYPES.find((a) => a.archetype === 'confirm-dialog') || null;
  }

  if (
    selector.includes('subnav') ||
    classes.includes('subnav') ||
    selector.includes('collection-nav')
  ) {
    return ARCHETYPES.find((a) => a.archetype === 'subnav') || null;
  }

  if (
    element.tag === 'table' ||
    selector.includes('table') ||
    classes.includes('data-table') ||
    classes.includes('cm-table')
  ) {
    return ARCHETYPES.find((a) => a.archetype === 'data-table') || null;
  }

  if (
    classes.includes('modal') ||
    selector.includes('modal') ||
    classes.includes('drawer') ||
    element.role === 'dialog'
  ) {
    return ARCHETYPES.find((a) => a.archetype === 'modal-dialog') || null;
  }

  if (
    classes.includes('badge') ||
    classes.includes('pill') ||
    classes.includes('status')
  ) {
    return ARCHETYPES.find((a) => a.archetype === 'status-badge') || null;
  }

  if (
    classes.includes('search') ||
    selector.includes('search') ||
    element.placeholder?.toLowerCase().includes('search')
  ) {
    return ARCHETYPES.find((a) => a.archetype === 'search-input') || null;
  }

  if (
    element.tag === 'button' ||
    element.role === 'button' ||
    classes.includes('btn')
  ) {
    return ARCHETYPES.find((a) => a.archetype === 'button') || null;
  }

  return null;
}

export function clusterCapturedInventories(
  inventories: PageCaptureInventory[],
  threshold = 2,
): ClusteredComponentReport[] {
  const archetypeMap = new Map<
    string,
    {
      match: ComponentArchetypeMatch;
      routes: Set<string>;
      localNames: Set<string>;
    }
  >();

  for (const page of inventories) {
    for (const element of page.elements) {
      const match = classifyElement(element);
      if (!match) continue;

      let entry = archetypeMap.get(match.archetype);
      if (!entry) {
        entry = {
          match,
          routes: new Set<string>(),
          localNames: new Set<string>(),
        };
        archetypeMap.set(match.archetype, entry);
      }

      entry.routes.add(page.route);

      const localIdentifier =
        element.id ||
        (element.classes && element.classes.length > 0 ? element.classes[0] : element.tag) ||
        match.archetype;
      entry.localNames.add(localIdentifier);
    }
  }

  const reports: ClusteredComponentReport[] = [];

  for (const [, entry] of archetypeMap) {
    const routeCount = entry.routes.size;
    if (routeCount >= threshold) {
      reports.push({
        sharedComponentName: entry.match.sharedComponentName,
        archetype: entry.match.archetype,
        category: entry.match.category,
        targetPath: entry.match.targetPath,
        pageOccurrencesCount: routeCount,
        routes: Array.from(entry.routes).sort(),
        currentLocalNames: Array.from(entry.localNames).slice(0, 8),
        suggestedInputs: entry.match.inputs,
        suggestedOutputs: entry.match.outputs,
        extractionPriority: routeCount >= 3 ? 'critical' : 'high',
      });
    }
  }

  reports.sort((a, b) => b.pageOccurrencesCount - a.pageOccurrencesCount);
  return reports;
}

export function generateSharedCatalogYaml(reports: ClusteredComponentReport[]): string {
  let yaml = '# Shared UI Components Catalog (Auto-derived from cross-page donor crawl)\n';
  yaml += '# Rule of 2: Components detected across >= 2 pages are extracted to @ui/shared\n\n';
  yaml += 'version: "1.0"\n';
  yaml += 'components:\n';

  for (const item of reports) {
    yaml += `  - name: "${item.sharedComponentName}"\n`;
    yaml += `    archetype: "${item.archetype}"\n`;
    yaml += `    category: "${item.category}"\n`;
    yaml += `    targetPath: "${item.targetPath}"\n`;
    yaml += `    pageOccurrencesCount: ${item.pageOccurrencesCount}\n`;
    yaml += `    extractionPriority: "${item.extractionPriority}"\n`;
    yaml += `    routes:\n`;
    for (const r of item.routes) {
      yaml += `      - "${r}"\n`;
    }
    yaml += `    currentLocalNames:\n`;
    for (const n of item.currentLocalNames) {
      yaml += `      - "${n}"\n`;
    }
    yaml += `    suggestedInputs:\n`;
    for (const inp of item.suggestedInputs) {
      yaml += `      - "${inp}"\n`;
    }
    yaml += `    suggestedOutputs:\n`;
    for (const out of item.suggestedOutputs) {
      yaml += `      - "${out}"\n`;
    }
    yaml += '\n';
  }

  return yaml;
}

// Standalone execution entrypoint
if (import.meta.url === `file://${process.argv[1]}`) {
  console.log('[cluster-components] Cross-page reusable component clustering utility initialized.');
}
