---
name: client-planning
description: Protocol for client & frontend planning, interactive Dev Workbench (Storybook/playground) with live input controls, and strict bottom-up component construction (Shared Entities -> Atoms -> Molecules -> Organisms -> Screens).
---

# Client Planning, Dev Workbench & Bottom-Up Construction Protocol

This skill governs the end-to-end lifecycle of planning and building client frontend applications, feature modules, and UI surfaces within the Dark Factory.

---

## 0. FUNDAMENTAL INVARIANTS: NO MONOLITHIC SCREENS

> [!IMPORTANT]
> **The Golden Law of Frontend Authoring**:
> Agents are **STRICTLY PROHIBITED** from authoring full monolithic pages or screens from scratch in a single shot.
> All client features MUST be built **Bottom-Up**: from shared domain contracts and reusable atoms to composite molecules, verified in an interactive Dev Workbench, and only then assembled into screens.

```
┌────────────────────────────────────────────────────────────────────────┐
│                        PROHIBITED (FAIL-CLOSED)                        │
│  OpenSpec ──► Direct 500-line monolithic page ──► Unmaintainable chaos │
└────────────────────────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────────────────┐
│                        DARK FACTORY REQUIREMENT                        │
│  OpenSpec ──► Shared Contracts ──► Atoms/Molecules in Dev Workbench    │
│           ──► Verified with Dynamic Input Knobs ──► Pure Screen Layout │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 1. THE 5-LAYER BOTTOM-UP HIERARCHY

Every client application must be constructed in strict ascending order:

```mermaid
flowchart TD
    L0["Level 0: Domain Contracts & Ports\n(<name>.api.md ≤ 60 lines, schemas, DTOs)"]
    L1["Level 1: Reusable UI Atoms & Primitives\n(Button, Input, Badge, Dialog Overlay, Icon — ≤ 100 lines)"]
    L2["Level 2: Composite Molecules\n(Form Group, Filter Bar, Table Row, Card — ≤ 140 lines)"]
    L3["Level 3: Feature Organisms\n(Data Table, Navigation Header, Drawer, Modal Form — ≤ 180 lines)"]
    L4["Level 4: Screens & Routing\n(Pure orchestration of approved components — ≤ 150 lines)"]

    L0 --> L1
    L1 --> L2
    L2 --> L3
    L3 --> L4

    subgraph DevWorkbench["Interactive Dev Workbench (make dev)"]
        W1["Render Level 1 & 2 Entities in Isolation"]
        W2["Interactive Controls / Knobs for Live Inputs"]
        W3["Visual & Edge Case Verification"]
    end

    L1 -.-> DevWorkbench
    L2 -.-> DevWorkbench
    L3 -.-> DevWorkbench
```

---

## 2. PHASE 1: COMPREHENSIVE REQUIREMENTS INTAKE (MAX ТЗ)

Before authoring any code, the agent must perform an exhaustive requirements gathering and codify it in `openspec/specs/<client>/spec.md`:

1. **Route & Screen Inventory**:
   - List every route, subroute, and modal dialog.
   - Define exact entry conditions, access guards, and parameters.
2. **Domain Entities & Data Contracts**:
   - For every entity: schema, fields, validation constraints, and nullability.
   - Companion API contracts: `<entity>.api.md` (≤ 60 lines).
3. **State Matrix & Visual Variations**:
   - Define for each screen: `Loading`, `Empty`, `Success`, `Partial Error`, and `Network Error`.
   - Explicit mock payloads for each state.
4. **User Journeys & Scenarios**:
   - Every requirement must have concrete `#### Scenario` acceptance criteria with Given-When-Then.

---

## 3. PHASE 2: INTERACTIVE DEV WORKBENCH (STORYBOOK / PLAYGROUND)

Before any production page is linked to routing, the project must expose an interactive **Dev Workbench** (e.g. `/_dev/workbench`, `/workbench`, or Storybook route under `make dev`):

```mermaid
sequenceDiagram
    participant Dev as Agent / Human Developer
    participant WB as Dev Workbench (make dev)
    participant Knobs as Dynamic Input Controls
    participant Comp as Shared UI Entity / Atom

    Dev->>WB: Open Workbench route
    WB->>Comp: Render entity in isolation with mock defaults
    Dev->>Knobs: Enter dynamic inputs (props, labels, toggles, mock data)
    Knobs->>Comp: Reactively update input parameters
    Comp-->>Dev: Immediate visual feedback across boundary conditions
    Dev->>WB: Verify hover, error, disabled, and responsive states
```

### Workbench Requirements:
1. **Isolated Rendering**: Each atom, molecule, and organism must be renderable independently of backend APIs.
2. **Dynamic Input Knobs**: The workbench must provide interactive controls (text fields, selects, toggles, JSON inputs) allowing the developer/agent to mutate props on the fly and verify edge cases:
   - Extremely long text (overflow / truncation)
   - Empty values / undefined
   - Disabled and loading states
   - Validation error triggers
3. **Zero Backend Dependency**: All workbench instances use local deterministic mock adapters.

---

## 4. PHASE 3: COMPONENT CODING & ASSEMBLY PROTOCOL

During component creation, agents must adhere to:

| Layer | Responsibility | Max Physical Lines | Tested In |
| --- | --- | --- | --- |
| **Domain Port** | Interfaces, DTOs, `<name>.api.md` | ≤ 60 | Typecheck (`tsc`) |
| **Atom** | Single visual primitive (Button, Badge) | ≤ 100 | Dev Workbench + Unit |
| **Molecule** | 2-3 atoms composed (SearchInput, FormField) | ≤ 140 | Dev Workbench + Unit |
| **Organism** | Feature block (FilterableTable, SettingsCard) | ≤ 180 | Dev Workbench + Component |
| **Screen** | Grid layout & routing orchestrator | ≤ 150 | Integration / E2E |

### Hard Rules:
- **Rule of 2**: If an atom or molecule pattern appears in ≥ 2 places, it belongs in the shared UI layer.
- **Zero Monoliths**: A page component that contains raw DOM buttons, forms, and tables without using reusable components will be REJECTED.
- **Explicit Naming**: Fully spelled out identifiers (`customerProfileTableComponent`, not `cptc` or `custTab`).

---

## 5. AGENT EXECUTION CHECKLIST

```markdown
- [ ] 1. Max ТЗ documented in openspec/specs/<client>/spec.md with all scenarios.
- [ ] 2. Shared domain types and <entity>.api.md contracts created.
- [ ] 3. Dev Workbench registered for new entities under `make dev`.
- [ ] 4. Interactive input knobs wired for live prop mutation and boundary testing.
- [ ] 5. Reusable atoms and molecules verified in isolation.
- [ ] 6. Screen page assembled solely by composing verified entities.
- [ ] 7. Full gate passes: `make df71:check` exits with code 0.
```
