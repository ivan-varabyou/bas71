---
name: project-navigation
description: Find existing project components, services, ports and engines before adding or modifying code; resolve PROJECT-CATALOG, PROJECT-COVERAGE, PROJECT-SIZE and PROJECT-HARDCODE diagnostics using the portable factory discovery commands.
---

# Navigate and reuse project entities

Before implementation, run `factory discover --query <entity-or-capability>` from the repository root. Read the relevant configured ownership/readiness metadata and source references. Use a symbol or selector in a second query to find usages. Search reads current sources; it is lexical discovery, not a semantic call graph or proof of safe reuse. Queries currently use literal text (no stemming or translation); use code names such as Button, storage, auth, descriptor.

## 3-Phase Dark Factory Protocol (Discovery -> Plan -> Implement)

Every development agent must execute tasks in three distinct phases to prevent token burn and avoid rework:
1. **Phase 1: Discovery & Technical Contract**:
   - Query existing components and ports (`factory discover --query <entity>`).
   - Audit size budgets and policies (`factory project-check`).
   - Produce a concise pre-implementation plan: target files, estimated line counts adhering to budgets (`*.component.ts` <= 250 lines, `*.component.html` <= 150 lines, `*.test.ts` <= 350 lines), reusable primitives to consume, and verification strategy.
2. **Phase 2: Plan Review**:
   - Verify that the technical contract complies with layer boundaries and limits before creating or editing files.
3. **Phase 3: Implementation & Gate Verification**:
   - Implement according to the contract, run formatting/linting, and execute `factory harness`.

Read `factory.project.json` guidance and the applicable layer AGENTS.md. Open only relevant contracts, implementation and actual consumers. Choose reuse, contract extension, or feature-local composition and record the reason when introducing a new entity. A candidate is not approved just because a file exists. Do not reimplement a service/port because the first query returned no result; search ownership and synonyms, then use `rg` in that scope.

For PROJECT findings run `factory project-check --json`; follow its configured guidance. Hardcoded deployment URLs belong behind configuration/ports, user-facing copy behind i18n, product schemas behind descriptors, styles behind actual design tokens where shared. Do not blindly replace every literal with a constant; protocol constants and meaningful local defaults have legitimate owners.

When adding/moving public reusable entities, update the curated entities in factory.project.json with owner, readiness and references. Never mark approved without a real consumer or verification reference. Source discovery does not require registering every private helper.

For a repeated defect, add a rejected fixture and a valid counterexample, update the narrow rule and OpenSpec, and run the policy and affected behavior checks. Do not hide findings using new exclusions or inflated budgets. Keep stack-specific parsing in its adapter. Skills guide work; deterministic checks and independent review determine acceptance.
