---
name: frontend-component-design
description: Resolve Viafactory UI-SIZE, UI-BOUNDARY, UI-I18N, UI-REUSE, UI-SVG and UI-TEMPLATE architecture diagnostics; decompose Angular components and choose existing UI primitives without changing donor behavior. Use when these diagnostics appear or a frontend component is being extracted for reuse.
---

# Component design and architecture repair

Before adding a component/service, run `factory discover --query <entity>` and inspect its existing consumers. Start from the diagnostic's file and rule ID. Read only the relevant section in [component rules](../../../docs/agents/architecture/component-design.md) and matching rows in the [UI catalog](../../../docs/agents/architecture/ui-catalog.md). Requirements live in [OpenSpec](../../../openspec/specs/frontend-component-architecture/spec.md).

1. Inspect the component's inputs/outputs, template, styles and actual consumers. Identify presentation mechanics versus domain orchestration. Do not explore unrelated packages.
2. For size/boundary findings, name the responsibilities before moving code. Shared dialog owns overlay/accessibility mechanics; an entry editor owns schemas, relationships, draft/publish and API-facing state. Put domain compositions in features. Use projected slots or lazy templates/components as required by the caller. Preserve donor page-versus-dialog semantics.
3. Prefer a suitable catalog primitive. If its contract lacks accessible naming, form type, loading or disabled behavior, extend and verify that contract before migrating callers. Keep feature logic out of shared primitives. Do not invent a generic component merely because none is cataloged.
4. Preserve user-visible text through i18n and donor-compatible behavior. No placeholder handlers, static data presented as live data, arbitrary CSS resizing, or changes to donor acceptance assertions.
5. Fix the source responsibility, not just file length: no numbered fragments, forwarding-utility collections, compressed formatting, threshold increases or blanket lint disables. An unresolved production finding remains a blocker.
6. Run `pnpm architecture:frontend:test` and `pnpm architecture:frontend`; inspect all diagnostics. Run affected tests and real Angular/browser flows for refactors, then harness and donor gate. If only rules/docs were requested, report existing application findings without silently expanding into a full UI rewrite.
7. Update catalog entries for moved/added components. For a newly demonstrated architectural failure, add a narrow failing checker fixture AND a valid counterexample; update its rule ID/documentation and canonical requirement. Keep AGENTS.md a short map. Do not claim every design property is lintable.

The checker suggests this skill; it does not invoke an agent or authorize external issue publication, dependencies, merging or deployment. If the current task is review-only, propose remediation and preserve findings instead of changing application code.
