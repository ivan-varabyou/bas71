---
name: task-verification
description: Protocol for defining Use Cases, verifying task execution with mandatory automated gates, auto-fixing regressions, and generating a Task Verification Report. Generic template — adapt placeholders to your project stack.
---

# Task Verification & Dark Factory Acceptance Protocol

This skill governs how tasks and features are specified, tested with deterministic automated gates, auto-fixed, and reported. All placeholders in `<angle-brackets>` must be replaced with your project's actual commands and paths.

---

## 0. FUNDAMENTAL PRINCIPLES

1. **Spec is the Ground Truth**: The OpenSpec module is the reference of behavior, not screenshots or subjective interpretation.
2. **Pre-Generated Automated Specs**: Tests are compiled from actual behavior specifications **before** feature implementation. Agents DO NOT author subjective tests to validate their own code.
3. **No Fixing "By Eye"**: Fixing "by looking at a screenshot" or improvising UI mocks is **STRICTLY PROHIBITED**. Agents fix strictly in response to failing assertions in the gate report.
4. **Deterministic Status "DONE"**: Status "DONE" can NEVER be declared verbally or by commit message. Status "DONE" is ONLY granted when the acceptance gate exits with code 0.
5. **Gate Integrity**: Modifying spec files or gate assertions to make a failing test pass is forbidden.

---

## 1. THE ACCEPTANCE PIPELINE (`<make test>`)

Every task and pull request must execute the project's configured harness:

```
┌────────────────────────────────────────────────────────────┐
│ Stage 1: Static Scan                                       │
│ - Zero tolerance for stubs, TODOs, placeholder logic       │
│ - Fails on: empty handlers, preventDefault-only, TODO/FIXME│
└───────────────────────────────┬────────────────────────────┘
                                │ PASS
                                ▼
┌────────────────────────────────────────────────────────────┐
│ Stage 2: Unit & Component Tests                            │
│ - All unit tests green                                     │
│ - No test skipped or mocked without justification          │
└───────────────────────────────┬────────────────────────────┘
                                │ PASS
                                ▼
┌────────────────────────────────────────────────────────────┐
│ Stage 3: Integration / E2E Tests (if configured)           │
│ - 100% of spec scenarios covered                           │
│ - Missing or hidden elements = FAIL                        │
└───────────────────────────────┬────────────────────────────┘
                                │ PASS
                                ▼
┌────────────────────────────────────────────────────────────┐
│ Stage 4: df71 Harness Gate                                 │
│ - line-budget-check, openspec-validate, evidence-check     │
│ - Exit Code 0 = ACCEPTED                                   │
│ - Exit Code 1 = REJECTED (blocks merge)                    │
└────────────────────────────────────────────────────────────┘
```

---

## 2. PHASE 0: PRE-TASK PREPARATION (MANDATORY BEFORE ANY CODING)

Before writing any new component, template, or service:

1. **Mandatory Git Hygiene & Clean Stage Audit**:
   ```bash
   df71 stage-check --pre-task
   # or:
   make stage-check
   ```
   - **Empty Stage Rule**: Before starting a new task, the git working tree and staging MUST be clean.
     - *Previous completed task*: Commit it immediately: `git add <files> && git commit -m "feat(...): ... Closes #<ID>"`.
     - *Stale / experimental changes*: Clean or stash them: `git restore . && git clean -df` (or `git stash`).
     - **NEVER** start work on a new task on top of a dirty stage or mixed changes!
   - **Forbidden Files & Secrets Audit**:
     - Ensure NO secret credentials (`.env`, `*.pem`, `*.key`, `*token*`, `credentials.json`) are staged or untracked.
     - Ensure NO temporary garbage (`*.tmp`, `*.temp`, `*.swp`, `*.bak`, `.DS_Store`) is present.
     - Ensure NO stray test screenshots or visual dumps (`*.png`, `test-results/`, `playwright-report/`) are present.
     - Remove forbidden files or add them to `.gitignore` before proceeding.

2. **Run Discovery**:
   ```bash
   df71 discover --query <EntityName>
   df71 project-check
   ```
3. **Audit Shared Catalog** (your project's `<shared-lib>` path):
   - Check existing reusable atoms, molecules, and dialogs.
   - **Rule of 2**: If a pattern is needed in ≥ 2 places, it MUST live in the shared layer.
4. **Audit Ports & Interfaces** (`<contracts-path>`):
   - Check existing ports and event contracts before creating ad-hoc state or network calls.
5. **Mandatory Adjacent Entity API Contract (`*.api.md`)**:
   - Every reusable shared component or domain entity must have `<name>.api.md` adjacent to it.
   - Use `templates/entity.api.md` as the starting template.

---

## 3. PHASE 1: RED STAGE FORMULATION

At the **kickoff of every task** (BEFORE modifying implementation code):

1. **Confirm behavioral spec** exists in `openspec/specs/<module>/spec.md`.
2. **Formulate Explicit Use Cases**:
   - Map each requirement to its expected action and observable effect.
3. **Mandatory Zero-Stub Verification**:
   - Every planned element must be wired to real logic (API call, state update, or navigation). Stubs rejected by harness.

---

## 4. CLEAN CODE, ARCHITECTURE & NAMING STANDARDS (SOLID & DRY)

During all implementation and refactoring phases, agents MUST strictly adhere to:
- **Readable Like a Book**: Code structure must be self-documenting and logical.
- **Explicit Naming (ABSOLUTELY NO Cryptic Abbreviations)**:
  - All constants, variables, functions, interfaces, parameters, and component names MUST be fully spelled out.
  - **Forbidden**: `cm`, `subnav`, `ctb`, `btn`, `fn`, `idx`, `opts`, `batchDel`, `actKey`, `id_val`, `acc`.
  - **Required**: `contentManagerTableComponent`, `subNavigationMenuComponent`, `contentTypeBuilderService`, `filterAttributeOptions`, `executeBatchDeleteAction`, `activeContentTypeKey`.
- **DRY & SOLID Principles**:
  - Single Responsibility: One component/module per directory or file.
  - Don't Repeat Yourself: Extract reusable pure functions and contract interfaces.
- **Physical Line Budgets**: Respect your stack's configured limits (see `factory.project.json` scopes, <= 350 lines).
- **Zero Inline Comments**:
  - Code expresses intent through naming and structure; comments explaining lines of code are prohibited.

---

## 5. AUTO-FIX LOOP & TASK ACCEPTANCE

```bash
make test
make harness
# or:
df71 harness
```

If any gate stage fails:
1. Read the exact failing assertion output.
2. Fix ONLY what is reported in the failing findings.
3. Re-run until harness exits with code 0.

---

## 6. TASK VERIFICATION REPORT

At the conclusion of verification, output `task_verification_report.md`:

```markdown
# 📋 Task Verification Report: [Task Title / ID]

> **Status**: [PASSED / IN_PROGRESS / BLOCKED]
> **OpenSpec Ref**: `openspec/specs/.../spec.md`
> **Harness Verdict**: PASS (Exit Code 0)

---

### 1. Formulated Use Cases
- [x] UC-01: [describe verified scenario]
- [x] UC-02: [describe verified scenario]

### 2. Acceptance Verification Results
| Check | Result |
|---|---|
| Unit tests | PASS (N/N) |
| Integration/E2E | PASS (N/N) |
| df71 harness | PASS |
| Line budgets | PASS |

### 3. Issues Discovered & Fixes Applied
| Issue | Root Cause | Fix | Status |
| --- | --- | --- | --- |
| Example: missing event handler | Unbound method | Wired to handler | Fixed |

### 4. Remaining Action Items
- [Next scheduled task from OpenSpec]
```
