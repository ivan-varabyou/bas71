# Project Stack & Agent Orientation Guide

## Overview
- **Stack**: <Stack Name> (`<stack-id>`)
- **Topology**: <monorepo | polyrepo>
- **Package Manager**: <npm | pnpm | yarn | bun | cargo | go | uv>
- **Issue Tracker**: <github | gitlab | openspec-local>

## Universal Developer & Agent Interface (Make)
Every developer and AI agent MUST interact with this project via `make`:
- `make env`: Bootstrap and verify environment (.env, runtime).
- `make setup`: Pull environment and install dependencies.
- `make dev`: Start local development / hot-reload server.
- `make build`: Build production artifacts.
- `make test`: Run unit and component test suites.
- `make check`: Run linters, types, and line budget checks.
- `make harness`: Run dark-factory verification harness.
- `make clean`: Clean temporary and build artifacts.

## Architecture & Code Limits
- Strict Hexagonal Architecture (Domain is pure; UI talks to Use Cases; Infra implements Ports).
- Companion Entity API Contracts: shared entities must maintain an adjacent `<name>.api.md` (≤ 60 lines).
- Physical Line Budgets: adhere strictly to configured limits (SFC ≤ 180, Composable ≤ 80, Adapter ≤ 220, Test ≤ 240).
