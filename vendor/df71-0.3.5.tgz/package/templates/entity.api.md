# <EntityName> API Contract

> Max 60 physical lines. Keep concise — this is the agent's fast-read contract.
> Place adjacent to `<name>.ts` or `<name>.vue`. Update when interface changes.

## Purpose

One-line summary of what this entity does.

## Public Props / Constructor Args

| Prop / Param | Type | Required | Default | Description |
|---|---|---|---|---|
| `propA` | `string` | ✅ | — | Short description |
| `propB` | `number` | ❌ | `0` | Short description |

## Emits / Methods / Outputs

| Name | Signature / Payload | Description |
|---|---|---|
| `update:value` | `(value: string) => void` | Emitted on user input |
| `methodA()` | `() => Promise<void>` | Short description |

## Usage Snippet

```ts
// Copy-paste minimal working example (3–10 lines)
import { EntityName } from './entity-name';

const entity = new EntityName({ propA: 'value' });
await entity.methodA();
```

## Invariants & Constraints

- Key invariant or rule agents must not violate.
- E.g.: "Must be disposed when parent scope is destroyed."
