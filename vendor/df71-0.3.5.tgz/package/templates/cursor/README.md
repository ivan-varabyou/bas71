# Cursor process projections (templates)

Copy into the consumer repository:

| Template | Consumer destination |
| --- | --- |
| `skills/factory-sprint/SKILL.md` | `.cursor/skills/factory-sprint/SKILL.md` |
| `rules/dark-factory.mdc` | `.cursor/rules/dark-factory.mdc` |

Also copy or link the package [AGENTS.md](../../AGENTS.md) into the consumer
`AGENTS.md` (or cite the installed package path and keep a short consumer overlay
for product stack locks only).

Automation default is **L1** (human merge). Agents SHALL NOT `gh pr merge` unless
the human explicitly authorizes merge for named PR(s) in the same session.
Do not document merge-on-green as success without explicit `automation.level: L2`,
harness green, CLEAN evidence matching head SHA, and a living `### Requirement:` cite.

All projection text is **English only**.
