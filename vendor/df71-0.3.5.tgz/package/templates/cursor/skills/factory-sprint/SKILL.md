---
name: factory-sprint
description: >-
  Portable dark factory: OpenSpec issue, TDD, harness, PR, then second-model
  security-review dialogue on GitHub. Use when the user mentions Sprint, dark
  factory, GitHub issue/task/story, TDD, OpenSpec, feat/#N, or asks to implement
  a numbered issue.
---

# Factory sprint (GitHub + TDD)

Process source of truth: living `openspec/specs/dark-factory/spec.md` in the
factory-kit package / consumer projection. This skill is a brand-free projection.

## Source of work

- Development ONLY from OpenSpec. No code from chat without a living `### Requirement:`.
- Implement only against a GitHub Task (`type:task`) `#N` that cites OpenSpec.
- Branch: `feat/#N-short-name` or `fix/#N-short-name`.
- Commits / PR title: `#N - feat(<scope>): …`. PR body: `Closes #<Task>` only — never `Closes #<Story>`.
- Never commit `.env`, tokens, or Cursor/AI authorship trailers.

If there is no `#N`, stop. Open or archive an OpenSpec change, then cut the Task.

## Model roles

| Role | Primary guidance |
| --- | --- |
| `ops-cheap` | Status, logs, rerun known harness |
| `implement` | Session default — tests and code |
| `openspec-author` | Draft OpenSpec changes |
| `openspec-review` | No Composer/flash; `fast` only if kit-allowlisted |
| `security-review` | No Composer/flash; `fast` only if kit-allowlisted |
| `intake-triage` | Map evidence → requirement or change; redact secrets |

Role priority lists MAY live in consumer `factory.config.yaml` → `roles:`.

### Model availability day-cache

Consumers SHOULD keep a local day-cache (Viafactory: gitignored `tmp/factory-model-availability.json` + `scripts/factory-model-availability.sh`; do not commit) of which role slugs work. Agents SHALL consult it before Task/subagent launches for `openspec-review` / `security-review`: probe at most once per UTC day; mark unavailable on invoice/quota/outage; do not retry unavailable slugs until the cache is stale; prefer `available[]`. Empty available + fresh cache → stop that gate, do not loop dead models.

## Loop

1. Red — tests for every scenario (including reject).
2. Green — minimum impl.
3. Harness — `factory harness` or consumer `pnpm harness:check` until green.
4. Commit — only when the human asks.
5. PR — open/update before security-review dialogue completes.
6. Security-review on PR head; post blocked / CLEAN on GitHub.
7. Ready only when CLEAN matches head SHA. At L1: humans merge; agents MUST NOT `gh pr merge` unless the human explicitly authorizes merge for named PR(s) in the same session.

## Harness

```bash
pnpm harness:check
# or
pnpm exec factory harness
```

Do not put LLM review inside the harness.
