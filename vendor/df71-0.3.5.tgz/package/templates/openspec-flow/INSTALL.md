# Optional openspec-flow conveyor (KIT-06)

openspec-flow is **optional**. Install it only when you want GitHub-label
conveyor automation for the same lifecycle already defined by living
`dark-factory`. It SHALL NOT invent requirements outside OpenSpec and SHALL
NOT create a parallel chat-only implementation path.

## Install

1. Install the GitHub App, **or** run the CLI shim:

   ```bash
   npx @dwmkerr/openspec-flow install
   ```

2. Ensure repository labels match `factory.config.yaml` → `flow.labels`
   (defaults below). Bootstrap helpers may create them; see
   `templates/github/README.md`.

3. Keep `automation.level: L1` (default) unless your consumer has archived
   OpenSpec allowing L2. There is **no separate `autoMerge` config field**;
   only `automation.level` controls merge automation.

## Default labels → dark-factory steps

| Label | Dark-factory step |
| --- | --- |
| `openspec:go` | Start OpenSpec change / proposal (`openspec/changes/<name>/`) |
| `openspec:spec` | Spec PR / archive path (`openspec archive` → living specs) |
| `openspec:impl` | Implementation Task → TDD → harness → security-review → impl PR |

Override names only via `flow.labels` in `factory.config.yaml`. Labels must
still map 1:1 to those three conveyor stages.

## Lifecycle (non-parallel)

Same OpenSpec → archive → Task → impl PR lifecycle as `dark-factory`:

1. **openspec:go** — propose change under `openspec/changes/`; validate.
2. **openspec:spec** — human gate at L1 for Spec-PR merge / archive.
3. Cut a GitHub **Task** citing the living `### Requirement:` / scenarios.
4. **openspec:impl** — implement on a Task branch; impl-PR requires
   factory harness green and matching CLEAN security-review evidence before
   ready-for-merge.

A **parallel chat-only** implementation path (coding from chat/memory without
a living OpenSpec requirement and Task) is **forbidden**.

## Merge rules

- At **L1** (default): humans merge. Agents SHALL NOT `gh pr merge` / `--auto` unless the human explicitly authorizes merge for named PR(s) in the same session.
  Merge-on-green without L2 is **forbidden** and MUST NOT be documented as
  success.
- At **L2** (opt-in only): a gated bot merge MAY occur only under living
  factory-kit L2 rules (`automation.level: L2`, harness green, CLEAN evidence
  matching head SHA, OpenSpec citation). See `templates/github/l2-gated-merge.md`.
- Do **not** add `autoMerge: true` (or any `autoMerge` field). Schema and
  config parsers reject it; use `automation.level` only.
