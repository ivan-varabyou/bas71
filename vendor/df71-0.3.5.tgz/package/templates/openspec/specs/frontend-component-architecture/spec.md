# Frontend Component Architecture

## Purpose

Make Angular component ownership, reuse and decomposition enforceable and discoverable without weakening donor acceptance.

## Requirements

### Requirement: Frontend source coverage and bounded size

The architecture gate SHALL scan production frontend TypeScript, Angular templates and CSS, fail on missing coverage or parse/config errors, and enforce the documented per-layer physical-line budgets. Existing violations SHALL remain failures rather than silently grandfathered baselines.

#### Scenario: Oversized shared template
- **WHEN** a shared UI template exceeds 100 physical lines
- **THEN** the check fails with UI-SIZE-001 and links to remediation and the reuse catalog.

#### Scenario: Missing frontend after a move
- **WHEN** the configured frontend directory or a required source category is absent
- **THEN** the check fails with UI-COVERAGE-001.

### Requirement: Dependency direction and composable primitives

Shared UI SHALL own presentation mechanics and generic contracts only. It SHALL NOT depend directly or transitively on features, pages, app, auth, domain contracts, core, host, adapters, router/HTTP clients, storage or aggregate application tokens. Features/auth/i18n/layout SHALL NOT depend on pages/app. Pages SHALL NOT depend on app. Aliases, relative imports and reexports SHALL be resolved.

#### Scenario: Domain dependency hidden behind a barrel
- **WHEN** a shared dialog imports a helper barrel reexporting a feature module
- **THEN** the gate fails with UI-BOUNDARY-001 and the import chain.

#### Scenario: Generic dialog composition
- **WHEN** a feature renders an entry editor in a dialog
- **THEN** the feature provides content/actions and domain state while the dialog owns accessibility and overlay mechanics, preserving donor route behavior.

### Requirement: Template reuse and translatable copy

Static user-visible template text and accessible labels SHALL use i18n or caller-provided content. Native buttons SHALL be implemented by the shared button primitive and consumers SHALL preserve accessible/form behavior. Angular control-flow nesting SHALL not exceed four levels.

#### Scenario: Hardcoded duplicate action button
- **WHEN** a consumer template declares a native button with hardcoded visible text
- **THEN** the gate reports UI-REUSE-001 and UI-I18N-001.

#### Scenario: Projected translated button content
- **WHEN** a consumer uses the button primitive with translated content
- **THEN** reuse and static-copy checks pass.

### Requirement: Zero SVG in templates and code

Hand-written component templates and TypeScript sources SHALL NOT contain inline `<svg>` elements or hardcoded SVG markup strings. All SVG graphics SHALL be extracted into dedicated `*.svg` asset files under `assets/icons/` and rendered via the shared icon primitive (`<vf-icon>`).

#### Scenario: Inline SVG in component template

- **WHEN** a component template contains an inline `<svg>` element
- **THEN** the gate reports UI-SVG-001 and fails closed until extracted to an asset file.

#### Scenario: Dedicated SVG asset and icon primitive

- **WHEN** a component renders an icon via `<vf-icon name="...">`
- **THEN** the gate passes with zero UI-SVG-001 diagnostics.

### Requirement: Actionable diagnostics and rule evolution

Every architecture diagnostic SHALL identify file/line, stable rule ID, remediation document, reuse catalog and repair skill. Enforcement SHALL participate in package lint and therefore the mandatory platform harness. Checker regression tests SHALL include rejected and accepted cases. New findings SHALL update a narrow rule only when an invariant can be tested; skills SHALL not authorize gate suppression or external writes.

#### Scenario: Agent receives a diagnostic
- **WHEN** the architecture gate rejects a component
- **THEN** the agent can navigate directly to the applicable rule, existing implementation and `.agents/skills/frontend-component-design/SKILL.md`.
