# GitHub labels and PR evidence

## Bootstrap

```bash
bash scripts/bootstrap-labels.sh
# or for an explicit repo:
bash scripts/bootstrap-labels.sh owner/name
```

## Labels / flags

| Label | Kind | Meaning |
| --- | --- | --- |
| `type:story` | Scrum | Story covering one OpenSpec module |
| `type:task` | Scrum | One Task per living `### Requirement:` |
| `type:bug` | Scrum | Defect |
| `status:backlog` | Status | Not started |
| `status:sprint` | Status | In current sprint |
| `status:in-progress` | Status | Agent/human working |
| `status:review` | Status | PR open for review |
| `priority:critical` | Priority | Take first |
| `priority:high` | Priority | Core path |
| `priority:normal` | Priority | Polish / docs |
| `openspec:go` | Flow flag | Start OpenSpec change / proposal |
| `openspec:spec` | Flow flag | Spec PR / archive path |
| `openspec:impl` | Flow flag | Implementation Task / impl PR |

Default flow labels (override in `factory.config.yaml` → `flow.labels`):

| Label | Dark-factory step |
| --- | --- |
| `openspec:go` | Start OpenSpec change / proposal |
| `openspec:spec` | Spec PR / archive path |
| `openspec:impl` | Implementation Task / impl PR |

Full install steps: [`../openspec-flow/INSTALL.md`](../openspec-flow/INSTALL.md).

Parallel chat-only implementation without OpenSpec is forbidden.

At **L1** (default), humans merge. Agents SHALL NOT `gh pr merge` / `--auto`
unless the human explicitly authorizes merge for named PR(s) in the same session.
Do not enable merge-on-green. Merge-on-green without `automation.level: L2`
is forbidden and MUST NOT be documented as success. There is no separate
`autoMerge` field; only `automation.level` controls merge automation.

**L2** gated bot merge is opt-in only — see `l2-gated-merge.md`. Fresh templates
stay at L1.

Evaluate with:

```bash
pnpm exec factory merge-gate --head-sha <40hex> --harness-exit <n> \
  --evidence-file ./evidence.txt --citation-file ./pr-body.txt
```

## PR evidence snippet

```text
Factory security-review: CLEAN
SHA: <full 40-hex head sha>
Model: <security-review model slug>
```
