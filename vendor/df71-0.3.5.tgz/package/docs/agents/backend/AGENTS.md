# Backend (agent layer)

Purpose: services, gateway, and data topology for this repository.

**OpenSpec:** cite living backend/ops modules this page summarizes.

**Up:** [root AGENTS.md](../../../AGENTS.md)  
**Down:** link per-service / per-domain notes under this layer (do not dump catalogs into root `AGENTS.md`).

English only. Non-obvious invariants (AuthN≠AuthZ, off-public admin planes, body limits) belong here with module citations.
