# Apps (agent layer)

Purpose: installable / public UI surfaces for this repository.

**OpenSpec:** cite living app modules this page summarizes.

**Up:** [root AGENTS.md](../../../AGENTS.md)  
**Down:** per-app notes as needed.

English only. Obvious framework facts stay out of this page.
