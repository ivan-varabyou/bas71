# Release process

English only. Applies to `df71`.

**Canonical process:** repository root [`RELEASE.md`](./RELEASE.md) in `df71`.
This file remains for npm package consumers who see the published tarball.

## Version axes

| Axis | Where | When to bump |
| --- | --- | --- |
| Package semver | `package.json` → `version` | Every publish |
| Config schema | `factory.config.yaml` → `version` | Only on incompatible config shape |
| Process revision | living `openspec/specs/dark-factory/spec.md` | Via OpenSpec archive in this repo |

### Semver rules for the kit

- **MAJOR** — breaking CLI flags, config schema, evidence contract, or process locks consumers rely on.
- **MINOR** — new builtins/templates/docs; backward-compatible behavior.
- **PATCH** — bug fixes with no intentional process break.
- Expanding the evidence `*-fast` allowlist is a documented kit release (usually MINOR).

## Prerequisites

1. Living OpenSpec change archived when behavior locks change.
2. `pnpm test`, `pnpm lint`, `pnpm typecheck`, `pnpm build` green on `main`.
3. `CHANGELOG.md` updated under `[Unreleased]` then moved into the version section.

## Tag and publish

Preferred path (CI):

```bash
# on main, after merge
pnpm version <patch|minor|major>   # updates package.json; creates commit if configured
git push origin main --follow-tags
```

Or explicit tag:

```bash
# package.json version already set to X.Y.Z
git tag -a "vX.Y.Z" -m "vX.Y.Z"
git push origin "vX.Y.Z"
```

GitHub Actions workflow `.github/workflows/release.yml` on tag `v*`:

1. Install, test, build.
2. Create GitHub Release from `CHANGELOG.md` notes when possible.
3. `pnpm publish --access public` when `NPM_TOKEN` repository secret is present.
4. If `NPM_TOKEN` is missing, the GitHub Release still publishes the git tag for
   `pnpm add -D "df71@github:ivan-varabyou/df71#vX.Y.Z"` consumers.

## Consumer upgrade checklist

```bash
pnpm up df71
# or: pin github:ivan-varabyou/df71#vX.Y.Z
pnpm harness:check
```

Refresh Cursor projections from `node_modules/df71/templates/cursor/`
(or the git checkout `templates/cursor/`) when the release notes say projections changed.

## Do not

- Publish from a dirty worktree.
- Skip CHANGELOG process-break notes.
- Enable L2 in default templates.
- Commit npm tokens or publish credentials.
