# Changelog

All notable changes to `df71` (Dark Factory 7/1) are documented in this file.
The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.3.6] - 2026-11-06

### Added
- Automated GitHub Issue creation on process and gate failures: `df71 check --create-issue` and `df71 fleet-sync --create-issues`.
- Deduplication and commenting on existing open issues to avoid ticket flooding.
- Failure issue reporting integrated into `.github/workflows/df71-auto-sync.yml` and `.github/workflows/factory-gate.yml`.
- `BudgetScope.exclude` support in `factory.project.json` for excluding legacy or test fixtures from line budget constraints.
- Bundled runtime dependencies (`bundleDependencies: ["yaml"]`) for 100% standalone zero-dependency execution.

## [0.3.5] - 2026-11-06

### Added
- Auto-distribution of `scripts/` (including `install.sh` and `scripts/github/`) across all workspace projects during sync.
- Auto-distribution of all managed skills (`client-planning`, `app-snapshot`, `frontend-component-design`, `project-navigation`, `task-verification`, `agent-review`) to target projects.
- Dependency update step in `.github/workflows/df71-auto-sync.yml` (`pnpm add -D df71@latest` / `npm install --save-dev df71@latest`).

### Fixed
- Registered `git-hygiene` stage in `BUILTIN_IDS` to prevent invalid builtin errors during `df71 check`.

## [0.3.4] - 2026-11-06

### Added
- Dual Development Streams: Proactive Feature Stream (Idea -> OpenSpec Proposal -> Story/Tasks) and Reactive Bug Triage Stream (User Issue -> Reproducer -> Upstream/Custom Fix).
- `df71 triage [id]`: CLI command for querying open GitHub issues, redacting secrets, and guiding Red-TDD bug reproduction.
- Zero-Install standalone execution: support for `npx --yes df71@latest <cmd>` and curl-installer script (`scripts/install.sh`).
- Automated Fleet delivery workflow (`df71-auto-sync.yml`): nightly schedule and dispatch trigger for automated project updates and PR creation.

## [0.3.3] - 2026-11-06

### Added
- Enterprise GitHub Toolkit (`df71 github init` / `make gh:init`): Automated setup of Scrum, Status, Priority, OpenSpec labels, milestones (`v0.1.0-mvp`, `v0.2.0-beta`, `v1.0.0-prod`), and main branch protection.
- Standardized Issue Templates: `story.yml`, `task.yml`, `bug.yml` with strict OpenSpec and scenario links.
- Standardized GitHub Actions Workflows: `factory-gate.yml` (CI verification), `release.yml` (automated release on tag), `project-sync.yml` (Kanban sync).
- Automated Release command (`df71 release [patch|minor|major]` / `make release`): Pre-task stage check, full gate verification, changelog notes extraction, semver bump, tag, remote push, and official GitHub Release creation via `gh`.
- Client Planning and Dev Workbench Protocol: 5-layer bottom-up hierarchy (`client-planning` skill, interactive knobs, zero monolithic screens).
- `df71 stage-check`: Pre-task git stage cleanliness and hygiene gate command (`df71 stage-check --pre-task` / `make stage-check`).
- `git-hygiene` builtin stage: Fail-closed scanner for forbidden garbage in git staging and untracked files (rejects `.env` secrets, crypto keys, tokens, temp files, and test screenshots/dumps).
- Integrated `git-hygiene` into `df71 check` and Dark Factory harness gates.
- Fleet synchronization (`df71 fleet-sync` / `df71 sync-all`) with workspace discovery and automated multi-project process sync.
- Post-upgrade harness verification in `df71 upgrade` to ensure green state.
- Automated process sync in `task-verification` protocol (Phase 0 Step 0: Git Hygiene & Stage Audit).

## [0.3.2] - 2026-11-06

### Added
- Independent standalone repository at `https://github.com/ivan-varabyou/df71`.
- Package renamed to `df71` with CLI binaries `df71`, `harness71`, `factory`.
- 7 Measures, 1 Cut architecture ("7 раз отмерь на бумаге, 1 раз отрежь в коде").
- Multi-stack adapters: Vue 3 TS, React TS, Angular TS, Go Engine, Rust Cargo, Python, Generic.
- Universal Make Façade generator (`make env`, `make dev`, `make test`, `make check`, `make harness`).
- `df71 init` and `df71 sync` commands for automated bootstrapping and `AGENTS.md` synchronization.
- Companion Entity API Contracts (`<entity>.api.md` ≤ 60 lines) and `templates/entity.api.md`.
- Builtin stages: `line-budget-check` and `update-check`.
- CLI `df71 check` command for fast policy and line-budget checks.
- CLI `df71 upgrade` command for checking npm registry, prompting, and auto-upgrading.
- Extensible stack adapter registry (`registerAdapter`).
- Decomposed observability into compliant file sizes (< 220 physical lines).
- Dual documentation in English (`.md`) and Russian companion (`.ru.md`).

## [0.2.1] - 2026-10-04

### Added
- Builtin `agent-docs-map-check`: verify root `AGENTS.md` links to hierarchical documentation layers.
- Living OpenSpec module `agent-docs`.

## [0.2.0] - 2026-10-04

### Added
- Portable harness stages and living OpenSpec validation (`openspec-validate`, `living-spec-guard`, `factory-evidence-check`).
- Automation levels L0, L1, L2 with evidence-gated merge authorization (`merge-gate`).
- Kit-owned evidence Model allowlist for exact `*-fast` slugs.
